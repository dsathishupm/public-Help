package screenplay;

import net.serenitybdd.junit5.SerenityTest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.annotations.Managed;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import screenplay.tasks.Login;

import static net.serenitybdd.screenplay.GivenWhenThen.*;

@SerenityTest
public class LoginTest {

    @Managed
    WebDriver browser;

    Actor user = Actor.named("Alex");

    @BeforeEach
    void setUp() {
        user.can(BrowseTheWeb.with(browser));
    }

    @Test
    void shouldLoginSuccessfully() {
        givenThat(user).wasAbleTo(Open.url("https://the-internet.herokuapp.com/login"));
        when(user).attemptsTo(Login.withCredentials("tomsmith", "SuperSecretPassword!"));
    }
}
