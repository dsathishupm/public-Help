package com.example.reporter;

import net.thucydides.core.model.TestOutcome;
import net.thucydides.core.reports.TestOutcomeReporter;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExcelTestOutcomeReporter implements TestOutcomeReporter {

    private static final String EXCEL_FILE_PATH = "Serenity_Live_Results.xlsm";

    @Override
    public void generateReportFor(TestOutcome outcome, File targetDirectory) {
        try {
            File file = new File(EXCEL_FILE_PATH);
            Workbook workbook;
            Sheet resultSheet;
            Sheet metricSheet;

            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                workbook = new XSSFWorkbook(fis);
                fis.close();
            } else {
                workbook = new XSSFWorkbook();
                workbook.createSheet("Live Results");
                workbook.createSheet("Metrics");

                Row header = workbook.getSheet("Live Results").createRow(0);
                String[] headers = {"Date", "Feature", "Scenario", "Status", "Duration (ms)", "Tags", "Steps", "Errors"};
                for (int i = 0; i < headers.length; i++) {
                    header.createCell(i).setCellValue(headers[i]);
                }
            }

            resultSheet = workbook.getSheet("Live Results");
            metricSheet = workbook.getSheet("Metrics");

            int rowNum = resultSheet.getLastRowNum() + 1;
            Row row = resultSheet.createRow(rowNum);

            String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            String feature = outcome.getUserStory() != null ? outcome.getUserStory().getName() : "N/A";
            String scenario = outcome.getTitle();
            String status = outcome.getResult().toString();
            long duration = outcome.getDuration();
            String tags = String.join(", ", outcome.getTagsAsStrings());
            String steps = String.valueOf(outcome.getTestSteps().size());
            String error = outcome.getTestFailureCause() != null ? outcome.getTestFailureCause().getMessage() : "";

            String[] data = {date, feature, scenario, status, String.valueOf(duration), tags, steps, error};
            for (int i = 0; i < data.length; i++) {
                row.createCell(i).setCellValue(data[i]);
            }

            try (FileOutputStream fos = new FileOutputStream(EXCEL_FILE_PATH)) {
                workbook.write(fos);
            }
            workbook.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean canHandle(TestOutcome testOutcome) {
        return true;
    }

    @Override
    public void setOutputDirectory(File file) {}
}
