
package util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FeatureFileUpdater {

    public static void updateFeatureFile(String scenarioName, List<String> accountTypes) {
        String templatePath = "src/test/resources/features/AccountRestrictions.feature";
        String tempPath = "src/test/resources/features/tmp_" + scenarioName + ".feature";

        try {
            List<String> lines = Files.readAllLines(Paths.get(templatePath));
            List<String> newLines = new ArrayList<>();

            for (String line : lines) {
                if (line.trim().startsWith("Examples:")) {
                    newLines.add("Examples:");
                    newLines.add("| AccountType |");
                    for (String accountType : accountTypes) {
                        newLines.add("| " + accountType + " |");
                    }
                    break;
                }
                newLines.add(line);
            }

            Files.write(Paths.get(tempPath), newLines);
            System.out.println("Updated feature file: " + tempPath);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String scenario = "AccountRestrictions024";
        List<String> products = ExcelMultiDropDownReader.getSelectedAccountTypes(scenario);
        updateFeatureFile(scenario, products);
    }
}
