
package util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExcelMultiDropDownReader {

    public static List<String> getSelectedAccountTypes(String scenarioName) {
        List<String> result = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream("src/test/resources/TestData.xlsx");
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                Cell scriptCell = row.getCell(0);
                Cell accountTypeCell = row.getCell(1);

                if (scriptCell != null && accountTypeCell != null &&
                        scenarioName.equalsIgnoreCase(scriptCell.getStringCellValue())) {

                    String[] types = accountTypeCell.getStringCellValue().split(",");
                    for (String type : types) {
                        result.add(type.trim());
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }
}
