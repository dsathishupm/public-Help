package com.example.features;

import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.questions.Text;
import net.serenitybdd.screenplay.actions.Open;
import net.thucydides.core.annotations.Managed;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.WebDriver;

@ExtendWith(SerenityJUnit5Extension.class)
public class SampleTest {

    @Managed
    WebDriver browser;

    Actor sam = Actor.named("Sam");

    @BeforeEach
    public void setUp() {
        sam.can(BrowseTheWeb.with(browser));
    }

    @Test
    public void openGoogleTest() {
        sam.attemptsTo(Open.url("https://www.google.com"));
    }
}