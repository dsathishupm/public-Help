let extractedLocators = [];

document.getElementById('extract').addEventListener('click', async () => {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: () => {
      window.postMessage({ type: 'EXTRACT_LOCATORS' });
    },
  });

  // Wait a bit then pull data from background
  setTimeout(() => {
    chrome.runtime.sendMessage({ type: 'GET_LOCATORS' }, (response) => {
      extractedLocators = response.locators || [];
      document.getElementById('output').textContent = JSON.stringify(extractedLocators, null, 2);
      document.getElementById('download').disabled = extractedLocators.length === 0;
    });
  }, 1000);
});

document.getElementById('download').addEventListener('click', () => {
  if (extractedLocators.length > 0) {
    const blob = new Blob([JSON.stringify(extractedLocators, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'locators.json';
    a.click();
    URL.revokeObjectURL(url);
  }
});