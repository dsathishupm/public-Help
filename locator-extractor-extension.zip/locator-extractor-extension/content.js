window.addEventListener('message', async (event) => {
  if (event.data.type === 'EXTRACT_LOCATORS') {
    const elements = document.querySelectorAll('body *');
    let locators = [];

    elements.forEach(el => {
      let locator = null;

      if (el.getAttribute('aria-label')) {
        locator = { type: 'aria', value: el.getAttribute('aria-label') };
      } else if (el.getAttribute('role')) {
        locator = { type: 'role', value: el.getAttribute('role') };
      } else if (el.getAttribute('alt')) {
        locator = { type: 'alt', value: el.getAttribute('alt') };
      } else if (el.getAttribute('title')) {
        locator = { type: 'title', value: el.getAttribute('title') };
      } else if (el.id) {
        locator = { type: 'id', value: `#${el.id}` };
      } else if (el.name) {
        locator = { type: 'name', value: `[name="${el.name}"]` };
      } else if (el.className && typeof el.className === 'string') {
        locator = { type: 'class', value: `.${el.className.trim().split(/\s+/).join('.')}` };
      }

      if (!locator) {
        const xpath = generateXPath(el);
        locator = { type: 'xpath', value: xpath };
      }

      if (locator) {
        locators.push({
          tag: el.tagName.toLowerCase(),
          locator: locator
        });
      }
    });

    chrome.runtime.sendMessage({ type: 'LOCATORS_EXTRACTED', locators });
    alert(`Extracted ${locators.length} locators. Now ready to download.`);
  }
});

function generateXPath(el) {
  if (el.id !== '') return `//*[@id="${el.id}"]`;
  if (el === document.body) return '/html/body';
  let ix = 0;
  const siblings = el.parentNode ? el.parentNode.childNodes : [];
  for (let i = 0; i < siblings.length; i++) {
    const sibling = siblings[i];
    if (sibling === el) {
      const path = generateXPath(el.parentNode) + '/' + el.tagName.toLowerCase() + `[${ix + 1}]`;
      return path;
    }
    if (sibling.nodeType === 1 && sibling.tagName === el.tagName) {
      ix++;
    }
  }
}