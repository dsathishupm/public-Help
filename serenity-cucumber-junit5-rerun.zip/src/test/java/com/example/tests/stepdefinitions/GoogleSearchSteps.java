package com.example.tests.stepdefinitions;

import io.cucumber.java.en.*;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.assertj.core.api.Assertions.assertThat;

public class GoogleSearchSteps extends PageObject {

    @FindBy(name = "q")
    WebElement searchBox;

    @Given("I open the Google homepage")
    public void openGoogle() {
        getDriver().get("https://www.google.com");
    }

    @When("I search for {string}")
    public void searchFor(String keyword) {
        searchBox.sendKeys(keyword);
        searchBox.sendKeys(Keys.ENTER);
    }

    @Then("the page title should contain {string}")
    public void verifyTitle(String keyword) {
        assertThat(getDriver().getTitle()).containsIgnoringCase(keyword);
    }
}
