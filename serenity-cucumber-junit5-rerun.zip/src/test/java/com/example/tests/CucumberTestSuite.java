package com.example.tests;

import org.junit.platform.suite.api.*;

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features")
@ConfigurationParameters({
    @ConfigurationParameter(key = "cucumber.plugin", value = "pretty, rerun:target/failed-rerun.txt"),
    @ConfigurationParameter(key = "cucumber.glue", value = "com.example.tests.stepdefinitions")
})
public class CucumberTestSuite {}
