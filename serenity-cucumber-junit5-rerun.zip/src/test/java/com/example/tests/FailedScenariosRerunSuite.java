package com.example.tests;

import org.junit.platform.suite.api.*;

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features")
@ConfigurationParameters({
    @ConfigurationParameter(key = "cucumber.plugin", value = "pretty"),
    @ConfigurationParameter(key = "cucumber.glue", value = "com.example.tests.stepdefinitions"),
    @ConfigurationParameter(key = "cucumber.features", value = "@target/failed-rerun.txt")
})
public class FailedScenariosRerunSuite {}
