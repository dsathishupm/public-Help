
window.addEventListener('message', async (event) => {
  if (event.data.type !== 'GENERATE_POM') return;

  const elements = Array.from(document.querySelectorAll('input:not([type=hidden]), select, textarea, button, [role=button], [role=checkbox], [role=radio], [role=textbox]'))
    .filter(el =>
      el.offsetParent !== null &&
      !el.shadowRoot
    );

  const locators = [];

  elements.forEach((el, index) => {
    const label = getLabel(el);
    if (!label || label.length > 60) return;

    const base = label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 50);
    const tag = el.tagName.toLowerCase();
    const type = el.getAttribute('type') || '';
    const role = el.getAttribute('role') || '';

    let suffix = 'element';
    if ((tag === 'input' && type === 'checkbox') || role === 'checkbox') suffix = 'checkbox';
    else if ((tag === 'input' && type === 'radio') || role === 'radio') suffix = 'radio';
    else if (tag === 'input' || tag === 'textarea' || role === 'textbox') suffix = 'textfield';
    else if (tag === 'select') suffix = 'dropdown';
    else if (tag === 'button' || role === 'button') suffix = 'button';

    const varName = `${base}_${suffix}`;
    const xpath = getRelativeXPath(el);
    const locator = `page.locator('//${xpath}')`;

    let action = 'click';
    if (suffix === 'textfield') action = 'fill';
    else if (suffix === 'dropdown') action = 'selectOption';
    else if (suffix === 'checkbox') action = 'check';

    locators.push({ name: varName, label, locator, action });
  });

  const className = document.title?.replace(/\W+/g, '') || 'Page';

  const content = generatePlaywrightPOM(className, locators);
  const blob = new Blob([content], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${className}.ts`;
  a.click();
});

function getLabel(el) {
  const id = el.getAttribute('id');
  const labelEl = id ? document.querySelector(`label[for="${id}"]`) : null;
  return el.getAttribute('aria-label') ||
         el.getAttribute('placeholder') ||
         el.getAttribute('name') ||
         el.getAttribute('id') ||
         labelEl?.innerText?.trim() ||
         el.innerText?.trim() || null;
}

function getRelativeXPath(el) {
  if (el.id) return `*[@id="${el.id}"]`;
  const parts = [];
  while (el && el.nodeType === 1 && el.tagName.toLowerCase() !== 'html') {
    let index = 1, sibling = el.previousElementSibling;
    while (sibling) {
      if (sibling.tagName === el.tagName) index++;
      sibling = sibling.previousElementSibling;
    }
    parts.unshift(`${el.tagName.toLowerCase()}[${index}]`);
    el = el.parentElement;
  }
  return parts.join('/');
}

function generatePlaywrightPOM(className, locators) {
  const fields = locators.map(loc => `  readonly ${loc.name}: Locator;`).join('\n');
  const assigns = locators.map(loc => `    this.${loc.name} = ${loc.locator};`).join('\n');
  const methods = locators.map(loc => {
    const fn = loc.action === 'fill' ? `fill_${loc.name}(value: string)` :
                loc.action === 'selectOption' ? `select_${loc.name}(option: string)` :
                `click_${loc.name}()`;
    const body = loc.action === 'fill' ? `this.${loc.name}.fill(value);` :
                 loc.action === 'selectOption' ? `this.${loc.name}.selectOption(option);` :
                 `this.${loc.name}.click();`;
    return `  async ${fn} {
    await ${body}
  }`;
  }).join('\n\n');

  return `import { Page, Locator } from '@playwright/test';

export class ${className} {
  readonly page: Page;
${fields}

  constructor(page: Page) {
    this.page = page;
${assigns}
  }

${methods}
}`;
}
