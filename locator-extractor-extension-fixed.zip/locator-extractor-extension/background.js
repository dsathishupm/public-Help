let extractedLocatorsGlobal = [];

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'LOCATORS_EXTRACTED') {
    extractedLocatorsGlobal = message.locators;
    console.log('Locators stored in background:', extractedLocatorsGlobal);
    sendResponse({ status: 'stored' });
  }

  if (message.type === 'GET_LOCATORS') {
    sendResponse({ locators: extractedLocatorsGlobal });
  }

  return true; // keep channel open
});