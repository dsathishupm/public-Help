// 
// Decompiled by Procyon v0.5.36
// 

package com.primatest.ui;

import javax.swing.ListCellRenderer;
import javax.swing.event.ListDataEvent;
import javax.swing.ComboBoxModel;
import javax.swing.plaf.ComboBoxUI;
import javax.swing.ComboBoxEditor;
import javax.swing.event.PopupMenuListener;
import org.openqa.selenium.NoSuchWindowException;
import java.util.concurrent.TimeUnit;
import java.beans.PropertyChangeSupport;
import java.util.Iterator;
import javax.swing.SwingWorker;
import javax.swing.plaf.ComponentUI;
import javax.swing.ButtonModel;
import javax.swing.ComponentInputMap;
import javax.swing.JToolTip;
import javax.swing.InputMap;
import javax.swing.event.AncestorListener;
import javax.swing.ActionMap;
import javax.swing.KeyStroke;
import java.awt.event.ItemEvent;
import javax.swing.event.ChangeListener;
import javax.swing.InputVerifier;
import javax.swing.border.Border;
import javax.swing.plaf.ButtonUI;
import javax.swing.Icon;
import javax.swing.Action;
import java.awt.event.ItemListener;
import java.beans.VetoableChangeListener;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Clipboard;
import java.awt.MenuComponent;
import javax.accessibility.AccessibleContext;
import java.awt.image.VolatileImage;
import java.awt.ImageCapabilities;
import java.awt.event.InputMethodEvent;
import java.awt.AWTKeyStroke;
import java.awt.FontMetrics;
import java.awt.BufferCapabilities;
import java.util.ResourceBundle;
import java.awt.event.MouseEvent;
import java.awt.image.ImageObserver;
import java.awt.im.InputContext;
import java.awt.event.KeyListener;
import java.awt.event.HierarchyEvent;
import java.awt.image.ImageProducer;
import java.awt.event.FocusEvent;
import java.io.PrintStream;
import java.awt.im.InputMethodRequests;
import java.awt.event.WindowFocusListener;
import javax.swing.TransferHandler;
import java.io.PrintWriter;
import java.awt.MenuBar;
import java.awt.Insets;
import java.awt.image.BufferStrategy;
import java.awt.event.InputMethodListener;
import java.awt.Font;
import java.awt.Dialog;
import java.awt.PopupMenu;
import java.awt.event.HierarchyBoundsListener;
import java.awt.Color;
import java.awt.FocusTraversalPolicy;
import java.util.List;
import java.awt.PointerInfo;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.AWTEvent;
import java.awt.event.ComponentEvent;
import javax.swing.JLayeredPane;
import java.awt.event.ComponentListener;
import java.awt.image.ColorModel;
import java.awt.event.ContainerListener;
import java.awt.event.ContainerEvent;
import javax.accessibility.AccessibleStateSet;
import java.awt.Shape;
import java.awt.event.MouseWheelEvent;
import javax.swing.JRootPane;
import java.util.Locale;
import java.beans.PropertyChangeListener;
import java.lang.ref.WeakReference;
import sun.java2d.pipe.Region;
import java.awt.peer.ComponentPeer;
import java.awt.Image;
import java.awt.Event;
import java.awt.dnd.DropTarget;
import java.awt.LayoutManager;
import java.util.Set;
import java.awt.Toolkit;
import java.awt.Rectangle;
import java.awt.GraphicsConfiguration;
import java.awt.event.WindowStateListener;
import java.awt.Cursor;
import javax.accessibility.Accessible;
import java.awt.Component;
import java.awt.Point;
import java.security.AccessControlContext;
import java.awt.Window;
import java.awt.Graphics;
import java.awt.event.FocusListener;
import java.awt.event.MouseWheelListener;
import java.awt.Dimension;
import java.awt.ComponentOrientation;
import java.awt.event.HierarchyListener;
import java.awt.Container;
import javax.swing.SwingUtilities;
import java.io.StringReader;
import org.xml.sax.InputSource;
import org.apache.html.dom.HTMLDocumentImpl;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeNode;
import javax.xml.xpath.XPathConstants;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.xerces.dom.CommentImpl;
import org.apache.xerces.dom.TextImpl;
import org.codehaus.groovy.runtime.ArrayUtil;
import javax.swing.JOptionPane;
import java.awt.event.WindowEvent;
import java.awt.event.InputEvent;
import java.awt.MouseInfo;
import java.awt.Robot;
import javax.swing.JScrollPane;
import javax.swing.tree.DefaultTreeCellRenderer;
import groovy.lang.Closure;
import org.codehaus.groovy.runtime.GeneratedClosure;
import groovy.lang.Reference;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.ImageIcon;
import org.codehaus.groovy.runtime.BytecodeInterface8;
import javax.swing.JPopupMenu;
import org.gpl.JSplitButton.action.SplitButtonActionListener;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import java.awt.event.KeyEvent;
import org.codehaus.groovy.runtime.callsite.CallSiteArray;
import org.codehaus.groovy.runtime.GStringImpl;
import org.codehaus.groovy.runtime.callsite.CallSite;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import net.miginfocom.swing.MigLayout;
import javax.swing.UIManager;
import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
import javax.xml.xpath.XPathFactory;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import java.io.File;
import java.lang.ref.SoftReference;
import groovy.lang.MetaClass;
import org.codehaus.groovy.reflection.ClassInfo;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import org.gpl.JSplitButton.JSplitButton;
import javax.swing.JLabel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JTree;
import javax.swing.JButton;
import javax.swing.JTextField;
import org.cyberneko.html.parsers.DOMParser;
import com.primatest.objectfinder.LookingGlass;
import groovy.lang.GroovyObject;
import java.awt.event.WindowListener;
import javax.swing.JFrame;

public class MainWindow extends JFrame implements WindowListener, GroovyObject
{
    public LookingGlass glass;
    public Object jarPath;
    public CodeTab codeTab;
    private DOMParser parser;
    public Object xpath;
    public String SelectedBrowser;
    public JTextField idField;
    public JButton pointerBtn;
    public JTree DOMtree;
    public DefaultMutableTreeNode rootNode;
    public boolean lookingForObject;
    public MainWindow mainWindow;
    public Object uiToXMLHash;
    public Object alreadyIncludedHash;
    public Object ShownElement;
    public boolean autoSelect;
    public JLabel infoLabel;
    public JSplitButton performActionBtn;
    public JComboBox idTypeList;
    private JCheckBoxMenuItem alwaysOnTop;
    private JMenuBar menubar;
    private JMenu fileMenu;
    private JButton startBtn;
    private IDEView ideView;
    private static /* synthetic */ ClassInfo $staticClassInfo;
    public static transient /* synthetic */ boolean __$stMC;
    private transient /* synthetic */ MetaClass metaClass;
    public static /* synthetic */ long __timeStamp;
    public static /* synthetic */ long __timeStamp__239_neverHappen1397742965754;
    private static /* synthetic */ SoftReference $callSiteArray;
    
    public MainWindow() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        this.jarPath = $getCallSiteArray[0].callGetProperty($getCallSiteArray[1].callGetProperty($getCallSiteArray[2].callConstructor(File.class, $getCallSiteArray[3].call($getCallSiteArray[4].call($getCallSiteArray[5].call($getCallSiteArray[6].call($getCallSiteArray[7].callGroovyObjectGetProperty(this))))))));
        this.parser = (DOMParser)ScriptBytecodeAdapter.castToType($getCallSiteArray[8].callConstructor(DOMParser.class), DOMParser.class);
        this.xpath = $getCallSiteArray[9].call($getCallSiteArray[10].call(XPathFactory.class));
        this.SelectedBrowser = "Firefox";
        this.lookingForObject = false;
        this.mainWindow = this;
        this.uiToXMLHash = ScriptBytecodeAdapter.createMap(new Object[0]);
        this.alreadyIncludedHash = ScriptBytecodeAdapter.createMap(new Object[0]);
        this.ShownElement = null;
        this.autoSelect = false;
        this.metaClass = this.$getStaticMetaClass();
        if (!DefaultTypeTransformation.booleanUnbox($getCallSiteArray[11].call($getCallSiteArray[12].callConstructor(File.class, $getCallSiteArray[13].call(this.jarPath, "/images"))))) {
            this.jarPath = $getCallSiteArray[14].call(System.class, "user.dir");
        }
        $getCallSiteArray[15].call(UIManager.class, $getCallSiteArray[16].call(UIManager.class));
        $getCallSiteArray[17].callCurrent(this, "Looking Glass");
        $getCallSiteArray[18].callCurrent(this, 800, 500);
        $getCallSiteArray[19].callCurrent(this, (Object)null);
        $getCallSiteArray[20].callCurrent(this, $getCallSiteArray[21].callGroovyObjectGetProperty(this));
        $getCallSiteArray[22].callCurrent(this, this);
        $getCallSiteArray[23].callCurrent(this, $getCallSiteArray[24].callConstructor(MigLayout.class));
        this.menubar = (JMenuBar)ScriptBytecodeAdapter.castToType($getCallSiteArray[25].callConstructor(JMenuBar.class), JMenuBar.class);
        final JMenu browserMenu = (JMenu)ScriptBytecodeAdapter.castToType($getCallSiteArray[26].callConstructor(JMenu.class, "Browsers"), JMenu.class);
        final JMenuItem fireFoxMenuItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[27].callConstructor(JMenuItem.class, "Start Firefox"), JMenuItem.class);
        $getCallSiteArray[28].call(fireFoxMenuItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent event) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                ScriptBytecodeAdapter.setGroovyObjectProperty("Firefox", MainWindow$1.class, this, "SelectedBrowser");
                $getCallSiteArray[0].callCurrent(this);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$1.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$1.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$1.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$1.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = { null };
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$1.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$1.$callSiteArray == null || ($createCallSiteArray = MainWindow$1.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$1.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final JMenuItem chromeMenuItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[29].callConstructor(JMenuItem.class, "Start Chrome"), JMenuItem.class);
        $getCallSiteArray[30].call(chromeMenuItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent event) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                ScriptBytecodeAdapter.setGroovyObjectProperty("Chrome", MainWindow$2.class, this, "SelectedBrowser");
                $getCallSiteArray[0].callCurrent(this);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$2.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$2.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$2.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$2.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = { null };
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$2.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$2.$callSiteArray == null || ($createCallSiteArray = MainWindow$2.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$2.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final JMenuItem ieMenuItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[31].callConstructor(JMenuItem.class, "Internet Explorer"), JMenuItem.class);
        $getCallSiteArray[32].call(ieMenuItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent event) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                ScriptBytecodeAdapter.setGroovyObjectProperty("Internet Explorer", MainWindow$3.class, this, "SelectedBrowser");
                $getCallSiteArray[0].callCurrent(this);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$3.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$3.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$3.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$3.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = { null };
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$3.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$3.$callSiteArray == null || ($createCallSiteArray = MainWindow$3.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$3.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final JMenuItem safariMenuItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[33].callConstructor(JMenuItem.class, "Start Safari"), JMenuItem.class);
        $getCallSiteArray[34].call(safariMenuItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent event) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                ScriptBytecodeAdapter.setGroovyObjectProperty("Safari", MainWindow$4.class, this, "SelectedBrowser");
                $getCallSiteArray[0].callCurrent(this);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$4.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$4.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$4.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$4.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = { null };
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$4.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$4.$callSiteArray == null || ($createCallSiteArray = MainWindow$4.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$4.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        this.fileMenu = (JMenu)ScriptBytecodeAdapter.castToType($getCallSiteArray[35].callConstructor(JMenu.class, "File"), JMenu.class);
        $getCallSiteArray[36].call(this.fileMenu, $getCallSiteArray[37].callGetProperty(KeyEvent.class));
        $getCallSiteArray[38].call(browserMenu, $getCallSiteArray[39].callGetProperty(KeyEvent.class));
        $getCallSiteArray[40].call(browserMenu, fireFoxMenuItem);
        $getCallSiteArray[41].call(browserMenu, chromeMenuItem);
        $getCallSiteArray[42].call(browserMenu, ieMenuItem);
        $getCallSiteArray[43].call(browserMenu, safariMenuItem);
        final JMenuItem eMenuItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[44].callConstructor(JMenuItem.class, "Exit"), JMenuItem.class);
        this.alwaysOnTop = (JCheckBoxMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[45].callConstructor(JCheckBoxMenuItem.class, "Always On Top"), JCheckBoxMenuItem.class);
        $getCallSiteArray[46].call(this.alwaysOnTop, true);
        $getCallSiteArray[47].call(eMenuItem, $getCallSiteArray[48].callGetProperty(KeyEvent.class));
        $getCallSiteArray[49].call(eMenuItem, "Exit application");
        $getCallSiteArray[50].call(eMenuItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent event) {
                $getCallSiteArray()[0].call(System.class, 0);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$5.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$5.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$5.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$5.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = { null };
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$5.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$5.$callSiteArray == null || ($createCallSiteArray = MainWindow$5.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$5.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        $getCallSiteArray[51].call(this.alwaysOnTop, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent event) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[0].callCurrent(this))) {
                    $getCallSiteArray[1].callCurrent(this, false);
                }
                else {
                    $getCallSiteArray[2].callCurrent(this, true);
                }
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$6.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$6.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$6.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$6.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[3];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$6.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$6.$callSiteArray == null || ($createCallSiteArray = MainWindow$6.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$6.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        $getCallSiteArray[52].call(this.fileMenu, this.alwaysOnTop);
        $getCallSiteArray[53].call(this.fileMenu, eMenuItem);
        $getCallSiteArray[54].call(this.menubar, this.fileMenu);
        $getCallSiteArray[55].call(this.menubar, browserMenu);
        final JPanel mainPanel = (JPanel)ScriptBytecodeAdapter.castToType($getCallSiteArray[56].callConstructor(JPanel.class), JPanel.class);
        final JPanel commonPanel = (JPanel)ScriptBytecodeAdapter.castToType($getCallSiteArray[57].callConstructor(JPanel.class), JPanel.class);
        final JPanel midPanel = (JPanel)ScriptBytecodeAdapter.castToType($getCallSiteArray[58].callConstructor(JPanel.class), JPanel.class);
        final JPanel topPanel = (JPanel)ScriptBytecodeAdapter.castToType($getCallSiteArray[59].callConstructor(JPanel.class), JPanel.class);
        final JPanel botPanel = (JPanel)ScriptBytecodeAdapter.castToType($getCallSiteArray[60].callConstructor(JPanel.class), JPanel.class);
        $getCallSiteArray[61].call(commonPanel, $getCallSiteArray[62].callConstructor(MigLayout.class));
        $getCallSiteArray[63].call(midPanel, $getCallSiteArray[64].callConstructor(MigLayout.class));
        $getCallSiteArray[65].call(mainPanel, $getCallSiteArray[66].callConstructor(MigLayout.class));
        $getCallSiteArray[67].call(topPanel, $getCallSiteArray[68].callConstructor(MigLayout.class));
        $getCallSiteArray[69].call(botPanel, $getCallSiteArray[70].callConstructor(MigLayout.class));
        final JTabbedPane tabbedPane = (JTabbedPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[71].callConstructor(JTabbedPane.class), JTabbedPane.class);
        $getCallSiteArray[72].call(tabbedPane, "Inspector", mainPanel);
        this.codeTab = (CodeTab)ScriptBytecodeAdapter.castToType($getCallSiteArray[73].callConstructor(CodeTab.class, this), CodeTab.class);
        $getCallSiteArray[74].call(tabbedPane, "Code", this.codeTab);
        $getCallSiteArray[75].callCurrent(this, tabbedPane);
        final String[] idStrings = (String[])ScriptBytecodeAdapter.castToType(ScriptBytecodeAdapter.createList(new Object[] { "XPath", "ID", "Name", "CSS Selector", "Class Name", "Tag Name", "Link Text", "Partial Link Text" }), String[].class);
        final JComboBox browserList = (JComboBox)ScriptBytecodeAdapter.castToType($getCallSiteArray[76].callConstructor(browserTypeList.class, this), JComboBox.class);
        this.idTypeList = (JComboBox)ScriptBytecodeAdapter.castToType($getCallSiteArray[77].callConstructor(JComboBox.class, (Object)idStrings), JComboBox.class);
        $getCallSiteArray[78].call(this.idTypeList, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent e) {
                $getCallSiteArray()[0].callCurrent(this);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$7.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$7.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$7.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$7.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = { null };
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$7.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$7.$callSiteArray == null || ($createCallSiteArray = MainWindow$7.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$7.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        this.performActionBtn = (JSplitButton)ScriptBytecodeAdapter.castToType($getCallSiteArray[79].callConstructor(JSplitButton.class, "Validate  "), JSplitButton.class);
        $getCallSiteArray[80].call(this.performActionBtn, new SplitButtonActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void buttonClicked(final ActionEvent actionEvent) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[0].call($getCallSiteArray[1].call($getCallSiteArray[2].callGroovyObjectGetProperty(this)), "Validate"))) {
                    $getCallSiteArray[3].callCurrent(this, "highlight");
                }
                else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[4].call($getCallSiteArray[5].call($getCallSiteArray[6].callGroovyObjectGetProperty(this)), "Click"))) {
                    $getCallSiteArray[7].callCurrent(this, "click");
                }
                else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[8].call($getCallSiteArray[9].call($getCallSiteArray[10].callGroovyObjectGetProperty(this)), "Type"))) {
                    $getCallSiteArray[11].callCurrent(this, "type");
                }
            }
            
            public void splitButtonClicked(final ActionEvent actionEvent) {
                $getCallSiteArray();
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$8.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$8.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$8.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$8.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[12];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$8.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$8.$callSiteArray == null || ($createCallSiteArray = MainWindow$8.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$8.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final JPopupMenu popupMenu = (JPopupMenu)ScriptBytecodeAdapter.castToType($getCallSiteArray[81].callConstructor(JPopupMenu.class), JPopupMenu.class);
        final JMenuItem clickItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[82].callConstructor(JMenuItem.class, "Click"), JMenuItem.class);
        $getCallSiteArray[83].call(clickItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent actionEvent) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                $getCallSiteArray[0].call($getCallSiteArray[1].callGroovyObjectGetProperty(this), "Click ");
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$9.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$9.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$9.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$9.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[2];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$9.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$9.$callSiteArray == null || ($createCallSiteArray = MainWindow$9.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$9.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final JMenuItem validateItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[84].callConstructor(JMenuItem.class, "Validate"), JMenuItem.class);
        $getCallSiteArray[85].call(validateItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent actionEvent) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                $getCallSiteArray[0].call($getCallSiteArray[1].callGroovyObjectGetProperty(this), "Validate ");
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$10.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$10.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$10.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$10.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[2];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$10.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$10.$callSiteArray == null || ($createCallSiteArray = MainWindow$10.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$10.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final JMenuItem typeItem = (JMenuItem)ScriptBytecodeAdapter.castToType($getCallSiteArray[86].callConstructor(JMenuItem.class, "Type"), JMenuItem.class);
        $getCallSiteArray[87].call(typeItem, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent actionEvent) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                $getCallSiteArray[0].call($getCallSiteArray[1].callGroovyObjectGetProperty(this), "Type ");
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$11.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$11.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$11.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$11.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[2];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$11.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$11.$callSiteArray == null || ($createCallSiteArray = MainWindow$11.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$11.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        $getCallSiteArray[88].call(popupMenu, validateItem);
        $getCallSiteArray[89].call(popupMenu, clickItem);
        $getCallSiteArray[90].call(popupMenu, typeItem);
        $getCallSiteArray[91].call(this.performActionBtn, popupMenu);
        this.idField = (JTextField)ScriptBytecodeAdapter.castToType($getCallSiteArray[92].callConstructor(JTextField.class, 500), JTextField.class);
        this.infoLabel = (JLabel)ScriptBytecodeAdapter.castToType($getCallSiteArray[93].callConstructor(JLabel.class, "<html><font color=blue>Select Browser Type and click Open button.</font></html>"), JLabel.class);
        this.startBtn = (JButton)ScriptBytecodeAdapter.castToType($getCallSiteArray[94].callConstructor(startBtn.class, this, "Open"), JButton.class);
        ImageIcon pointerBtnIcon = null;
        if (!BytecodeInterface8.disabledStandardMetaClass()) {
            pointerBtnIcon = this.createImageIcon("images/find.png");
        }
        else {
            pointerBtnIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[95].callCurrent(this, "images/find.png"), ImageIcon.class);
        }
        ImageIcon copyBtnIcon = null;
        if (!BytecodeInterface8.disabledStandardMetaClass()) {
            copyBtnIcon = this.createImageIcon("images/copy.png");
        }
        else {
            copyBtnIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[96].callCurrent(this, "images/copy.png"), ImageIcon.class);
        }
        this.pointerBtn = (JButton)ScriptBytecodeAdapter.castToType($getCallSiteArray[97].callConstructor(pointerBtn.class, this, "", pointerBtnIcon), JButton.class);
        final JButton copyBtn = (JButton)ScriptBytecodeAdapter.castToType($getCallSiteArray[98].callConstructor(copyBtn.class, this, "", copyBtnIcon), JButton.class);
        $getCallSiteArray[99].call(this.pointerBtn, false);
        this.rootNode = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[100].callConstructor(DefaultMutableTreeNode.class, " <HTML>"), DefaultMutableTreeNode.class);
        final DefaultTreeModel treeModel = (DefaultTreeModel)ScriptBytecodeAdapter.castToType($getCallSiteArray[101].callConstructor(DefaultTreeModel.class, this.rootNode), DefaultTreeModel.class);
        this.DOMtree = (JTree)ScriptBytecodeAdapter.castToType($getCallSiteArray[102].callConstructor(JTree.class, treeModel), JTree.class);
        $getCallSiteArray[103].call($getCallSiteArray[104].call(this.DOMtree), $getCallSiteArray[105].callGetProperty(TreeSelectionModel.class));
        $getCallSiteArray[106].call(this.DOMtree, new TreeSelectionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            public static transient /* synthetic */ boolean __$stMC;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void valueChanged(final TreeSelectionEvent e) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                if (BytecodeInterface8.isOrigZ() && !MainWindow$12.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                    if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[1].callGroovyObjectGetProperty(this), true)) {
                        return;
                    }
                }
                else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[0].callGroovyObjectGetProperty(this), true)) {
                    return;
                }
                final Reference node = new Reference(ScriptBytecodeAdapter.castToType($getCallSiteArray[2].call($getCallSiteArray[3].callGroovyObjectGetProperty(this)), DefaultMutableTreeNode.class));
                if (BytecodeInterface8.isOrigZ() && !MainWindow$12.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                    if (ScriptBytecodeAdapter.compareEqual(node.get(), null)) {
                        return;
                    }
                }
                else if (ScriptBytecodeAdapter.compareEqual(node.get(), null)) {
                    return;
                }
                final Object domnode = $getCallSiteArray[4].call($getCallSiteArray[5].callGroovyObjectGetProperty(this), new GeneratedClosure((Object)this, (Object)this) {
                    public static transient /* synthetic */ boolean __$stMC;
                    private static /* synthetic */ SoftReference $callSiteArray;
                    
                    public Object doCall(final Object it) {
                        final CallSite[] $getCallSiteArray = $getCallSiteArray();
                        if (BytecodeInterface8.isOrigZ() && !MainWindow$_12_valueChanged_closure1.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                            return ScriptBytecodeAdapter.compareEqual($getCallSiteArray[1].callGetProperty(it), node.get());
                        }
                        return ScriptBytecodeAdapter.compareEqual($getCallSiteArray[0].callGetProperty(it), node.get());
                    }
                    
                    public DefaultMutableTreeNode getNode() {
                        $getCallSiteArray();
                        return (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType(node.get(), DefaultMutableTreeNode.class);
                    }
                    
                    public Object doCall() {
                        $getCallSiteArray();
                        return this.doCall(null);
                    }
                    
                    public static /* synthetic */ void __$swapInit() {
                        $getCallSiteArray();
                        MainWindow$_12_valueChanged_closure1.$callSiteArray = null;
                    }
                    
                    static {
                        __$swapInit();
                    }
                    
                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                        final String[] names = new String[2];
                        $createCallSiteArray_1(names);
                        return new CallSiteArray(MainWindow$_12_valueChanged_closure1.class, names);
                    }
                    
                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                        CallSiteArray $createCallSiteArray;
                        if (MainWindow$_12_valueChanged_closure1.$callSiteArray == null || ($createCallSiteArray = MainWindow$_12_valueChanged_closure1.$callSiteArray.get()) == null) {
                            $createCallSiteArray = $createCallSiteArray();
                            MainWindow$_12_valueChanged_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                        }
                        return $createCallSiteArray.array;
                    }
                });
                if (BytecodeInterface8.isOrigZ() && !MainWindow$12.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                    if (ScriptBytecodeAdapter.compareEqual(domnode, null)) {
                        return;
                    }
                }
                else if (ScriptBytecodeAdapter.compareEqual(domnode, null)) {
                    return;
                }
                ScriptBytecodeAdapter.setGroovyObjectProperty($getCallSiteArray[6].call($getCallSiteArray[7].callGroovyObjectGetProperty(this), $getCallSiteArray[8].callCurrent(this, $getCallSiteArray[9].callGetProperty(domnode))), MainWindow$12.class, this, "ShownElement");
                $getCallSiteArray[10].callCurrent(this);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$12.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$12.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$12.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$12.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[11];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$12.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$12.$callSiteArray == null || ($createCallSiteArray = MainWindow$12.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$12.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer)ScriptBytecodeAdapter.castToType($getCallSiteArray[107].call(this.DOMtree), DefaultTreeCellRenderer.class);
        $getCallSiteArray[108].call(renderer, (Object)null);
        $getCallSiteArray[109].call(renderer, (Object)null);
        $getCallSiteArray[110].call(renderer, (Object)null);
        $getCallSiteArray[111].call(this.DOMtree, true);
        $getCallSiteArray[112].call(this.DOMtree, true);
        final JScrollPane treeView = (JScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[113].callConstructor(JScrollPane.class, this.DOMtree), JScrollPane.class);
        $getCallSiteArray[114].call(topPanel, browserList);
        $getCallSiteArray[115].call(topPanel, this.startBtn);
        $getCallSiteArray[116].call(topPanel, this.pointerBtn);
        $getCallSiteArray[117].call(midPanel, this.idTypeList, "growx");
        $getCallSiteArray[118].call(midPanel, this.idField, "grow");
        $getCallSiteArray[119].call(midPanel, copyBtn);
        $getCallSiteArray[120].call(midPanel, this.performActionBtn);
        $getCallSiteArray[121].call(mainPanel, topPanel, "wrap");
        $getCallSiteArray[122].call(mainPanel, this.infoLabel, "span, grow, wrap");
        $getCallSiteArray[123].call(mainPanel, midPanel, "wrap");
        $getCallSiteArray[124].call(mainPanel, treeView, "span, grow,height 200:1200:");
        $getCallSiteArray[125].callCurrent(this, this.menubar);
        $getCallSiteArray[126].callCurrent(this, true);
    }
    
    protected ImageIcon createImageIcon(final String path) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        return (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[127].callConstructor(ImageIcon.class, $getCallSiteArray[128].call($getCallSiteArray[129].call(this.jarPath, "/"), path)), ImageIcon.class);
    }
    
    public Object stopRecording() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        $getCallSiteArray[130].callCurrent(this, $getCallSiteArray[131].callGroovyObjectGetProperty(this));
        if (!DefaultTypeTransformation.booleanUnbox($getCallSiteArray[132].callCurrent(this))) {
            $getCallSiteArray[133].callCurrent(this, true);
            $getCallSiteArray[134].callCurrent(this, false);
        }
        final Robot robot = (Robot)ScriptBytecodeAdapter.castToType($getCallSiteArray[135].callConstructor(Robot.class), Robot.class);
        $getCallSiteArray[136].callCurrent(this, 100);
        final Object mouseLocation = $getCallSiteArray[137].call($getCallSiteArray[138].call(MouseInfo.class));
        $getCallSiteArray[139].call(robot, $getCallSiteArray[140].call($getCallSiteArray[141].callCurrent(this), 50), $getCallSiteArray[142].call($getCallSiteArray[143].callCurrent(this), 20));
        $getCallSiteArray[144].call(robot, $getCallSiteArray[145].callGetProperty(InputEvent.class));
        $getCallSiteArray[146].call(robot, $getCallSiteArray[147].callGetProperty(InputEvent.class));
        $getCallSiteArray[148].call(robot, $getCallSiteArray[149].call($getCallSiteArray[150].callGetProperty(mouseLocation)), $getCallSiteArray[151].call($getCallSiteArray[152].callGetProperty(mouseLocation)));
        $getCallSiteArray[153].call(this.fileMenu, false);
        $getCallSiteArray[154].call(this.idField);
        $getCallSiteArray[155].call(this.infoLabel, "<html><font color=blue>Click on the looking glass and move mouse pointer to html element.</font></html>");
        return $getCallSiteArray[156].call(this.performActionBtn, true);
    }
    
    public void windowOpened(final WindowEvent e) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[157].call($getCallSiteArray[158].callConstructor(File.class, "lastCode.tmp")))) {
            $getCallSiteArray[159].call($getCallSiteArray[160].callGroovyObjectGetProperty(this.codeTab), $getCallSiteArray[161].callGetProperty($getCallSiteArray[162].callConstructor(File.class, "lastCode.tmp")));
            $getCallSiteArray[163].call($getCallSiteArray[164].callGroovyObjectGetProperty(this.codeTab), 0);
        }
        if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[165].call($getCallSiteArray[166].callConstructor(File.class, "lastImports.tmp")))) {
            ScriptBytecodeAdapter.setProperty($getCallSiteArray[167].callGetProperty($getCallSiteArray[168].callConstructor(File.class, "lastImports.tmp")), null, $getCallSiteArray[169].callGroovyObjectGetProperty(this.codeTab), "selectedImports");
        }
    }
    
    public void windowClosing(final WindowEvent windowEvent) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        $getCallSiteArray[170].call($getCallSiteArray[171].callConstructor(File.class, "lastCode.tmp"), $getCallSiteArray[172].call($getCallSiteArray[173].callGroovyObjectGetProperty(this.codeTab)));
        $getCallSiteArray[174].call($getCallSiteArray[175].callConstructor(File.class, "lastImports.tmp"), $getCallSiteArray[176].callGroovyObjectGetProperty(this.codeTab));
    }
    
    public void windowClosed(final WindowEvent e) {
        $getCallSiteArray()[177].call(System.class);
    }
    
    public void windowIconified(final WindowEvent windowEvent) {
        $getCallSiteArray();
    }
    
    public void windowDeiconified(final WindowEvent windowEvent) {
        $getCallSiteArray();
    }
    
    public void windowActivated(final WindowEvent windowEvent) {
        $getCallSiteArray();
    }
    
    public void windowDeactivated(final WindowEvent windowEvent) {
        $getCallSiteArray();
    }
    
    public Object startBrowser() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        $getCallSiteArray[178].call(this.startBtn, false);
        $getCallSiteArray[179].call(this.startBtn, "Opening...");
        final Object exceptionClosure = new GeneratedClosure(this, this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final Object ex) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                $getCallSiteArray[0].call(JOptionPane.class, $getCallSiteArray[1].callGroovyObjectGetProperty(this), $getCallSiteArray[2].call("Error starting browser: ", $getCallSiteArray[3].callGetProperty(ex)), "Error", $getCallSiteArray[4].callGetProperty(JOptionPane.class));
                $getCallSiteArray[5].call($getCallSiteArray[6].callGroovyObjectGetProperty(this), true);
                return $getCallSiteArray[7].call($getCallSiteArray[8].callGroovyObjectGetProperty(this), "Open");
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$_startBrowser_closure1.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[9];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$_startBrowser_closure1.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$_startBrowser_closure1.$callSiteArray == null || ($createCallSiteArray = MainWindow$_startBrowser_closure1.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$_startBrowser_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        };
        ScriptBytecodeAdapter.setGroovyObjectProperty(this.glass = (LookingGlass)ScriptBytecodeAdapter.castToType($getCallSiteArray[180].callConstructor(LookingGlass.class, new GeneratedClosure((Object)this, (Object)this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final Object it) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                $getCallSiteArray[0].call($getCallSiteArray[1].callGroovyObjectGetProperty(this), true);
                $getCallSiteArray[2].call($getCallSiteArray[3].callGroovyObjectGetProperty(this), true);
                return $getCallSiteArray[4].call($getCallSiteArray[5].callGroovyObjectGetProperty(this), "Open");
            }
            
            public Object doCall() {
                $getCallSiteArray();
                return this.doCall(null);
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$_startBrowser_closure2.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[6];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$_startBrowser_closure2.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$_startBrowser_closure2.$callSiteArray == null || ($createCallSiteArray = MainWindow$_startBrowser_closure2.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$_startBrowser_closure2.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        }, exceptionClosure), LookingGlass.class), MainWindow.class, this.codeTab, "glass");
        $getCallSiteArray[181].call(this.infoLabel, "<html><font color=blue>Click on the looking glass and move mouse pointer to html element.</font></html>");
        ScriptBytecodeAdapter.setGroovyObjectProperty(this.SelectedBrowser, MainWindow.class, this.glass, "BrowserType");
        final Thread t = (Thread)ScriptBytecodeAdapter.castToType($getCallSiteArray[182].callConstructor(Thread.class, this.glass), Thread.class);
        return $getCallSiteArray[183].call(t);
    }
    
    public Object performElementAction(final String actionType) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[187].callGroovyObjectGetProperty(this.codeTab), true)) {
                $getCallSiteArray[188].call(JOptionPane.class, this.mainWindow, "Please stop recording in Code tab.", "Error", $getCallSiteArray[189].callGetProperty(JOptionPane.class));
                return null;
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[184].callGroovyObjectGetProperty(this.codeTab), true)) {
            $getCallSiteArray[185].call(JOptionPane.class, this.mainWindow, "Please stop recording in Code tab.", "Error", $getCallSiteArray[186].callGetProperty(JOptionPane.class));
            return null;
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual(this.glass, null)) {
                return null;
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual(this.glass, null)) {
            return null;
        }
        $getCallSiteArray[190].call(this.performActionBtn, false);
        $getCallSiteArray[191].call(this.infoLabel, "<html><font color=blue>Click on the looking glass and move mouse pointer to html element.</font></html>");
        final Object exceptionClosure = new GeneratedClosure(this, this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final Object ex) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                $getCallSiteArray[0].callCurrent(this, ex);
                return $getCallSiteArray[1].call(JOptionPane.class, $getCallSiteArray[2].callGroovyObjectGetProperty(this), $getCallSiteArray[3].call("Error interacting with element: ", $getCallSiteArray[4].callGetProperty(ex)), "Error", $getCallSiteArray[5].callGetProperty(JOptionPane.class));
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$_performElementAction_closure3.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[6];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$_performElementAction_closure3.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$_performElementAction_closure3.$callSiteArray == null || ($createCallSiteArray = MainWindow$_performElementAction_closure3.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$_performElementAction_closure3.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        };
        final Object response = $getCallSiteArray[192].call(this.glass, ArrayUtil.createArray($getCallSiteArray[193].call(this.idField), new GeneratedClosure((Object)this, (Object)this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final Object it) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                return $getCallSiteArray[0].callCurrent(this, $getCallSiteArray[1].call($getCallSiteArray[2].callGroovyObjectGetProperty(this)));
            }
            
            public Object doCall() {
                $getCallSiteArray();
                return this.doCall(null);
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$_performElementAction_closure4.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[3];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$_performElementAction_closure4.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$_performElementAction_closure4.$callSiteArray == null || ($createCallSiteArray = MainWindow$_performElementAction_closure4.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$_performElementAction_closure4.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        }, $getCallSiteArray[194].call(this.idTypeList), actionType, exceptionClosure));
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual(response, null)) {
                return null;
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual(response, null)) {
            return null;
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[198].callGetProperty(response), "")) {
                $getCallSiteArray[199].call(this.infoLabel, new GStringImpl(new Object[] { $getCallSiteArray[200].callGetProperty(response) }, new String[] { "<html>", "</html>" }));
            }
        }
        else if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[195].callGetProperty(response), "")) {
            $getCallSiteArray[196].call(this.infoLabel, new GStringImpl(new Object[] { $getCallSiteArray[197].callGetProperty(response) }, new String[] { "<html>", "</html>" }));
        }
        this.autoSelect = true;
        if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[201].callGetProperty(response))) {
            $getCallSiteArray[202].callCurrent(this, $getCallSiteArray[203].callGetProperty(response));
        }
        this.autoSelect = false;
        return $getCallSiteArray[204].call(this.performActionBtn, true);
    }
    
    public Object setIDValue() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[229].call(this.idTypeList), "XPath")) {
                return $getCallSiteArray[230].call(this.idField, $getCallSiteArray[231].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[232].call(this.idTypeList), "ID")) {
                return $getCallSiteArray[233].call(this.idField, $getCallSiteArray[234].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[235].call(this.idTypeList), "Name")) {
                return $getCallSiteArray[236].call(this.idField, $getCallSiteArray[237].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[238].call(this.idTypeList), "CSS Selector")) {
                return $getCallSiteArray[239].call(this.idField, $getCallSiteArray[240].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[241].call(this.idTypeList), "Class Name")) {
                return $getCallSiteArray[242].call(this.idField, $getCallSiteArray[243].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[244].call(this.idTypeList), "Tag Name")) {
                return $getCallSiteArray[245].call(this.idField, $getCallSiteArray[246].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[247].call(this.idTypeList), "Link Text")) {
                return $getCallSiteArray[248].call(this.idField, $getCallSiteArray[249].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[250].call(this.idTypeList), "Partial Link Text")) {
                return $getCallSiteArray[251].call(this.idField, $getCallSiteArray[252].callGetProperty(this.ShownElement));
            }
            return null;
        }
        else {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[205].call(this.idTypeList), "XPath")) {
                return $getCallSiteArray[206].call(this.idField, $getCallSiteArray[207].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[208].call(this.idTypeList), "ID")) {
                return $getCallSiteArray[209].call(this.idField, $getCallSiteArray[210].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[211].call(this.idTypeList), "Name")) {
                return $getCallSiteArray[212].call(this.idField, $getCallSiteArray[213].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[214].call(this.idTypeList), "CSS Selector")) {
                return $getCallSiteArray[215].call(this.idField, $getCallSiteArray[216].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[217].call(this.idTypeList), "Class Name")) {
                return $getCallSiteArray[218].call(this.idField, $getCallSiteArray[219].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[220].call(this.idTypeList), "Tag Name")) {
                return $getCallSiteArray[221].call(this.idField, $getCallSiteArray[222].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[223].call(this.idTypeList), "Link Text")) {
                return $getCallSiteArray[224].call(this.idField, $getCallSiteArray[225].callGetProperty(this.ShownElement));
            }
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[226].call(this.idTypeList), "Partial Link Text")) {
                return $getCallSiteArray[227].call(this.idField, $getCallSiteArray[228].callGetProperty(this.ShownElement));
            }
            return null;
        }
    }
    
    public Object addNodes(final Object domnode, final Object uinode) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[266].callGetProperty(domnode), TextImpl.class)) {
                Object trimmedData = $getCallSiteArray[267].call($getCallSiteArray[268].callGetProperty(domnode));
                trimmedData = $getCallSiteArray[269].call(trimmedData, "\n", "");
                if (ScriptBytecodeAdapter.compareNotEqual(trimmedData, "")) {
                    if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[270].call(this.alreadyIncludedHash, domnode), null) && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[271].call(this.alreadyIncludedHash, domnode), false)) {
                        final DefaultMutableTreeNode node = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[272].callConstructor(DefaultMutableTreeNode.class, $getCallSiteArray[273].callGetProperty(domnode)), DefaultMutableTreeNode.class);
                        $getCallSiteArray[274].call(uinode, node);
                    }
                    else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[275].call(this.alreadyIncludedHash, domnode), null)) {
                        final DefaultMutableTreeNode node2 = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[276].callConstructor(DefaultMutableTreeNode.class, $getCallSiteArray[277].callGetProperty(domnode)), DefaultMutableTreeNode.class);
                        $getCallSiteArray[278].call(uinode, node2);
                    }
                }
                return null;
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[253].callGetProperty(domnode), TextImpl.class)) {
            Object trimmedData2 = $getCallSiteArray[254].call($getCallSiteArray[255].callGetProperty(domnode));
            trimmedData2 = $getCallSiteArray[256].call(trimmedData2, "\n", "");
            if (ScriptBytecodeAdapter.compareNotEqual(trimmedData2, "")) {
                if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[257].call(this.alreadyIncludedHash, domnode), null) && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[258].call(this.alreadyIncludedHash, domnode), false)) {
                    final DefaultMutableTreeNode node3 = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[259].callConstructor(DefaultMutableTreeNode.class, $getCallSiteArray[260].callGetProperty(domnode)), DefaultMutableTreeNode.class);
                    $getCallSiteArray[261].call(uinode, node3);
                }
                else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[262].call(this.alreadyIncludedHash, domnode), null)) {
                    final DefaultMutableTreeNode node4 = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[263].callConstructor(DefaultMutableTreeNode.class, $getCallSiteArray[264].callGetProperty(domnode)), DefaultMutableTreeNode.class);
                    $getCallSiteArray[265].call(uinode, node4);
                }
            }
            return null;
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[280].callGetProperty(domnode), CommentImpl.class)) {
                return null;
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[279].callGetProperty(domnode), CommentImpl.class)) {
            return null;
        }
        Object uiText = new GStringImpl(new Object[] { $getCallSiteArray[281].call(domnode) }, new String[] { "<html><font color=C700FF> &lt;", "</font>" });
        final Reference attributes = new Reference((T)"");
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[286].call(domnode), null)) {
                $getCallSiteArray[287].call($getCallSiteArray[288].callGetProperty($getCallSiteArray[289].call(domnode)), new GeneratedClosure((Object)this, (Object)this) {
                    private /* synthetic */ Reference attributes;
                    private static /* synthetic */ SoftReference $callSiteArray;
                    
                    public Object doCall(final Object it) {
                        final CallSite[] $getCallSiteArray = $getCallSiteArray();
                        final Object value = $getCallSiteArray[0].call(StringEscapeUtils.class, $getCallSiteArray[1].callGetProperty(it));
                        final Object call = $getCallSiteArray[2].call($getCallSiteArray[3].call(this.attributes.get(), " "), new GStringImpl(new Object[] { $getCallSiteArray[4].callGetProperty(it), value }, new String[] { "<font color=FF8A13>", "=</font><font color=C700FF>\"</font><font color=blue>", "</font><font color=C700FF>\"</font>" }));
                        this.attributes.set(call);
                        return call;
                    }
                    
                    public Object getAttributes() {
                        $getCallSiteArray();
                        return this.attributes.get();
                    }
                    
                    public Object doCall() {
                        $getCallSiteArray();
                        return this.doCall(null);
                    }
                    
                    public static /* synthetic */ void __$swapInit() {
                        $getCallSiteArray();
                        MainWindow$_addNodes_closure5.$callSiteArray = null;
                    }
                    
                    static {
                        __$swapInit();
                    }
                    
                    private static /* synthetic */ void $createCallSiteArray_1(final String[] array) {
                        array[0] = "escapeHtml4";
                        array[1] = "value";
                        array[3] = (array[2] = "plus");
                        array[4] = "name";
                    }
                    
                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                        final String[] names = new String[5];
                        $createCallSiteArray_1(names);
                        return new CallSiteArray(MainWindow$_addNodes_closure5.class, names);
                    }
                    
                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                        CallSiteArray $createCallSiteArray;
                        if (MainWindow$_addNodes_closure5.$callSiteArray == null || ($createCallSiteArray = MainWindow$_addNodes_closure5.$callSiteArray.get()) == null) {
                            $createCallSiteArray = $createCallSiteArray();
                            MainWindow$_addNodes_closure5.$callSiteArray = new SoftReference($createCallSiteArray);
                        }
                        return $createCallSiteArray.array;
                    }
                });
            }
        }
        else if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[282].call(domnode), null)) {
            $getCallSiteArray[283].call($getCallSiteArray[284].callGetProperty($getCallSiteArray[285].call(domnode)), new GeneratedClosure((Object)this, (Object)this) {
                private /* synthetic */ Reference attributes = attributes;
                private static /* synthetic */ SoftReference $callSiteArray;
                
                public Object doCall(final Object it) {
                    final CallSite[] $getCallSiteArray = $getCallSiteArray();
                    final Object value = $getCallSiteArray[0].call(StringEscapeUtils.class, $getCallSiteArray[1].callGetProperty(it));
                    final Object call = $getCallSiteArray[2].call($getCallSiteArray[3].call(attributes.get(), " "), new GStringImpl(new Object[] { $getCallSiteArray[4].callGetProperty(it), value }, new String[] { "<font color=FF8A13>", "=</font><font color=C700FF>\"</font><font color=blue>", "</font><font color=C700FF>\"</font>" }));
                    attributes.set(call);
                    return call;
                }
                
                public Object getAttributes() {
                    $getCallSiteArray();
                    return attributes.get();
                }
                
                public Object doCall() {
                    $getCallSiteArray();
                    return this.doCall(null);
                }
                
                public static /* synthetic */ void __$swapInit() {
                    $getCallSiteArray();
                    MainWindow$_addNodes_closure5.$callSiteArray = null;
                }
                
                static {
                    __$swapInit();
                }
                
                private static /* synthetic */ void $createCallSiteArray_1(final String[] array) {
                    array[0] = "escapeHtml4";
                    array[1] = "value";
                    array[3] = (array[2] = "plus");
                    array[4] = "name";
                }
                
                private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                    final String[] names = new String[5];
                    $createCallSiteArray_1(names);
                    return new CallSiteArray(MainWindow$_addNodes_closure5.class, names);
                }
                
                private static /* synthetic */ CallSite[] $getCallSiteArray() {
                    CallSiteArray $createCallSiteArray;
                    if (MainWindow$_addNodes_closure5.$callSiteArray == null || ($createCallSiteArray = MainWindow$_addNodes_closure5.$callSiteArray.get()) == null) {
                        $createCallSiteArray = $createCallSiteArray();
                        MainWindow$_addNodes_closure5.$callSiteArray = new SoftReference($createCallSiteArray);
                    }
                    return $createCallSiteArray.array;
                }
            });
        }
        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[326].callGetProperty(domnode), null) && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[327].callGetProperty($getCallSiteArray[328].callGetProperty(domnode)), TextImpl.class)) {
                $getCallSiteArray[329].call(this.alreadyIncludedHash, $getCallSiteArray[330].callGetProperty(domnode), false);
                Object trimmedData3 = $getCallSiteArray[331].call($getCallSiteArray[332].callGetProperty($getCallSiteArray[333].callGetProperty(domnode)));
                trimmedData3 = $getCallSiteArray[334].call(trimmedData3, "\n", "");
                if (ScriptBytecodeAdapter.compareNotEqual(trimmedData3, "") && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[335].callGetProperty($getCallSiteArray[336].call(domnode)), 1)) {
                    uiText = $getCallSiteArray[337].call($getCallSiteArray[338].call($getCallSiteArray[339].call($getCallSiteArray[340].call(uiText, attributes.get()), "<font color=C700FF>&gt;</font>"), $getCallSiteArray[341].callGetProperty($getCallSiteArray[342].callGetProperty(domnode))), new GStringImpl(new Object[] { $getCallSiteArray[343].call(domnode) }, new String[] { "<font color=C700FF>&lt/", "</font><font color=C700FF>&gt;</font></html>" }));
                    $getCallSiteArray[344].call(this.alreadyIncludedHash, $getCallSiteArray[345].callGetProperty(domnode), true);
                }
                else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[346].callGetProperty($getCallSiteArray[347].call(domnode)), 1) && ScriptBytecodeAdapter.compareNotEqual(trimmedData3, "")) {
                    uiText = $getCallSiteArray[348].call($getCallSiteArray[349].call($getCallSiteArray[350].call($getCallSiteArray[351].call("  <font color=C700FF>&lt;", $getCallSiteArray[352].call(domnode)), "</font>"), attributes.get()), "<font color=C700FF>/&gt;</font></html>");
                }
                else {
                    uiText = $getCallSiteArray[353].call($getCallSiteArray[354].call(uiText, attributes.get()), "<font color=C700FF>&gt;</font></html>");
                }
            }
            else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[355].callGetProperty($getCallSiteArray[356].call(domnode)), 0)) {
                if (ScriptBytecodeAdapter.compareEqual(attributes.get(), "")) {
                    uiText = $getCallSiteArray[357].call(uiText, "<font color=C700FF>/&gt;</font></html>");
                }
                else {
                    uiText = $getCallSiteArray[358].call($getCallSiteArray[359].call(uiText, attributes.get()), "<font color=C700FF>/&gt;</font></html>");
                }
            }
            else {
                uiText = $getCallSiteArray[360].call($getCallSiteArray[361].call(uiText, attributes.get()), "<font color=C700FF>&gt;</font></html>");
            }
        }
        else if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[290].callGetProperty(domnode), null) && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[291].callGetProperty($getCallSiteArray[292].callGetProperty(domnode)), TextImpl.class)) {
            $getCallSiteArray[293].call(this.alreadyIncludedHash, $getCallSiteArray[294].callGetProperty(domnode), false);
            Object trimmedData4 = $getCallSiteArray[295].call($getCallSiteArray[296].callGetProperty($getCallSiteArray[297].callGetProperty(domnode)));
            trimmedData4 = $getCallSiteArray[298].call(trimmedData4, "\n", "");
            if (ScriptBytecodeAdapter.compareNotEqual(trimmedData4, "") && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[299].callGetProperty($getCallSiteArray[300].call(domnode)), 1)) {
                uiText = $getCallSiteArray[301].call($getCallSiteArray[302].call($getCallSiteArray[303].call($getCallSiteArray[304].call(uiText, attributes.get()), "<font color=C700FF>&gt;</font>"), $getCallSiteArray[305].callGetProperty($getCallSiteArray[306].callGetProperty(domnode))), new GStringImpl(new Object[] { $getCallSiteArray[307].call(domnode) }, new String[] { "<font color=C700FF>&lt/", "</font><font color=C700FF>&gt;</font></html>" }));
                $getCallSiteArray[308].call(this.alreadyIncludedHash, $getCallSiteArray[309].callGetProperty(domnode), true);
            }
            else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[310].callGetProperty($getCallSiteArray[311].call(domnode)), 1) && ScriptBytecodeAdapter.compareNotEqual(trimmedData4, "")) {
                uiText = $getCallSiteArray[312].call($getCallSiteArray[313].call($getCallSiteArray[314].call($getCallSiteArray[315].call("  <font color=C700FF>&lt;", $getCallSiteArray[316].call(domnode)), "</font>"), attributes.get()), "<font color=C700FF>/&gt;</font></html>");
            }
            else {
                uiText = $getCallSiteArray[317].call($getCallSiteArray[318].call(uiText, attributes.get()), "<font color=C700FF>&gt;</font></html>");
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[319].callGetProperty($getCallSiteArray[320].call(domnode)), 0)) {
            if (ScriptBytecodeAdapter.compareEqual(attributes.get(), "")) {
                uiText = $getCallSiteArray[321].call(uiText, "<font color=C700FF>/&gt;</font></html>");
            }
            else {
                uiText = $getCallSiteArray[322].call($getCallSiteArray[323].call(uiText, attributes.get()), "<font color=C700FF>/&gt;</font></html>");
            }
        }
        else {
            uiText = $getCallSiteArray[324].call($getCallSiteArray[325].call(uiText, attributes.get()), "<font color=C700FF>&gt;</font></html>");
        }
        final DefaultMutableTreeNode node5 = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[362].callConstructor(DefaultMutableTreeNode.class, uiText), DefaultMutableTreeNode.class);
        $getCallSiteArray[363].call(uinode, node5);
        $getCallSiteArray[364].call(this.uiToXMLHash, domnode, node5);
        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            for (int i = 0; ScriptBytecodeAdapter.compareLessThan(i, $getCallSiteArray[386].callGetProperty($getCallSiteArray[387].call(domnode))); i++) {
                $getCallSiteArray[388].callCurrent(this, $getCallSiteArray[389].call($getCallSiteArray[390].call(domnode), i), node5);
                if (ScriptBytecodeAdapter.compareEqual(i + 1, $getCallSiteArray[391].callGetProperty($getCallSiteArray[392].call(domnode)))) {
                    if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[393].callGetProperty($getCallSiteArray[394].callGetProperty(domnode)), TextImpl.class)) {
                        if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[395].callGetProperty($getCallSiteArray[396].call(domnode)), 1)) {
                            $getCallSiteArray[397].call(node5, $getCallSiteArray[398].callConstructor(DefaultMutableTreeNode.class, new GStringImpl(new Object[] { $getCallSiteArray[399].call(domnode) }, new String[] { "<html><font color=C700FF>&lt;/", "&gt;</font><html>" })));
                        }
                    }
                    else if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[400].callGetProperty($getCallSiteArray[401].call(domnode)), 0)) {
                        $getCallSiteArray[402].call(node5, $getCallSiteArray[403].callConstructor(DefaultMutableTreeNode.class, new GStringImpl(new Object[] { $getCallSiteArray[404].call(domnode) }, new String[] { "<html><font color=C700FF>&lt;/", "&gt;</font><html>" })));
                    }
                }
            }
        }
        else {
            for (int j = 0; ScriptBytecodeAdapter.compareLessThan(j, $getCallSiteArray[365].callGetProperty($getCallSiteArray[366].call(domnode))); j = DefaultTypeTransformation.intUnbox($getCallSiteArray[385].call(j))) {
                $getCallSiteArray[367].callCurrent(this, $getCallSiteArray[368].call($getCallSiteArray[369].call(domnode), j), node5);
                if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[370].call(j, 1), $getCallSiteArray[371].callGetProperty($getCallSiteArray[372].call(domnode)))) {
                    if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[373].callGetProperty($getCallSiteArray[374].callGetProperty(domnode)), TextImpl.class)) {
                        if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[375].callGetProperty($getCallSiteArray[376].call(domnode)), 1)) {
                            $getCallSiteArray[377].call(node5, $getCallSiteArray[378].callConstructor(DefaultMutableTreeNode.class, new GStringImpl(new Object[] { $getCallSiteArray[379].call(domnode) }, new String[] { "<html><font color=C700FF>&lt;/", "&gt;</font><html>" })));
                        }
                    }
                    else if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[380].callGetProperty($getCallSiteArray[381].call(domnode)), 0)) {
                        $getCallSiteArray[382].call(node5, $getCallSiteArray[383].callConstructor(DefaultMutableTreeNode.class, new GStringImpl(new Object[] { $getCallSiteArray[384].call(domnode) }, new String[] { "<html><font color=C700FF>&lt;/", "&gt;</font><html>" })));
                    }
                }
            }
        }
        return null;
    }
    
    public void selectUINodeByXpath(final String id) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        Object node = null;
        try {
            node = $getCallSiteArray[405].call(this.xpath, id, $getCallSiteArray[406].call(this.parser), $getCallSiteArray[407].callGetProperty(XPathConstants.class));
        }
        catch (Exception ex) {
            $getCallSiteArray[408].callCurrent(this, new GStringImpl(new Object[] { id }, new String[] { "Problem with id: ", "" }));
        }
        final Object exceptionClosure = new GeneratedClosure(this, this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final Exception ex) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                return $getCallSiteArray[0].call(JOptionPane.class, $getCallSiteArray[1].callGroovyObjectGetProperty(this), $getCallSiteArray[2].call("Error getting html page: ", $getCallSiteArray[3].callGetProperty(ex)), "Error", $getCallSiteArray[4].callGetProperty(JOptionPane.class));
            }
            
            public Object call(final Exception ex) {
                return $getCallSiteArray()[5].callCurrent(this, ex);
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$_selectUINodeByXpath_closure6.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[6];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$_selectUINodeByXpath_closure6.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$_selectUINodeByXpath_closure6.$callSiteArray == null || ($createCallSiteArray = MainWindow$_selectUINodeByXpath_closure6.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$_selectUINodeByXpath_closure6.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        };
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual(node, null)) {
                $getCallSiteArray[411].callCurrent(this, $getCallSiteArray[412].call(this.glass, exceptionClosure));
                return;
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual(node, null)) {
            $getCallSiteArray[409].callCurrent(this, $getCallSiteArray[410].call(this.glass, exceptionClosure));
            return;
        }
        final TreeNode[] nodes = (TreeNode[])ScriptBytecodeAdapter.castToType($getCallSiteArray[413].call(ScriptBytecodeAdapter.castToType($getCallSiteArray[414].call(this.DOMtree), DefaultTreeModel.class), $getCallSiteArray[415].call(this.uiToXMLHash, node)), TreeNode[].class);
        final TreePath tpath = (TreePath)ScriptBytecodeAdapter.castToType($getCallSiteArray[416].callConstructor(TreePath.class, (Object)nodes), TreePath.class);
        $getCallSiteArray[417].call(this.DOMtree);
        $getCallSiteArray[418].call(this.DOMtree, tpath);
        $getCallSiteArray[419].call(this.DOMtree, tpath);
        $getCallSiteArray[420].call(this.DOMtree, tpath);
    }
    
    public String generateXPathFromDOM(final Object domnode) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[422].callGetProperty(domnode), TextImpl.class)) {
                return "";
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[421].callGetProperty(domnode), TextImpl.class)) {
            return "";
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[424].callGetProperty(domnode), CommentImpl.class)) {
                return "";
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[423].callGetProperty(domnode), CommentImpl.class)) {
            return "";
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[426].callGetProperty(domnode), HTMLDocumentImpl.class)) {
                return "";
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[425].callGetProperty(domnode), HTMLDocumentImpl.class)) {
            return "";
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[434].call(domnode), null)) {
                final Object foundID = $getCallSiteArray[435].call($getCallSiteArray[436].callGetProperty($getCallSiteArray[437].call(domnode)), new GeneratedClosure((Object)this, (Object)this) {
                    public static transient /* synthetic */ boolean __$stMC;
                    private static /* synthetic */ SoftReference $callSiteArray;
                    
                    public Object doCall(final Object it) {
                        final CallSite[] $getCallSiteArray = $getCallSiteArray();
                        if (BytecodeInterface8.isOrigZ() && !MainWindow$_generateXPathFromDOM_closure7.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                            return ScriptBytecodeAdapter.compareEqual($getCallSiteArray[1].callGetProperty(it), "id");
                        }
                        return ScriptBytecodeAdapter.compareEqual($getCallSiteArray[0].callGetProperty(it), "id");
                    }
                    
                    public Object doCall() {
                        $getCallSiteArray();
                        return this.doCall(null);
                    }
                    
                    public static /* synthetic */ void __$swapInit() {
                        $getCallSiteArray();
                        MainWindow$_generateXPathFromDOM_closure7.$callSiteArray = null;
                    }
                    
                    static {
                        __$swapInit();
                    }
                    
                    private static /* synthetic */ void $createCallSiteArray_1(final String[] array) {
                        array[1] = (array[0] = "name");
                    }
                    
                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                        final String[] names = new String[2];
                        $createCallSiteArray_1(names);
                        return new CallSiteArray(MainWindow$_generateXPathFromDOM_closure7.class, names);
                    }
                    
                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                        CallSiteArray $createCallSiteArray;
                        if (MainWindow$_generateXPathFromDOM_closure7.$callSiteArray == null || ($createCallSiteArray = MainWindow$_generateXPathFromDOM_closure7.$callSiteArray.get()) == null) {
                            $createCallSiteArray = $createCallSiteArray();
                            MainWindow$_generateXPathFromDOM_closure7.$callSiteArray = new SoftReference($createCallSiteArray);
                        }
                        return $createCallSiteArray.array;
                    }
                });
                if (ScriptBytecodeAdapter.compareNotEqual(foundID, null)) {
                    return (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[438].call($getCallSiteArray[439].call("//*[@id='", $getCallSiteArray[440].callGetProperty(foundID)), "']"), String.class);
                }
            }
        }
        else if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[427].call(domnode), null)) {
            final Object foundID2 = $getCallSiteArray[428].call($getCallSiteArray[429].callGetProperty($getCallSiteArray[430].call(domnode)), new GeneratedClosure((Object)this, (Object)this) {
                public static transient /* synthetic */ boolean __$stMC;
                private static /* synthetic */ SoftReference $callSiteArray;
                
                public Object doCall(final Object it) {
                    final CallSite[] $getCallSiteArray = $getCallSiteArray();
                    if (BytecodeInterface8.isOrigZ() && !MainWindow$_generateXPathFromDOM_closure7.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                        return ScriptBytecodeAdapter.compareEqual($getCallSiteArray[1].callGetProperty(it), "id");
                    }
                    return ScriptBytecodeAdapter.compareEqual($getCallSiteArray[0].callGetProperty(it), "id");
                }
                
                public Object doCall() {
                    $getCallSiteArray();
                    return this.doCall(null);
                }
                
                public static /* synthetic */ void __$swapInit() {
                    $getCallSiteArray();
                    MainWindow$_generateXPathFromDOM_closure7.$callSiteArray = null;
                }
                
                static {
                    __$swapInit();
                }
                
                private static /* synthetic */ void $createCallSiteArray_1(final String[] array) {
                    array[1] = (array[0] = "name");
                }
                
                private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                    final String[] names = new String[2];
                    $createCallSiteArray_1(names);
                    return new CallSiteArray(MainWindow$_generateXPathFromDOM_closure7.class, names);
                }
                
                private static /* synthetic */ CallSite[] $getCallSiteArray() {
                    CallSiteArray $createCallSiteArray;
                    if (MainWindow$_generateXPathFromDOM_closure7.$callSiteArray == null || ($createCallSiteArray = MainWindow$_generateXPathFromDOM_closure7.$callSiteArray.get()) == null) {
                        $createCallSiteArray = $createCallSiteArray();
                        MainWindow$_generateXPathFromDOM_closure7.$callSiteArray = new SoftReference($createCallSiteArray);
                    }
                    return $createCallSiteArray.array;
                }
            });
            if (ScriptBytecodeAdapter.compareNotEqual(foundID2, null)) {
                return (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[431].call($getCallSiteArray[432].call("//*[@id='", $getCallSiteArray[433].callGetProperty(foundID2)), "']"), String.class);
            }
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[442].call(domnode), "HTML")) {
                return "/HTML";
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[441].call(domnode), "HTML")) {
            return "/HTML";
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[444].call(domnode), "BODY")) {
                return "/HTML/BODY";
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[443].call(domnode), "BODY")) {
            return "/HTML/BODY";
        }
        if (BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[446].call(domnode), "HEAD")) {
                return "/HTML/HEAD";
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[445].call(domnode), "HEAD")) {
            return "/HTML/HEAD";
        }
        int ix = 0;
        final Object siblings = $getCallSiteArray[447].call($getCallSiteArray[448].call(domnode));
        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            for (int i = 0; ScriptBytecodeAdapter.compareLessThan(i, $getCallSiteArray[466].callGetProperty(siblings)); i++) {
                final Object sibling = $getCallSiteArray[467].call(siblings, i);
                if (ScriptBytecodeAdapter.compareEqual(sibling, domnode)) {
                    return (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[468].call($getCallSiteArray[469].call($getCallSiteArray[470].call($getCallSiteArray[471].call($getCallSiteArray[472].call($getCallSiteArray[473].callCurrent(this, $getCallSiteArray[474].call(domnode)), "/"), $getCallSiteArray[475].call(domnode)), "["), ix + 1), "]"), String.class);
                }
                if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[476].callGetProperty(sibling), TextImpl.class) && ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[477].callGetProperty(sibling), CommentImpl.class) && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[478].call(sibling), $getCallSiteArray[479].call(domnode))) {
                    ix++;
                }
            }
        }
        else {
            for (int j = 0; ScriptBytecodeAdapter.compareLessThan(j, $getCallSiteArray[449].callGetProperty(siblings)); j = DefaultTypeTransformation.intUnbox($getCallSiteArray[465].call(j))) {
                final Object sibling2 = $getCallSiteArray[450].call(siblings, j);
                if (ScriptBytecodeAdapter.compareEqual(sibling2, domnode)) {
                    return (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[451].call($getCallSiteArray[452].call($getCallSiteArray[453].call($getCallSiteArray[454].call($getCallSiteArray[455].call($getCallSiteArray[456].callCurrent(this, $getCallSiteArray[457].call(domnode)), "/"), $getCallSiteArray[458].call(domnode)), "["), $getCallSiteArray[459].call(ix, 1)), "]"), String.class);
                }
                if (ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[460].callGetProperty(sibling2), TextImpl.class) && ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[461].callGetProperty(sibling2), CommentImpl.class) && ScriptBytecodeAdapter.compareEqual($getCallSiteArray[462].call(sibling2), $getCallSiteArray[463].call(domnode))) {
                    ix = DefaultTypeTransformation.intUnbox($getCallSiteArray[464].call(ix));
                }
            }
        }
        return (String)ScriptBytecodeAdapter.castToType(null, String.class);
    }
    
    public void parseHTML(String html) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        this.uiToXMLHash = ScriptBytecodeAdapter.createMap(new Object[0]);
        this.alreadyIncludedHash = ScriptBytecodeAdapter.createMap(new Object[0]);
        $getCallSiteArray[480].call(this.parser);
        final int index = DefaultTypeTransformation.intUnbox($getCallSiteArray[481].call(html, "<head>"));
        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !MainWindow.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (index != 0 && ScriptBytecodeAdapter.compareNotEqual(index, -1)) {
                html = (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[484].call(html, index, $getCallSiteArray[485].call(html)), String.class);
            }
        }
        else if (index != 0 && ScriptBytecodeAdapter.compareNotEqual(index, -1)) {
            html = (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[482].call(html, index, $getCallSiteArray[483].call(html)), String.class);
        }
        $getCallSiteArray[486].call(this.parser, $getCallSiteArray[487].callConstructor(InputSource.class, $getCallSiteArray[488].callConstructor(StringReader.class, html)));
        final Object htmlNode = $getCallSiteArray[489].call($getCallSiteArray[490].call($getCallSiteArray[491].call(this.parser)), 0);
        $getCallSiteArray[492].call(this.DOMtree, (Object)null);
        this.rootNode = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[493].callConstructor(DefaultMutableTreeNode.class, " <HTML>"), DefaultMutableTreeNode.class);
        final DefaultTreeModel treeModel = (DefaultTreeModel)ScriptBytecodeAdapter.castToType($getCallSiteArray[494].callConstructor(DefaultTreeModel.class, this.rootNode), DefaultTreeModel.class);
        $getCallSiteArray[495].call(this.DOMtree, treeModel);
        $getCallSiteArray[496].callCurrent(this, $getCallSiteArray[497].call($getCallSiteArray[498].call(htmlNode), 0), $getCallSiteArray[499].call($getCallSiteArray[500].call(this.DOMtree)));
        $getCallSiteArray[501].callCurrent(this, $getCallSiteArray[502].call($getCallSiteArray[503].call(htmlNode), 1), $getCallSiteArray[504].call($getCallSiteArray[505].call(this.DOMtree)));
    }
    
    public static void main(final String... args) {
        $getCallSiteArray()[506].call(SwingUtilities.class, new Runnable() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void run() {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                final MainWindow main = (MainWindow)ScriptBytecodeAdapter.castToType($getCallSiteArray[0].callConstructor(MainWindow.class), MainWindow.class);
                $getCallSiteArray[1].call(main, true);
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != MainWindow$13.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = MainWindow$13.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (MainWindow$13.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                MainWindow$13.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[2];
                $createCallSiteArray_1(names);
                return new CallSiteArray(MainWindow$13.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (MainWindow$13.$callSiteArray == null || ($createCallSiteArray = MainWindow$13.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    MainWindow$13.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
    }
    
    protected /* synthetic */ MetaClass $getStaticMetaClass() {
        if (this.getClass() != MainWindow.class) {
            return ScriptBytecodeAdapter.initMetaClass(this);
        }
        ClassInfo $staticClassInfo = MainWindow.$staticClassInfo;
        if ($staticClassInfo == null) {
            $staticClassInfo = (MainWindow.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
        }
        return $staticClassInfo.getMetaClass();
    }
    
    public static /* synthetic */ void __$swapInit() {
        $getCallSiteArray();
        MainWindow.$callSiteArray = null;
    }
    
    static {
        __$swapInit();
        MainWindow.__timeStamp__239_neverHappen1397742965754 = 0L;
        MainWindow.__timeStamp = 1397742965754L;
    }
    
    public DOMParser getParser() {
        return this.parser;
    }
    
    public void setParser(final DOMParser parser) {
        this.parser = parser;
    }
    
    public JCheckBoxMenuItem getAlwaysOnTop() {
        return this.alwaysOnTop;
    }
    
    public JMenuBar getMenubar() {
        return this.menubar;
    }
    
    public void setMenubar(final JMenuBar menubar) {
        this.menubar = menubar;
    }
    
    public JMenu getFileMenu() {
        return this.fileMenu;
    }
    
    public void setFileMenu(final JMenu fileMenu) {
        this.fileMenu = fileMenu;
    }
    
    public JButton getStartBtn() {
        return this.startBtn;
    }
    
    public void setStartBtn(final JButton startBtn) {
        this.startBtn = startBtn;
    }
    
    public IDEView getIdeView() {
        return this.ideView;
    }
    
    public void setIdeView(final IDEView ideView) {
        this.ideView = ideView;
    }
    
    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
        final String[] names = new String[507];
        $createCallSiteArray_1(names);
        return new CallSiteArray(MainWindow.class, names);
    }
    
    private static /* synthetic */ CallSite[] $getCallSiteArray() {
        CallSiteArray $createCallSiteArray;
        if (MainWindow.$callSiteArray == null || ($createCallSiteArray = MainWindow.$callSiteArray.get()) == null) {
            $createCallSiteArray = $createCallSiteArray();
            MainWindow.$callSiteArray = new SoftReference($createCallSiteArray);
        }
        return $createCallSiteArray.array;
    }
    
    public class copyBtn extends JButton implements ActionListener, GroovyObject
    {
        private static /* synthetic */ ClassInfo $staticClassInfo;
        private transient /* synthetic */ MetaClass metaClass;
        private static /* synthetic */ SoftReference $callSiteArray;
        
        public copyBtn(final String text, final ImageIcon icon) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            this.metaClass = this.$getStaticMetaClass();
            ScriptBytecodeAdapter.invokeMethodOnSuperN(JButton.class, this, "setText", new Object[] { text });
            ScriptBytecodeAdapter.invokeMethodOnSuperN(JButton.class, this, "setIcon", new Object[] { icon });
            $getCallSiteArray[0].callCurrent(this, this);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            final Clipboard clpbrd = (Clipboard)ScriptBytecodeAdapter.castToType($getCallSiteArray[1].call($getCallSiteArray[2].call(Toolkit.class)), Clipboard.class);
            $getCallSiteArray[3].call(clpbrd, $getCallSiteArray[4].callConstructor(StringSelection.class, $getCallSiteArray[5].call($getCallSiteArray[6].callGroovyObjectGetProperty(this))), null);
        }
        
        protected /* synthetic */ MetaClass $getStaticMetaClass() {
            if (this.getClass() != copyBtn.class) {
                return ScriptBytecodeAdapter.initMetaClass(this);
            }
            ClassInfo $staticClassInfo = copyBtn.$staticClassInfo;
            if ($staticClassInfo == null) {
                $staticClassInfo = (copyBtn.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
            }
            return $staticClassInfo.getMetaClass();
        }
        
        public static /* synthetic */ void __$swapInit() {
            $getCallSiteArray();
            copyBtn.$callSiteArray = null;
        }
        
        static {
            __$swapInit();
        }
        
        private static /* synthetic */ CallSiteArray $createCallSiteArray() {
            final String[] names = new String[7];
            $createCallSiteArray_1(names);
            return new CallSiteArray(copyBtn.class, names);
        }
        
        private static /* synthetic */ CallSite[] $getCallSiteArray() {
            CallSiteArray $createCallSiteArray;
            if (copyBtn.$callSiteArray == null || ($createCallSiteArray = copyBtn.$callSiteArray.get()) == null) {
                $createCallSiteArray = $createCallSiteArray();
                copyBtn.$callSiteArray = new SoftReference($createCallSiteArray);
            }
            return $createCallSiteArray.array;
        }
    }
    
    public class pointerBtn extends JButton implements ActionListener, GroovyObject
    {
        private static /* synthetic */ ClassInfo $staticClassInfo;
        public static transient /* synthetic */ boolean __$stMC;
        private transient /* synthetic */ MetaClass metaClass;
        private static /* synthetic */ SoftReference $callSiteArray;
        
        public pointerBtn(final String text, final ImageIcon icon) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            this.metaClass = this.$getStaticMetaClass();
            ScriptBytecodeAdapter.invokeMethodOnSuperN(JButton.class, this, "setText", new Object[] { text });
            ScriptBytecodeAdapter.invokeMethodOnSuperN(JButton.class, this, "setIcon", new Object[] { icon });
            $getCallSiteArray[0].callCurrent(this, this);
        }
        
        public void actionPerformed(final ActionEvent e) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            if (BytecodeInterface8.isOrigZ() && !pointerBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[6].callGroovyObjectGetProperty($getCallSiteArray[7].callGroovyObjectGetProperty(this)), true)) {
                    $getCallSiteArray[8].call(JOptionPane.class, $getCallSiteArray[9].callGroovyObjectGetProperty(this), "Please stop recording in Code tab.", "Error", $getCallSiteArray[10].callGetProperty(JOptionPane.class));
                    return;
                }
            }
            else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[1].callGroovyObjectGetProperty($getCallSiteArray[2].callGroovyObjectGetProperty(this)), true)) {
                $getCallSiteArray[3].call(JOptionPane.class, $getCallSiteArray[4].callGroovyObjectGetProperty(this), "Please stop recording in Code tab.", "Error", $getCallSiteArray[5].callGetProperty(JOptionPane.class));
                return;
            }
            ScriptBytecodeAdapter.setGroovyObjectProperty(true, pointerBtn.class, this, "lookingForObject");
            $getCallSiteArray[11].call($getCallSiteArray[12].callConstructor(ObjectLocator.class, this, $getCallSiteArray[13].callGroovyObjectGetProperty(this)));
        }
        
        protected /* synthetic */ MetaClass $getStaticMetaClass() {
            if (this.getClass() != pointerBtn.class) {
                return ScriptBytecodeAdapter.initMetaClass(this);
            }
            ClassInfo $staticClassInfo = pointerBtn.$staticClassInfo;
            if ($staticClassInfo == null) {
                $staticClassInfo = (pointerBtn.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
            }
            return $staticClassInfo.getMetaClass();
        }
        
        public static /* synthetic */ void __$swapInit() {
            $getCallSiteArray();
            pointerBtn.$callSiteArray = null;
        }
        
        static {
            __$swapInit();
        }
        
        private static /* synthetic */ CallSiteArray $createCallSiteArray() {
            final String[] names = new String[14];
            $createCallSiteArray_1(names);
            return new CallSiteArray(pointerBtn.class, names);
        }
        
        private static /* synthetic */ CallSite[] $getCallSiteArray() {
            CallSiteArray $createCallSiteArray;
            if (pointerBtn.$callSiteArray == null || ($createCallSiteArray = pointerBtn.$callSiteArray.get()) == null) {
                $createCallSiteArray = $createCallSiteArray();
                pointerBtn.$callSiteArray = new SoftReference($createCallSiteArray);
            }
            return $createCallSiteArray.array;
        }
        
        public class ObjectLocator extends SwingWorker<String, Object> implements GroovyObject
        {
            private MainWindow main;
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private transient /* synthetic */ MetaClass metaClass;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public ObjectLocator(final MainWindow mainWindow) {
                final Reference mainWindow2 = new Reference((T)mainWindow);
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                this.metaClass = this.$getStaticMetaClass();
                this.main = mainWindow2.get();
                final Object exceptionClosure = new _ObjectLocator_closure1(this, mainWindow2);
                final Object html = $getCallSiteArray[0].call($getCallSiteArray[1].callGetProperty(this.main), exceptionClosure);
                if (BytecodeInterface8.isOrigZ() && !BytecodeInterface8.disabledStandardMetaClass()) {
                    if (ScriptBytecodeAdapter.compareEqual(html, "")) {
                        return;
                    }
                }
                else if (ScriptBytecodeAdapter.compareEqual(html, "")) {
                    return;
                }
                $getCallSiteArray[2].call(this.main, html);
                $getCallSiteArray[3].call($getCallSiteArray[4].callGetProperty(this.main), "<html><font color=blue>Click on any element to stop tracking.</font></html>");
                $getCallSiteArray[5].call($getCallSiteArray[6].callGetProperty(this.main), false);
            }
            
            public String doInBackground() {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                while (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[7].callGetProperty(this.main))) {
                    final Object chunk = $getCallSiteArray[8].call($getCallSiteArray[9].callGetProperty(this.main), new GeneratedClosure((Object)this, (Object)this) {
                        private static /* synthetic */ SoftReference $callSiteArray;
                        
                        public Object doCall(final Object it) {
                            final CallSite[] $getCallSiteArray = $getCallSiteArray();
                            return $getCallSiteArray[0].call($getCallSiteArray[1].callGroovyObjectGetProperty(this), $getCallSiteArray[2].call($getCallSiteArray[3].callGetProperty($getCallSiteArray[4].callGroovyObjectGetProperty(this))));
                        }
                        
                        public Object doCall() {
                            $getCallSiteArray();
                            return this.doCall(null);
                        }
                        
                        public static /* synthetic */ void __$swapInit() {
                            $getCallSiteArray();
                            MainWindow$_ObjectLocator_doInBackground_closure2.$callSiteArray = null;
                        }
                        
                        static {
                            __$swapInit();
                        }
                        
                        private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                            final String[] names = new String[5];
                            $createCallSiteArray_1(names);
                            return new CallSiteArray(MainWindow$_ObjectLocator_doInBackground_closure2.class, names);
                        }
                        
                        private static /* synthetic */ CallSite[] $getCallSiteArray() {
                            CallSiteArray $createCallSiteArray;
                            if (MainWindow$_ObjectLocator_doInBackground_closure2.$callSiteArray == null || ($createCallSiteArray = MainWindow$_ObjectLocator_doInBackground_closure2.$callSiteArray.get()) == null) {
                                $createCallSiteArray = $createCallSiteArray();
                                MainWindow$_ObjectLocator_doInBackground_closure2.$callSiteArray = new SoftReference($createCallSiteArray);
                            }
                            return $createCallSiteArray.array;
                        }
                    });
                    if (ScriptBytecodeAdapter.compareEqual(chunk, "END OF RECORDING")) {
                        ScriptBytecodeAdapter.setProperty(false, null, this.main, "lookingForObject");
                        $getCallSiteArray[10].callCurrent(this);
                        return "";
                    }
                    $getCallSiteArray[11].callCurrent(this, chunk);
                }
                return "";
            }
            
            @Override
            protected void process(final List<Object> chunks) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                Object id = null;
                final Iterator iterator = (Iterator)ScriptBytecodeAdapter.castToType($getCallSiteArray[12].call(chunks), Iterator.class);
                while (iterator.hasNext()) {
                    id = iterator.next();
                    if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[13].callGetProperty(this.main), false)) {
                        return;
                    }
                    ScriptBytecodeAdapter.setProperty(id, null, this.main, "ShownElement");
                    $getCallSiteArray[14].call(this.main);
                    ScriptBytecodeAdapter.setProperty(true, null, this.main, "autoSelect");
                    $getCallSiteArray[15].call(this.main, $getCallSiteArray[16].callGetProperty(id));
                    ScriptBytecodeAdapter.setProperty(false, null, this.main, "autoSelect");
                }
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != ObjectLocator.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = ObjectLocator.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (ObjectLocator.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                ObjectLocator.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[17];
                $createCallSiteArray_1(names);
                return new CallSiteArray(ObjectLocator.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (ObjectLocator.$callSiteArray == null || ($createCallSiteArray = ObjectLocator.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    ObjectLocator.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
            
            class _ObjectLocator_closure1 extends Closure implements GeneratedClosure
            {
                private /* synthetic */ Reference mainWindow;
                public static transient /* synthetic */ boolean __$stMC;
                private static /* synthetic */ SoftReference $callSiteArray;
                
                public _ObjectLocator_closure1(final Object _outerInstance, final Object _thisObject, final Reference mainWindow) {
                    $getCallSiteArray();
                    super(_outerInstance, _thisObject);
                    this.mainWindow = mainWindow;
                }
                
                public Object doCall(final Exception ex) {
                    final CallSite[] $getCallSiteArray = $getCallSiteArray();
                    Object error = $getCallSiteArray[0].call("Error getting html page from browser: ", $getCallSiteArray[1].callGetProperty(ex));
                    if (BytecodeInterface8.isOrigZ() && !_ObjectLocator_closure1.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[3].callGetProperty(ex), NoSuchWindowException.class)) {
                            error = "Error getting html page from browser. \r\nPlease make sure that you have \"Protected Mode Enabled\" check box checked for all security zones.";
                        }
                    }
                    else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[2].callGetProperty(ex), NoSuchWindowException.class)) {
                        error = "Error getting html page from browser. \r\nPlease make sure that you have \"Protected Mode Enabled\" check box checked for all security zones.";
                    }
                    return $getCallSiteArray[4].call(JOptionPane.class, this.mainWindow.get(), error, "Error", $getCallSiteArray[5].callGetProperty(JOptionPane.class));
                }
                
                public Object call(final Exception ex) {
                    return $getCallSiteArray()[6].callCurrent(this, ex);
                }
                
                public MainWindow getMainWindow() {
                    $getCallSiteArray();
                    return (MainWindow)ScriptBytecodeAdapter.castToType(this.mainWindow.get(), MainWindow.class);
                }
                
                public static /* synthetic */ void __$swapInit() {
                    $getCallSiteArray();
                    _ObjectLocator_closure1.$callSiteArray = null;
                }
                
                static {
                    __$swapInit();
                }
                
                private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                    final String[] names = new String[7];
                    $createCallSiteArray_1(names);
                    return new CallSiteArray(_ObjectLocator_closure1.class, names);
                }
                
                private static /* synthetic */ CallSite[] $getCallSiteArray() {
                    CallSiteArray $createCallSiteArray;
                    if (_ObjectLocator_closure1.$callSiteArray == null || ($createCallSiteArray = _ObjectLocator_closure1.$callSiteArray.get()) == null) {
                        $createCallSiteArray = $createCallSiteArray();
                        _ObjectLocator_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                    }
                    return $createCallSiteArray.array;
                }
            }
        }
    }
    
    public class startBtn extends JButton implements ActionListener, GroovyObject
    {
        private static /* synthetic */ ClassInfo $staticClassInfo;
        private transient /* synthetic */ MetaClass metaClass;
        private static /* synthetic */ SoftReference $callSiteArray;
        
        public startBtn(final String text) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            this.metaClass = this.$getStaticMetaClass();
            ScriptBytecodeAdapter.invokeMethodOnSuperN(JButton.class, this, "setText", new Object[] { text });
            $getCallSiteArray[0].callCurrent(this, this);
        }
        
        public void actionPerformed(final ActionEvent e) {
            $getCallSiteArray()[1].callCurrent(this);
        }
        
        protected /* synthetic */ MetaClass $getStaticMetaClass() {
            if (this.getClass() != startBtn.class) {
                return ScriptBytecodeAdapter.initMetaClass(this);
            }
            ClassInfo $staticClassInfo = startBtn.$staticClassInfo;
            if ($staticClassInfo == null) {
                $staticClassInfo = (startBtn.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
            }
            return $staticClassInfo.getMetaClass();
        }
        
        public static /* synthetic */ void __$swapInit() {
            $getCallSiteArray();
            startBtn.$callSiteArray = null;
        }
        
        static {
            __$swapInit();
        }
        
        private static /* synthetic */ CallSiteArray $createCallSiteArray() {
            final String[] names = new String[2];
            $createCallSiteArray_1(names);
            return new CallSiteArray(startBtn.class, names);
        }
        
        private static /* synthetic */ CallSite[] $getCallSiteArray() {
            CallSiteArray $createCallSiteArray;
            if (startBtn.$callSiteArray == null || ($createCallSiteArray = startBtn.$callSiteArray.get()) == null) {
                $createCallSiteArray = $createCallSiteArray();
                startBtn.$callSiteArray = new SoftReference($createCallSiteArray);
            }
            return $createCallSiteArray.array;
        }
    }
    
    public class browserTypeList extends JComboBox implements ActionListener, GroovyObject
    {
        private static /* synthetic */ ClassInfo $staticClassInfo;
        private transient /* synthetic */ MetaClass metaClass;
        private static /* synthetic */ SoftReference $callSiteArray;
        
        public browserTypeList() {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            this.metaClass = this.$getStaticMetaClass();
            final String[] browserStrings = (String[])ScriptBytecodeAdapter.castToType(ScriptBytecodeAdapter.createList(new Object[] { "Firefox", "Chrome", "Internet Explorer", "Safari" }), String[].class);
            $getCallSiteArray[0].call(browserStrings, new _browserTypeList_closure1(this));
            $getCallSiteArray[1].callCurrent(this, this);
        }
        
        @Override
        public void actionPerformed(final ActionEvent e) {
            ScriptBytecodeAdapter.setGroovyObjectProperty(ScriptBytecodeAdapter.castToType($getCallSiteArray()[2].callGroovyObjectGetProperty(this), String.class), browserTypeList.class, this, "SelectedBrowser");
        }
        
        protected /* synthetic */ MetaClass $getStaticMetaClass() {
            if (this.getClass() != browserTypeList.class) {
                return ScriptBytecodeAdapter.initMetaClass(this);
            }
            ClassInfo $staticClassInfo = browserTypeList.$staticClassInfo;
            if ($staticClassInfo == null) {
                $staticClassInfo = (browserTypeList.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
            }
            return $staticClassInfo.getMetaClass();
        }
        
        public static /* synthetic */ void __$swapInit() {
            $getCallSiteArray();
            browserTypeList.$callSiteArray = null;
        }
        
        static {
            __$swapInit();
        }
        
        private static /* synthetic */ CallSiteArray $createCallSiteArray() {
            final String[] names = new String[3];
            $createCallSiteArray_1(names);
            return new CallSiteArray(browserTypeList.class, names);
        }
        
        private static /* synthetic */ CallSite[] $getCallSiteArray() {
            CallSiteArray $createCallSiteArray;
            if (browserTypeList.$callSiteArray == null || ($createCallSiteArray = browserTypeList.$callSiteArray.get()) == null) {
                $createCallSiteArray = $createCallSiteArray();
                browserTypeList.$callSiteArray = new SoftReference($createCallSiteArray);
            }
            return $createCallSiteArray.array;
        }
        
        class _browserTypeList_closure1 extends Closure implements GeneratedClosure
        {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public _browserTypeList_closure1(final Object _outerInstance, final Object _thisObject) {
                $getCallSiteArray();
                super(_outerInstance, _thisObject);
            }
            
            public Object doCall(final Object it) {
                return $getCallSiteArray()[0].callCurrent((GroovyObject)this.getThisObject(), it);
            }
            
            public Object doCall() {
                $getCallSiteArray();
                return this.doCall(null);
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                _browserTypeList_closure1.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = { null };
                $createCallSiteArray_1(names);
                return new CallSiteArray(_browserTypeList_closure1.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (_browserTypeList_closure1.$callSiteArray == null || ($createCallSiteArray = _browserTypeList_closure1.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    _browserTypeList_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        }
    }
}
