// 
// Decompiled by Procyon v0.5.36
// 

package com.primatest.ui;

import javax.swing.plaf.PanelUI;
import groovy.lang.Closure;
import org.codehaus.groovy.runtime.GeneratedClosure;
import java.awt.MenuComponent;
import javax.accessibility.AccessibleContext;
import java.awt.image.VolatileImage;
import java.awt.ImageCapabilities;
import java.awt.event.InputMethodEvent;
import javax.swing.plaf.ComponentUI;
import java.awt.AWTKeyStroke;
import javax.swing.JRootPane;
import java.awt.FontMetrics;
import java.awt.BufferCapabilities;
import java.awt.image.ImageObserver;
import java.awt.im.InputContext;
import java.awt.event.KeyListener;
import java.awt.event.HierarchyEvent;
import javax.swing.ComponentInputMap;
import java.awt.event.ActionListener;
import java.awt.image.ImageProducer;
import java.awt.event.FocusEvent;
import java.io.PrintStream;
import java.awt.im.InputMethodRequests;
import javax.swing.TransferHandler;
import javax.swing.JToolTip;
import javax.swing.InputMap;
import java.io.PrintWriter;
import java.awt.Insets;
import javax.swing.event.AncestorListener;
import javax.swing.ActionMap;
import javax.swing.JPopupMenu;
import java.awt.image.BufferStrategy;
import java.awt.event.InputMethodListener;
import java.awt.Font;
import java.awt.PopupMenu;
import javax.swing.KeyStroke;
import java.awt.event.HierarchyBoundsListener;
import java.awt.FocusTraversalPolicy;
import java.awt.PointerInfo;
import java.awt.event.KeyEvent;
import javax.swing.InputVerifier;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.AWTEvent;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.ColorModel;
import javax.swing.border.Border;
import java.awt.event.ContainerListener;
import java.awt.event.ContainerEvent;
import javax.accessibility.AccessibleStateSet;
import java.awt.Color;
import java.util.Locale;
import java.beans.PropertyChangeListener;
import sun.java2d.pipe.Region;
import javax.swing.plaf.LabelUI;
import java.awt.Window;
import java.awt.peer.ComponentPeer;
import java.awt.Image;
import java.awt.Event;
import java.awt.dnd.DropTarget;
import java.awt.LayoutManager;
import java.util.Set;
import javax.swing.Icon;
import java.awt.Toolkit;
import java.awt.Rectangle;
import java.awt.GraphicsConfiguration;
import java.awt.Cursor;
import javax.accessibility.Accessible;
import java.awt.Point;
import java.security.AccessControlContext;
import java.awt.Graphics;
import java.awt.event.FocusListener;
import java.beans.VetoableChangeListener;
import java.awt.event.MouseWheelListener;
import java.awt.Dimension;
import java.awt.ComponentOrientation;
import java.awt.event.HierarchyListener;
import java.awt.Container;
import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.JScrollPane;
import org.codehaus.groovy.runtime.callsite.CallSiteArray;
import java.awt.event.MouseWheelEvent;
import org.codehaus.groovy.runtime.callsite.CallSite;
import javax.swing.SwingUtilities;
import org.codehaus.groovy.runtime.BytecodeInterface8;
import javax.swing.tree.TreePath;
import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import org.codehaus.groovy.runtime.GStringImpl;
import javax.swing.JMenuItem;
import javax.swing.tree.DefaultTreeModel;
import java.io.File;
import net.miginfocom.swing.MigLayout;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import groovy.lang.Reference;
import java.lang.ref.SoftReference;
import groovy.lang.MetaClass;
import org.codehaus.groovy.reflection.ClassInfo;
import com.jidesoft.swing.JidePopupMenu;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JTree;
import groovy.lang.GroovyObject;
import javax.swing.JPanel;

public class FileExplorer extends JPanel implements GroovyObject
{
    private JTree fileTree;
    private DefaultMutableTreeNode rootNode;
    private IDEView mainView;
    private JidePopupMenu popup;
    private JPanel treePanel;
    private static /* synthetic */ ClassInfo $staticClassInfo;
    private transient /* synthetic */ MetaClass metaClass;
    public static /* synthetic */ long __timeStamp;
    public static /* synthetic */ long __timeStamp__239_neverHappen1397742965729;
    private static /* synthetic */ SoftReference $callSiteArray;
    
    public FileExplorer(final Object ProjectName, final Object projectPath, final Object mainView) {
        final Reference mainView2 = new Reference((T)mainView);
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        this.metaClass = this.$getStaticMetaClass();
        this.treePanel = this;
        this.mainView = (IDEView)ScriptBytecodeAdapter.castToType(mainView2.get(), IDEView.class);
        $getCallSiteArray[0].callCurrent(this, $getCallSiteArray[1].callConstructor(MigLayout.class));
        this.rootNode = (DefaultMutableTreeNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[2].callConstructor(FileNode.class, $getCallSiteArray[3].callConstructor(File.class, projectPath)), DefaultMutableTreeNode.class);
        final DefaultTreeModel treeModel = (DefaultTreeModel)ScriptBytecodeAdapter.castToType($getCallSiteArray[4].callConstructor(DefaultTreeModel.class, this.rootNode), DefaultTreeModel.class);
        this.fileTree = (JTree)ScriptBytecodeAdapter.castToType($getCallSiteArray[5].callConstructor(JTree.class, treeModel), JTree.class);
        this.popup = (JidePopupMenu)ScriptBytecodeAdapter.castToType($getCallSiteArray[6].callConstructor(JidePopupMenu.class), JidePopupMenu.class);
        $getCallSiteArray[7].call(this.popup, $getCallSiteArray[8].callConstructor(JMenuItem.class, "File"));
        $getCallSiteArray[9].call(this.rootNode, new GStringImpl(new Object[] { ProjectName, projectPath }, new String[] { "", " [", "]" }));
        final MouseListener ml = new GroovyObject() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            public static transient /* synthetic */ boolean __$stMC;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            @Override
            public void mousePressed(final MouseEvent e) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                final int selRow = DefaultTypeTransformation.intUnbox($getCallSiteArray[0].call($getCallSiteArray[1].callGroovyObjectGetProperty(this), $getCallSiteArray[2].call(e), $getCallSiteArray[3].call(e)));
                final TreePath selPath = (TreePath)ScriptBytecodeAdapter.castToType($getCallSiteArray[4].call($getCallSiteArray[5].callGroovyObjectGetProperty(this), $getCallSiteArray[6].call(e), $getCallSiteArray[7].call(e)), TreePath.class);
                if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !FileExplorer$1.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                    if (ScriptBytecodeAdapter.compareNotEqual(selRow, -1)) {
                        if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[40].call(SwingUtilities.class, e))) {
                            $getCallSiteArray[41].call($getCallSiteArray[42].callGroovyObjectGetProperty(this));
                            $getCallSiteArray[43].call($getCallSiteArray[44].callGroovyObjectGetProperty(this), selRow);
                            $getCallSiteArray[45].call($getCallSiteArray[46].callGroovyObjectGetProperty(this), $getCallSiteArray[47].callGroovyObjectGetProperty(this), $getCallSiteArray[48].call(e), $getCallSiteArray[49].call(e));
                            return;
                        }
                        if (!ScriptBytecodeAdapter.compareEqual($getCallSiteArray[50].call(e), 1)) {
                            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[51].call(e), 2)) {
                                final Object selectedNode = $getCallSiteArray[52].call(selPath);
                                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[53].call($getCallSiteArray[54].callGetProperty(selectedNode)))) {
                                    return;
                                }
                                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[55].call($getCallSiteArray[56].callGetProperty($getCallSiteArray[57].callGetProperty(selectedNode)), ".groovy"))) {
                                    $getCallSiteArray[58].call(mainView2.get(), $getCallSiteArray[59].callGetProperty(selectedNode));
                                }
                                else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[60].call($getCallSiteArray[61].callGetProperty($getCallSiteArray[62].callGetProperty(selectedNode)), ".java"))) {
                                    $getCallSiteArray[63].call(mainView2.get(), $getCallSiteArray[64].callGetProperty(selectedNode));
                                }
                                else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[65].call($getCallSiteArray[66].callGetProperty($getCallSiteArray[67].callGetProperty(selectedNode)), ".xml"))) {
                                    $getCallSiteArray[68].call(mainView2.get(), $getCallSiteArray[69].callGetProperty(selectedNode));
                                }
                                else {
                                    $getCallSiteArray[70].call(mainView2.get(), $getCallSiteArray[71].callGetProperty(selectedNode));
                                }
                            }
                        }
                    }
                }
                else if (ScriptBytecodeAdapter.compareNotEqual(selRow, -1)) {
                    if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[8].call(SwingUtilities.class, e))) {
                        $getCallSiteArray[9].call($getCallSiteArray[10].callGroovyObjectGetProperty(this));
                        $getCallSiteArray[11].call($getCallSiteArray[12].callGroovyObjectGetProperty(this), selRow);
                        $getCallSiteArray[13].call($getCallSiteArray[14].callGroovyObjectGetProperty(this), $getCallSiteArray[15].callGroovyObjectGetProperty(this), $getCallSiteArray[16].call(e), $getCallSiteArray[17].call(e));
                        return;
                    }
                    if (!ScriptBytecodeAdapter.compareEqual($getCallSiteArray[18].call(e), 1)) {
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[19].call(e), 2)) {
                            final Object selectedNode2 = $getCallSiteArray[20].call(selPath);
                            if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[21].call($getCallSiteArray[22].callGetProperty(selectedNode2)))) {
                                return;
                            }
                            if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[23].call($getCallSiteArray[24].callGetProperty($getCallSiteArray[25].callGetProperty(selectedNode2)), ".groovy"))) {
                                $getCallSiteArray[26].call(mainView2.get(), $getCallSiteArray[27].callGetProperty(selectedNode2));
                            }
                            else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[28].call($getCallSiteArray[29].callGetProperty($getCallSiteArray[30].callGetProperty(selectedNode2)), ".java"))) {
                                $getCallSiteArray[31].call(mainView2.get(), $getCallSiteArray[32].callGetProperty(selectedNode2));
                            }
                            else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[33].call($getCallSiteArray[34].callGetProperty($getCallSiteArray[35].callGetProperty(selectedNode2)), ".xml"))) {
                                $getCallSiteArray[36].call(mainView2.get(), $getCallSiteArray[37].callGetProperty(selectedNode2));
                            }
                            else {
                                $getCallSiteArray[38].call(mainView2.get(), $getCallSiteArray[39].callGetProperty(selectedNode2));
                            }
                        }
                    }
                }
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != FileExplorer$1.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = FileExplorer$1.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (FileExplorer$1.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                FileExplorer$1.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[72];
                $createCallSiteArray_1(names);
                return new CallSiteArray(FileExplorer$1.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (FileExplorer$1.$callSiteArray == null || ($createCallSiteArray = FileExplorer$1.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    FileExplorer$1.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        };
        $getCallSiteArray[10].call(this.fileTree, ml);
        $getCallSiteArray[11].call(this.fileTree, true);
        $getCallSiteArray[12].call(this.fileTree, true);
        $getCallSiteArray[13].callCurrent(this, this.rootNode, $getCallSiteArray[14].callGetProperty(this.rootNode));
        $getCallSiteArray[15].call(this.fileTree, 0);
        final JScrollPane treeView = (JScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[16].callConstructor(JScrollPane.class, this.fileTree), JScrollPane.class);
        $getCallSiteArray[17].call(this.fileTree, new GroovyObject() {
            private ImageIcon groovyIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[0].callConstructor(ImageIcon.class, $getCallSiteArray[1].call($getCallSiteArray[2].call(System.class, "user.dir"), "/images/fileTypeGroovy.png")), ImageIcon.class);
            private ImageIcon javaIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[3].callConstructor(ImageIcon.class, $getCallSiteArray[4].call($getCallSiteArray[5].call(System.class, "user.dir"), "/images/fileTypeJava.png")), ImageIcon.class);
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            @Override
            public Component getTreeCellRendererComponent(final JTree tree, final Object value, final boolean selected, final boolean expanded, final boolean isLeaf, final int row, final boolean focused) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                final Component c = (Component)ScriptBytecodeAdapter.castToType(ScriptBytecodeAdapter.invokeMethodOnSuperN(DefaultTreeCellRenderer.class, this, "getTreeCellRendererComponent", new Object[] { tree, value, selected, expanded, isLeaf, row, focused }), Component.class);
                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[6].call($getCallSiteArray[7].callGetProperty($getCallSiteArray[8].callGetProperty(value)), ".groovy"))) {
                    $getCallSiteArray[9].callCurrent(this, this.groovyIcon);
                }
                else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[10].call($getCallSiteArray[11].callGetProperty($getCallSiteArray[12].callGetProperty(value)), ".java"))) {
                    $getCallSiteArray[13].callCurrent(this, this.javaIcon);
                }
                return c;
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != FileExplorer$2.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = FileExplorer$2.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (FileExplorer$2.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                FileExplorer$2.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[14];
                $createCallSiteArray_1(names);
                return new CallSiteArray(FileExplorer$2.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (FileExplorer$2.$callSiteArray == null || ($createCallSiteArray = FileExplorer$2.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    FileExplorer$2.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        $getCallSiteArray[18].callCurrent(this, treeView, "span,push, grow,height 200:3000:");
    }
    
    public Object openFile(final Object file) {
        return $getCallSiteArray()[19].call(this.mainView, file);
    }
    
    public Object readDirectory(final Object path) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        return $getCallSiteArray[20].callCurrent(this, this.rootNode, $getCallSiteArray[21].callConstructor(File.class, path));
    }
    
    public Object addFilesToDirNode(final Object parentNode, final File file) {
        final Reference parentNode2 = new Reference((T)parentNode);
        return $getCallSiteArray()[22].call(file, new GeneratedClosure((Object)this, (Object)this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final Object it) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                final FileNode childNode = (FileNode)ScriptBytecodeAdapter.castToType($getCallSiteArray[0].callConstructor(FileNode.class, it), FileNode.class);
                $getCallSiteArray[1].call(parentNode2.get(), childNode);
                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[2].call(it))) {
                    return $getCallSiteArray[3].callCurrent(this, childNode, it);
                }
                return null;
            }
            
            public Object getParentNode() {
                $getCallSiteArray();
                return parentNode2.get();
            }
            
            public Object doCall() {
                $getCallSiteArray();
                return this.doCall(null);
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                FileExplorer$_addFilesToDirNode_closure1.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[4];
                $createCallSiteArray_1(names);
                return new CallSiteArray(FileExplorer$_addFilesToDirNode_closure1.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (FileExplorer$_addFilesToDirNode_closure1.$callSiteArray == null || ($createCallSiteArray = FileExplorer$_addFilesToDirNode_closure1.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    FileExplorer$_addFilesToDirNode_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
    }
    
    protected /* synthetic */ MetaClass $getStaticMetaClass() {
        if (this.getClass() != FileExplorer.class) {
            return ScriptBytecodeAdapter.initMetaClass(this);
        }
        ClassInfo $staticClassInfo = FileExplorer.$staticClassInfo;
        if ($staticClassInfo == null) {
            $staticClassInfo = (FileExplorer.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
        }
        return $staticClassInfo.getMetaClass();
    }
    
    public static /* synthetic */ void __$swapInit() {
        $getCallSiteArray();
        FileExplorer.$callSiteArray = null;
    }
    
    static {
        __$swapInit();
        FileExplorer.__timeStamp__239_neverHappen1397742965729 = 0L;
        FileExplorer.__timeStamp = 1397742965729L;
    }
    
    public JTree getFileTree() {
        return this.fileTree;
    }
    
    public void setFileTree(final JTree fileTree) {
        this.fileTree = fileTree;
    }
    
    public DefaultMutableTreeNode getRootNode() {
        return this.rootNode;
    }
    
    public void setRootNode(final DefaultMutableTreeNode rootNode) {
        this.rootNode = rootNode;
    }
    
    public IDEView getMainView() {
        return this.mainView;
    }
    
    public void setMainView(final IDEView mainView) {
        this.mainView = mainView;
    }
    
    public JidePopupMenu getPopup() {
        return this.popup;
    }
    
    public void setPopup(final JidePopupMenu popup) {
        this.popup = popup;
    }
    
    public JPanel getTreePanel() {
        return this.treePanel;
    }
    
    public void setTreePanel(final JPanel treePanel) {
        this.treePanel = treePanel;
    }
    
    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
        final String[] names = new String[23];
        $createCallSiteArray_1(names);
        return new CallSiteArray(FileExplorer.class, names);
    }
    
    private static /* synthetic */ CallSite[] $getCallSiteArray() {
        CallSiteArray $createCallSiteArray;
        if (FileExplorer.$callSiteArray == null || ($createCallSiteArray = FileExplorer.$callSiteArray.get()) == null) {
            $createCallSiteArray = $createCallSiteArray();
            FileExplorer.$callSiteArray = new SoftReference($createCallSiteArray);
        }
        return $createCallSiteArray.array;
    }
}
