// 
// Decompiled by Procyon v0.5.36
// 

package com.primatest.ui;

import java.beans.PropertyChangeSupport;
import java.util.Iterator;
import java.util.List;
import javax.swing.SwingWorker;
import javax.swing.ButtonModel;
import java.awt.event.ItemEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.ButtonUI;
import javax.swing.Icon;
import javax.swing.Action;
import java.awt.event.ItemListener;
import groovy.json.JsonSlurper;
import java.awt.MenuComponent;
import javax.accessibility.AccessibleContext;
import java.awt.image.VolatileImage;
import java.awt.ImageCapabilities;
import java.awt.event.InputMethodEvent;
import javax.swing.plaf.ComponentUI;
import java.awt.AWTKeyStroke;
import javax.swing.JRootPane;
import java.awt.FontMetrics;
import java.awt.BufferCapabilities;
import java.awt.image.ImageObserver;
import java.awt.im.InputContext;
import java.awt.event.KeyListener;
import java.awt.event.HierarchyEvent;
import javax.swing.ComponentInputMap;
import java.awt.image.ImageProducer;
import java.awt.event.FocusEvent;
import java.io.PrintStream;
import java.awt.im.InputMethodRequests;
import javax.swing.TransferHandler;
import javax.swing.JToolTip;
import javax.swing.InputMap;
import java.io.PrintWriter;
import java.awt.Insets;
import javax.swing.event.AncestorListener;
import javax.swing.ActionMap;
import javax.swing.JPopupMenu;
import java.awt.image.BufferStrategy;
import java.awt.event.InputMethodListener;
import java.awt.Font;
import java.awt.PopupMenu;
import javax.swing.KeyStroke;
import java.awt.event.HierarchyBoundsListener;
import java.awt.Color;
import java.awt.FocusTraversalPolicy;
import java.awt.PointerInfo;
import java.awt.event.KeyEvent;
import javax.swing.InputVerifier;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.AWTEvent;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.ColorModel;
import javax.swing.border.Border;
import java.awt.event.ContainerListener;
import java.awt.event.ContainerEvent;
import javax.accessibility.AccessibleStateSet;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseEvent;
import javax.swing.plaf.PanelUI;
import java.util.Locale;
import java.beans.PropertyChangeListener;
import sun.java2d.pipe.Region;
import java.awt.Window;
import java.awt.peer.ComponentPeer;
import java.awt.Image;
import java.awt.Event;
import java.awt.dnd.DropTarget;
import java.awt.LayoutManager;
import java.util.Set;
import java.awt.Toolkit;
import java.awt.Rectangle;
import java.awt.GraphicsConfiguration;
import java.awt.Cursor;
import javax.accessibility.Accessible;
import java.awt.Component;
import java.awt.Point;
import java.security.AccessControlContext;
import java.awt.Graphics;
import java.awt.event.FocusListener;
import java.beans.VetoableChangeListener;
import java.awt.event.MouseWheelListener;
import java.awt.Dimension;
import java.awt.ComponentOrientation;
import java.awt.event.HierarchyListener;
import java.awt.Container;
import groovy.lang.GroovyShell;
import groovy.lang.Binding;
import java.util.concurrent.TimeUnit;
import groovy.lang.Reference;
import groovy.lang.Closure;
import org.codehaus.groovy.runtime.GeneratedClosure;
import groovy.ui.SystemOutputInterceptor;
import org.codehaus.groovy.runtime.BytecodeInterface8;
import org.codehaus.groovy.runtime.ArrayUtil;
import javax.swing.JOptionPane;
import org.codehaus.groovy.runtime.callsite.CallSiteArray;
import org.codehaus.groovy.runtime.GStringImpl;
import org.codehaus.groovy.runtime.callsite.CallSite;
import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JSplitPane;
import java.text.NumberFormat;
import javax.swing.JLabel;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import net.miginfocom.swing.MigLayout;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import java.lang.ref.SoftReference;
import groovy.lang.MetaClass;
import org.codehaus.groovy.reflection.ClassInfo;
import org.fife.ui.rtextarea.RTextScrollPane;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import com.primatest.recorder.Recorder;
import javax.swing.JScrollPane;
import com.primatest.objectfinder.LookingGlass;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import groovy.lang.GroovyObject;
import javax.swing.JPanel;

public class CodeTab extends JPanel implements GroovyObject
{
    private RSyntaxTextArea textArea;
    private JTextArea outputText;
    private MainWindow mainWindow;
    private Object codeTab;
    private JTextField driverName;
    private JFormattedTextField timeoutValue;
    private LookingGlass glass;
    private JScrollPane outputView;
    private Recorder recorder;
    private boolean recording;
    private boolean running;
    private ImageIcon recordIcon;
    private ImageIcon stopIcon;
    private ImageIcon playIcon;
    private JButton executeBtn;
    private RTextScrollPane codeView;
    private Object execThread;
    private boolean firstActionRecorded;
    private Object lastURL;
    private String selectedImports;
    private static /* synthetic */ ClassInfo $staticClassInfo;
    public static transient /* synthetic */ boolean __$stMC;
    private transient /* synthetic */ MetaClass metaClass;
    public static /* synthetic */ long __timeStamp;
    public static /* synthetic */ long __timeStamp__239_neverHappen1397742965741;
    private static /* synthetic */ SoftReference $callSiteArray;
    
    public CodeTab(final Object mainWin) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        this.codeTab = this;
        this.glass = (LookingGlass)ScriptBytecodeAdapter.castToType(null, LookingGlass.class);
        this.recording = false;
        this.running = false;
        this.firstActionRecorded = false;
        this.selectedImports = "";
        this.metaClass = this.$getStaticMetaClass();
        this.mainWindow = (MainWindow)ScriptBytecodeAdapter.castToType(mainWin, MainWindow.class);
        $getCallSiteArray[0].callCurrent(this, $getCallSiteArray[1].callConstructor(MigLayout.class));
        this.textArea = (RSyntaxTextArea)ScriptBytecodeAdapter.castToType($getCallSiteArray[2].callConstructor(RSyntaxTextArea.class, 10, 275), RSyntaxTextArea.class);
        $getCallSiteArray[3].call(this.textArea, $getCallSiteArray[4].callGetProperty(SyntaxConstants.class));
        $getCallSiteArray[5].call(this.textArea, true);
        $getCallSiteArray[6].call(this.textArea, true);
        final RTextScrollPane sp = (RTextScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[7].callConstructor(RTextScrollPane.class, this.textArea), RTextScrollPane.class);
        $getCallSiteArray[8].call(sp, true);
        this.codeView = (RTextScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[9].callConstructor(RTextScrollPane.class, this.textArea), RTextScrollPane.class);
        final ImageIcon currentActionIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[10].callConstructor(ImageIcon.class, $getCallSiteArray[11].call($getCallSiteArray[12].callGetProperty(this.mainWindow), "/images/arrow_right_green.png")), ImageIcon.class);
        $getCallSiteArray[13].call($getCallSiteArray[14].callGetProperty(this.codeView), true);
        $getCallSiteArray[15].call($getCallSiteArray[16].callGetProperty(this.codeView), currentActionIcon);
        final JLabel nameLabel = (JLabel)ScriptBytecodeAdapter.castToType($getCallSiteArray[17].callConstructor(JLabel.class, "Driver variable name:"), JLabel.class);
        this.driverName = (JTextField)ScriptBytecodeAdapter.castToType($getCallSiteArray[18].callConstructor(JTextField.class, 15), JTextField.class);
        $getCallSiteArray[19].call(this.driverName, "driver");
        final JLabel timeoutLabel = (JLabel)ScriptBytecodeAdapter.castToType($getCallSiteArray[20].callConstructor(JLabel.class, "Element Timeout:"), JLabel.class);
        this.timeoutValue = (JFormattedTextField)ScriptBytecodeAdapter.castToType($getCallSiteArray[21].callConstructor(JFormattedTextField.class, $getCallSiteArray[22].call(NumberFormat.class)), JFormattedTextField.class);
        $getCallSiteArray[23].call(this.timeoutValue, 4);
        $getCallSiteArray[24].call(this.timeoutValue, "10");
        this.outputText = (JTextArea)ScriptBytecodeAdapter.castToType($getCallSiteArray[25].callConstructor(JTextArea.class, 10, 275), JTextArea.class);
        this.outputView = (JScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[26].callConstructor(JScrollPane.class, this.outputText), JScrollPane.class);
        final JSplitPane splitPane = (JSplitPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[27].callConstructor(JSplitPane.class, $getCallSiteArray[28].callGetProperty(JSplitPane.class), this.codeView, this.outputView), JSplitPane.class);
        $getCallSiteArray[29].call(splitPane, true);
        $getCallSiteArray[30].call(splitPane, 250);
        this.recordIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[31].callConstructor(ImageIcon.class, $getCallSiteArray[32].call($getCallSiteArray[33].callGetProperty(this.mainWindow), "/images/record.png")), ImageIcon.class);
        final ImageIcon listIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[34].callConstructor(ImageIcon.class, $getCallSiteArray[35].call($getCallSiteArray[36].callGetProperty(this.mainWindow), "/images/list.png")), ImageIcon.class);
        this.stopIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[37].callConstructor(ImageIcon.class, $getCallSiteArray[38].call($getCallSiteArray[39].callGetProperty(this.mainWindow), "/images/stop.png")), ImageIcon.class);
        this.playIcon = (ImageIcon)ScriptBytecodeAdapter.castToType($getCallSiteArray[40].callConstructor(ImageIcon.class, $getCallSiteArray[41].call($getCallSiteArray[42].callGetProperty(this.mainWindow), "/images/play.png")), ImageIcon.class);
        final JButton importBtn = (JButton)ScriptBytecodeAdapter.castToType($getCallSiteArray[43].callConstructor(JButton.class, listIcon), JButton.class);
        $getCallSiteArray[44].call(importBtn, "Set your imports for the script.");
        this.executeBtn = (JButton)ScriptBytecodeAdapter.castToType($getCallSiteArray[45].callConstructor(JButton.class, this.playIcon), JButton.class);
        final JButton recordBtn = (JButton)ScriptBytecodeAdapter.castToType($getCallSiteArray[46].callConstructor(recordBtn.class, this, this.recordIcon), JButton.class);
        $getCallSiteArray[47].call(this.executeBtn, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent actionEvent) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[0].callGroovyObjectGetProperty(this))) {
                    $getCallSiteArray[1].call($getCallSiteArray[2].callGroovyObjectGetProperty(this));
                    ScriptBytecodeAdapter.setGroovyObjectProperty(false, CodeTab$1.class, this, "running");
                    return;
                }
                $getCallSiteArray[3].callCurrent(this);
                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[4].callGroovyObjectGetProperty(this))) {
                    $getCallSiteArray[5].call($getCallSiteArray[6].callGroovyObjectGetProperty(this), $getCallSiteArray[7].callGetProperty($getCallSiteArray[8].callGroovyObjectGetProperty(this)));
                }
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != CodeTab$1.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = CodeTab$1.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (CodeTab$1.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                CodeTab$1.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[9];
                $createCallSiteArray_1(names);
                return new CallSiteArray(CodeTab$1.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (CodeTab$1.$callSiteArray == null || ($createCallSiteArray = CodeTab$1.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    CodeTab$1.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        $getCallSiteArray[48].call(importBtn, new ActionListener() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            public static transient /* synthetic */ boolean __$stMC;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void actionPerformed(final ActionEvent actionEvent) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                final JTextArea textField = (JTextArea)ScriptBytecodeAdapter.castToType($getCallSiteArray[0].callConstructor(JTextArea.class, 10, 45), JTextArea.class);
                final JPanel msgPanel = (JPanel)ScriptBytecodeAdapter.castToType($getCallSiteArray[1].callConstructor(JPanel.class), JPanel.class);
                final JScrollPane scrollPane = (JScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[2].callConstructor(JScrollPane.class, textField), JScrollPane.class);
                $getCallSiteArray[3].call(textField, $getCallSiteArray[4].callGroovyObjectGetProperty(this));
                $getCallSiteArray[5].call(msgPanel, $getCallSiteArray[6].callConstructor(MigLayout.class));
                $getCallSiteArray[7].call(msgPanel, $getCallSiteArray[8].callConstructor(JLabel.class, $getCallSiteArray[9].call("<html>Default Imports:<br/>import org.openqa.selenium.support.ui.*;<br/>import org.openqa.selenium.*;<br/>import static org.junit.Assert.*;", "<br/>Place your own jars to lib directory for them to become available.</html>")), "wrap");
                $getCallSiteArray[10].call(msgPanel, scrollPane);
                final int choice = DefaultTypeTransformation.intUnbox($getCallSiteArray[11].call(JOptionPane.class, ArrayUtil.createArray($getCallSiteArray[12].callGroovyObjectGetProperty(this), msgPanel, "Selected Imports", $getCallSiteArray[13].callGetProperty(JOptionPane.class), $getCallSiteArray[14].callGetProperty(JOptionPane.class))));
                if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !CodeTab$2.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                    if (ScriptBytecodeAdapter.compareEqual(choice, $getCallSiteArray[17].callGetProperty(JOptionPane.class))) {
                        ScriptBytecodeAdapter.setGroovyObjectProperty(ScriptBytecodeAdapter.castToType($getCallSiteArray[18].call(textField), String.class), CodeTab$2.class, this, "selectedImports");
                    }
                }
                else if (ScriptBytecodeAdapter.compareEqual(choice, $getCallSiteArray[15].callGetProperty(JOptionPane.class))) {
                    ScriptBytecodeAdapter.setGroovyObjectProperty(ScriptBytecodeAdapter.castToType($getCallSiteArray[16].call(textField), String.class), CodeTab$2.class, this, "selectedImports");
                }
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != CodeTab$2.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = CodeTab$2.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (CodeTab$2.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                CodeTab$2.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[19];
                $createCallSiteArray_1(names);
                return new CallSiteArray(CodeTab$2.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (CodeTab$2.$callSiteArray == null || ($createCallSiteArray = CodeTab$2.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    CodeTab$2.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        final JPanel topPanel = (JPanel)ScriptBytecodeAdapter.castToType($getCallSiteArray[49].callConstructor(JPanel.class), JPanel.class);
        $getCallSiteArray[50].call(topPanel, this.executeBtn);
        $getCallSiteArray[51].call(topPanel, recordBtn);
        $getCallSiteArray[52].call(topPanel, timeoutLabel);
        $getCallSiteArray[53].call(topPanel, this.timeoutValue);
        $getCallSiteArray[54].call(topPanel, nameLabel);
        $getCallSiteArray[55].call(topPanel, this.driverName);
        $getCallSiteArray[56].call(topPanel, importBtn);
        $getCallSiteArray[57].callCurrent(this, topPanel, "wrap");
        $getCallSiteArray[58].callCurrent(this, splitPane, "span, grow,height 200:1200:");
        this.recorder = (Recorder)ScriptBytecodeAdapter.castToType($getCallSiteArray[59].callConstructor(Recorder.class), Recorder.class);
    }
    
    public void executeScript() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        $getCallSiteArray[60].call(this.outputText, "");
        if (BytecodeInterface8.isOrigZ() && !CodeTab.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual(this.glass, null)) {
                $getCallSiteArray[63].call(JOptionPane.class, this.mainWindow, "Start Browser at Inspect tab.", "Error", $getCallSiteArray[64].callGetProperty(JOptionPane.class));
                return;
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual(this.glass, null)) {
            $getCallSiteArray[61].call(JOptionPane.class, this.mainWindow, "Start Browser at Inspect tab.", "Error", $getCallSiteArray[62].callGetProperty(JOptionPane.class));
            return;
        }
        if (this.recording) {
            $getCallSiteArray[65].call(JOptionPane.class, this.mainWindow, "Please stop recording first.", "Error", $getCallSiteArray[66].callGetProperty(JOptionPane.class));
            return;
        }
        final Reference systemOutInterceptor = new Reference($getCallSiteArray[67].callConstructor(SystemOutputInterceptor.class, new GeneratedClosure((Object)this, (Object)this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final String s) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                $getCallSiteArray[0].call($getCallSiteArray[1].callGroovyObjectGetProperty(this), $getCallSiteArray[2].call($getCallSiteArray[3].call($getCallSiteArray[4].callGroovyObjectGetProperty(this)), s));
                return false;
            }
            
            public Object call(final String s) {
                return $getCallSiteArray()[5].callCurrent(this, s);
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                CodeTab$_executeScript_closure1.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[6];
                $createCallSiteArray_1(names);
                return new CallSiteArray(CodeTab$_executeScript_closure1.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (CodeTab$_executeScript_closure1.$callSiteArray == null || ($createCallSiteArray = CodeTab$_executeScript_closure1.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    CodeTab$_executeScript_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        }));
        $getCallSiteArray[68].call(systemOutInterceptor.get());
        this.running = true;
        this.lastURL = null;
        $getCallSiteArray[69].call(this.textArea, false);
        $getCallSiteArray[70].call($getCallSiteArray[71].callGetProperty(this.mainWindow), false);
        $getCallSiteArray[72].call($getCallSiteArray[73].callGetProperty(this.mainWindow), false);
        this.firstActionRecorded = false;
        $getCallSiteArray[74].call($getCallSiteArray[75].call($getCallSiteArray[76].call($getCallSiteArray[77].callGroovyObjectGetProperty(this.glass))), $getCallSiteArray[78].call($getCallSiteArray[79].call(this.timeoutValue)), $getCallSiteArray[80].callGetProperty(TimeUnit.class));
        this.execThread = $getCallSiteArray[81].callConstructor(Thread.class, new Runnable() {
            private static /* synthetic */ ClassInfo $staticClassInfo;
            public static transient /* synthetic */ boolean __$stMC;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public void run() {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                final Reference lastLine = new Reference((T)(-1));
                final Object trackActions = new GeneratedClosure((Object)this, (Object)this) {
                    public static transient /* synthetic */ boolean __$stMC;
                    private static /* synthetic */ SoftReference $callSiteArray;
                    
                    public Object doCall(final Object line) {
                        final CallSite[] $getCallSiteArray = $getCallSiteArray();
                        if (BytecodeInterface8.isOrigZ() && !CodeTab$_3_run_closure1.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                            if (ScriptBytecodeAdapter.compareNotEqual(lastLine.get(), -1)) {
                                $getCallSiteArray[3].call($getCallSiteArray[4].callGetProperty($getCallSiteArray[5].callGroovyObjectGetProperty(this)), lastLine.get());
                            }
                        }
                        else if (ScriptBytecodeAdapter.compareNotEqual(lastLine.get(), -1)) {
                            $getCallSiteArray[0].call($getCallSiteArray[1].callGetProperty($getCallSiteArray[2].callGroovyObjectGetProperty(this)), lastLine.get());
                        }
                        lastLine.set(ScriptBytecodeAdapter.castToType(line, Integer.class));
                        $getCallSiteArray[6].call($getCallSiteArray[7].callGetProperty($getCallSiteArray[8].callGroovyObjectGetProperty(this)), line);
                        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !CodeTab$_3_run_closure1.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                            if (ScriptBytecodeAdapter.compareNotEqual(line, 0)) {
                                $getCallSiteArray[15].call($getCallSiteArray[16].callGroovyObjectGetProperty(this), $getCallSiteArray[17].call($getCallSiteArray[18].call($getCallSiteArray[19].callGroovyObjectGetProperty(this), $getCallSiteArray[20].call(line, 1)), 1));
                            }
                        }
                        else if (ScriptBytecodeAdapter.compareNotEqual(line, 0)) {
                            $getCallSiteArray[9].call($getCallSiteArray[10].callGroovyObjectGetProperty(this), $getCallSiteArray[11].call($getCallSiteArray[12].call($getCallSiteArray[13].callGroovyObjectGetProperty(this), $getCallSiteArray[14].call(line, 1)), 1));
                        }
                        return $getCallSiteArray[21].callGroovyObjectGetProperty($getCallSiteArray[22].callGroovyObjectGetProperty(this));
                    }
                    
                    public Integer getLastLine() {
                        $getCallSiteArray();
                        return (Integer)ScriptBytecodeAdapter.castToType(lastLine.get(), Integer.class);
                    }
                    
                    public static /* synthetic */ void __$swapInit() {
                        $getCallSiteArray();
                        CodeTab$_3_run_closure1.$callSiteArray = null;
                    }
                    
                    static {
                        __$swapInit();
                    }
                    
                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                        final String[] names = new String[23];
                        $createCallSiteArray_1(names);
                        return new CallSiteArray(CodeTab$_3_run_closure1.class, names);
                    }
                    
                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                        CallSiteArray $createCallSiteArray;
                        if (CodeTab$_3_run_closure1.$callSiteArray == null || ($createCallSiteArray = CodeTab$_3_run_closure1.$callSiteArray.get()) == null) {
                            $createCallSiteArray = $createCallSiteArray();
                            CodeTab$_3_run_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                        }
                        return $createCallSiteArray.array;
                    }
                };
                final Binding binding = (Binding)ScriptBytecodeAdapter.castToType($getCallSiteArray[0].callConstructor(Binding.class), Binding.class);
                $getCallSiteArray[1].call(binding, $getCallSiteArray[2].call($getCallSiteArray[3].callGroovyObjectGetProperty(this)), $getCallSiteArray[4].callGroovyObjectGetProperty($getCallSiteArray[5].callGroovyObjectGetProperty(this)));
                $getCallSiteArray[6].call(binding, "trackActions", trackActions);
                final GroovyShell shell = (GroovyShell)ScriptBytecodeAdapter.castToType($getCallSiteArray[7].callConstructor(GroovyShell.class, binding), GroovyShell.class);
                final Reference script = new Reference((T)"");
                final Reference index = new Reference((T)0);
                $getCallSiteArray[8].call($getCallSiteArray[9].call($getCallSiteArray[10].callGroovyObjectGetProperty(this)), new GeneratedClosure((Object)this, (Object)this) {
                    public static transient /* synthetic */ boolean __$stMC;
                    private static /* synthetic */ SoftReference $callSiteArray;
                    
                    public Object doCall(final Object line) {
                        final Reference line2 = new Reference((T)line);
                        final CallSite[] $getCallSiteArray = $getCallSiteArray();
                        final int found = DefaultTypeTransformation.intUnbox($getCallSiteArray[0].call(line2.get(), $getCallSiteArray[1].call($getCallSiteArray[2].callGroovyObjectGetProperty(this))));
                        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !CodeTab$_3_run_closure2.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                            if (ScriptBytecodeAdapter.compareNotEqual(found, -1)) {
                                if (found == 0) {
                                    line2.set($getCallSiteArray[15].call(line2.get(), $getCallSiteArray[16].call($getCallSiteArray[17].call($getCallSiteArray[18].callGroovyObjectGetProperty(this)), "."), new GStringImpl(new Object[] { index.get() }, new String[] { "trackActions(", ")." })));
                                }
                                $getCallSiteArray[19].call($getCallSiteArray[20].call(line2.get(), new GStringImpl(new Object[] { $getCallSiteArray[21].call($getCallSiteArray[22].callGroovyObjectGetProperty(this)) }, new String[] { "[^A-Za-z]", "[.]" })), new GeneratedClosure((Object)this, this.getThisObject()) {
                                    private /* synthetic */ Reference index;
                                    private /* synthetic */ Reference line;
                                    private static /* synthetic */ SoftReference $callSiteArray;
                                    
                                    public Object doCall(final Object it) {
                                        final CallSite[] $getCallSiteArray = $getCallSiteArray();
                                        final Object call = $getCallSiteArray[0].call(this.line.get(), $getCallSiteArray[1].call(it, ScriptBytecodeAdapter.createRange(1, $getCallSiteArray[2].call($getCallSiteArray[3].call(it), 1), true)), new GStringImpl(new Object[] { this.index.get() }, new String[] { "trackActions(", ")." }));
                                        this.line.set(call);
                                        return call;
                                    }
                                    
                                    public Integer getIndex() {
                                        $getCallSiteArray();
                                        return (Integer)ScriptBytecodeAdapter.castToType(this.index.get(), Integer.class);
                                    }
                                    
                                    public Object getLine() {
                                        $getCallSiteArray();
                                        return this.line.get();
                                    }
                                    
                                    public Object doCall() {
                                        $getCallSiteArray();
                                        return this.doCall(null);
                                    }
                                    
                                    public static /* synthetic */ void __$swapInit() {
                                        $getCallSiteArray();
                                        CodeTab$_3_run_closure2_closure5.$callSiteArray = null;
                                    }
                                    
                                    static {
                                        __$swapInit();
                                    }
                                    
                                    private static /* synthetic */ void $createCallSiteArray_1(final String[] array) {
                                        array[0] = "replaceFirst";
                                        array[1] = "getAt";
                                        array[2] = "minus";
                                        array[3] = "size";
                                    }
                                    
                                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                                        final String[] names = new String[4];
                                        $createCallSiteArray_1(names);
                                        return new CallSiteArray(CodeTab$_3_run_closure2_closure5.class, names);
                                    }
                                    
                                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                                        CallSiteArray $createCallSiteArray;
                                        if (CodeTab$_3_run_closure2_closure5.$callSiteArray == null || ($createCallSiteArray = CodeTab$_3_run_closure2_closure5.$callSiteArray.get()) == null) {
                                            $createCallSiteArray = $createCallSiteArray();
                                            CodeTab$_3_run_closure2_closure5.$callSiteArray = new SoftReference($createCallSiteArray);
                                        }
                                        return $createCallSiteArray.array;
                                    }
                                });
                                script.set($getCallSiteArray[23].call($getCallSiteArray[24].call(script.get(), line2.get()), "\r\n"));
                            }
                            else {
                                script.set($getCallSiteArray[25].call($getCallSiteArray[26].call(script.get(), line2.get()), "\r\n"));
                            }
                        }
                        else if (ScriptBytecodeAdapter.compareNotEqual(found, -1)) {
                            if (found == 0) {
                                line2.set($getCallSiteArray[3].call(line2.get(), $getCallSiteArray[4].call($getCallSiteArray[5].call($getCallSiteArray[6].callGroovyObjectGetProperty(this)), "."), new GStringImpl(new Object[] { index.get() }, new String[] { "trackActions(", ")." })));
                            }
                            $getCallSiteArray[7].call($getCallSiteArray[8].call(line2.get(), new GStringImpl(new Object[] { $getCallSiteArray[9].call($getCallSiteArray[10].callGroovyObjectGetProperty(this)) }, new String[] { "[^A-Za-z]", "[.]" })), new GeneratedClosure((Object)this, this.getThisObject()) {
                                private /* synthetic */ Reference index = index;
                                private /* synthetic */ Reference line = line;
                                private static /* synthetic */ SoftReference $callSiteArray;
                                
                                public Object doCall(final Object it) {
                                    final CallSite[] $getCallSiteArray = $getCallSiteArray();
                                    final Object call = $getCallSiteArray[0].call(line2.get(), $getCallSiteArray[1].call(it, ScriptBytecodeAdapter.createRange(1, $getCallSiteArray[2].call($getCallSiteArray[3].call(it), 1), true)), new GStringImpl(new Object[] { index.get() }, new String[] { "trackActions(", ")." }));
                                    line2.set(call);
                                    return call;
                                }
                                
                                public Integer getIndex() {
                                    $getCallSiteArray();
                                    return (Integer)ScriptBytecodeAdapter.castToType(index.get(), Integer.class);
                                }
                                
                                public Object getLine() {
                                    $getCallSiteArray();
                                    return line2.get();
                                }
                                
                                public Object doCall() {
                                    $getCallSiteArray();
                                    return this.doCall(null);
                                }
                                
                                public static /* synthetic */ void __$swapInit() {
                                    $getCallSiteArray();
                                    CodeTab$_3_run_closure2_closure5.$callSiteArray = null;
                                }
                                
                                static {
                                    __$swapInit();
                                }
                                
                                private static /* synthetic */ void $createCallSiteArray_1(final String[] array) {
                                    array[0] = "replaceFirst";
                                    array[1] = "getAt";
                                    array[2] = "minus";
                                    array[3] = "size";
                                }
                                
                                private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                                    final String[] names = new String[4];
                                    $createCallSiteArray_1(names);
                                    return new CallSiteArray(CodeTab$_3_run_closure2_closure5.class, names);
                                }
                                
                                private static /* synthetic */ CallSite[] $getCallSiteArray() {
                                    CallSiteArray $createCallSiteArray;
                                    if (CodeTab$_3_run_closure2_closure5.$callSiteArray == null || ($createCallSiteArray = CodeTab$_3_run_closure2_closure5.$callSiteArray.get()) == null) {
                                        $createCallSiteArray = $createCallSiteArray();
                                        CodeTab$_3_run_closure2_closure5.$callSiteArray = new SoftReference($createCallSiteArray);
                                    }
                                    return $createCallSiteArray.array;
                                }
                            });
                            script.set($getCallSiteArray[11].call($getCallSiteArray[12].call(script.get(), line2.get()), "\r\n"));
                        }
                        else {
                            script.set($getCallSiteArray[13].call($getCallSiteArray[14].call(script.get(), line2.get()), "\r\n"));
                        }
                        final Object value;
                        index.set(ScriptBytecodeAdapter.castToType($getCallSiteArray[27].call(value = index.get()), Integer.class));
                        return value;
                    }
                    
                    public Integer getIndex() {
                        $getCallSiteArray();
                        return (Integer)ScriptBytecodeAdapter.castToType(index.get(), Integer.class);
                    }
                    
                    public Object getScript() {
                        $getCallSiteArray();
                        return script.get();
                    }
                    
                    public static /* synthetic */ void __$swapInit() {
                        $getCallSiteArray();
                        CodeTab$_3_run_closure2.$callSiteArray = null;
                    }
                    
                    static {
                        __$swapInit();
                    }
                    
                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                        final String[] names = new String[28];
                        $createCallSiteArray_1(names);
                        return new CallSiteArray(CodeTab$_3_run_closure2.class, names);
                    }
                    
                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                        CallSiteArray $createCallSiteArray;
                        if (CodeTab$_3_run_closure2.$callSiteArray == null || ($createCallSiteArray = CodeTab$_3_run_closure2.$callSiteArray.get()) == null) {
                            $createCallSiteArray = $createCallSiteArray();
                            CodeTab$_3_run_closure2.$callSiteArray = new SoftReference($createCallSiteArray);
                        }
                        return $createCallSiteArray.array;
                    }
                });
                final Reference imports = new Reference((T)"");
                $getCallSiteArray[11].call($getCallSiteArray[12].callGroovyObjectGetProperty(this), new GeneratedClosure((Object)this, (Object)this) {
                    private static /* synthetic */ SoftReference $callSiteArray;
                    
                    public Object doCall(final Object it) {
                        final CallSite[] $getCallSiteArray = $getCallSiteArray();
                        if (!DefaultTypeTransformation.booleanUnbox($getCallSiteArray[0].call(it, "import"))) {
                            return null;
                        }
                        if (!DefaultTypeTransformation.booleanUnbox($getCallSiteArray[1].call(it, ";"))) {
                            final Object call = $getCallSiteArray[2].call($getCallSiteArray[3].call(imports.get(), ";"), it);
                            imports.set(call);
                            return call;
                        }
                        final Object call2 = $getCallSiteArray[4].call(imports.get(), it);
                        imports.set(call2);
                        return call2;
                    }
                    
                    public Object getImports() {
                        $getCallSiteArray();
                        return imports.get();
                    }
                    
                    public Object doCall() {
                        $getCallSiteArray();
                        return this.doCall(null);
                    }
                    
                    public static /* synthetic */ void __$swapInit() {
                        $getCallSiteArray();
                        CodeTab$_3_run_closure3.$callSiteArray = null;
                    }
                    
                    static {
                        __$swapInit();
                    }
                    
                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                        final String[] names = new String[5];
                        $createCallSiteArray_1(names);
                        return new CallSiteArray(CodeTab$_3_run_closure3.class, names);
                    }
                    
                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                        CallSiteArray $createCallSiteArray;
                        if (CodeTab$_3_run_closure3.$callSiteArray == null || ($createCallSiteArray = CodeTab$_3_run_closure3.$callSiteArray.get()) == null) {
                            $createCallSiteArray = $createCallSiteArray();
                            CodeTab$_3_run_closure3.$callSiteArray = new SoftReference($createCallSiteArray);
                        }
                        return $createCallSiteArray.array;
                    }
                });
                script.set($getCallSiteArray[13].call($getCallSiteArray[14].call($getCallSiteArray[15].call("import org.openqa.selenium.support.ui.*;import org.openqa.selenium.*;import static org.junit.Assert.*;", imports.get()), "\r\n"), script.get()));
                try {
                    try {
                        $getCallSiteArray[16].call(shell, script.get());
                    }
                    catch (Error ex) {
                        $getCallSiteArray[17].callCurrent(this, $getCallSiteArray[18].callGetProperty(ex));
                    }
                    catch (Exception ex2) {
                        $getCallSiteArray[19].callCurrent(this, $getCallSiteArray[20].call(ex2));
                        $getCallSiteArray[21].call($getCallSiteArray[22].call(ex2), new GeneratedClosure((Object)this, (Object)this) {
                            private static /* synthetic */ SoftReference $callSiteArray;
                            
                            public Object doCall(final Object trace) {
                                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                                if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[0].call($getCallSiteArray[1].call($getCallSiteArray[2].call(trace)), "Script1.run"))) {
                                    final int lineNumber = DefaultTypeTransformation.intUnbox($getCallSiteArray[3].call($getCallSiteArray[4].call($getCallSiteArray[5].call($getCallSiteArray[6].call($getCallSiteArray[7].call($getCallSiteArray[8].call(trace), ":"), 1), "\\)"), 0)));
                                    return $getCallSiteArray[9].callCurrent(this, new GStringImpl(new Object[] { $getCallSiteArray[10].call(lineNumber, 1) }, new String[] { "ERROR LINE: ", "" }));
                                }
                                return null;
                            }
                            
                            public static /* synthetic */ void __$swapInit() {
                                $getCallSiteArray();
                                CodeTab$_3_run_closure4.$callSiteArray = null;
                            }
                            
                            static {
                                __$swapInit();
                            }
                            
                            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                                final String[] names = new String[11];
                                $createCallSiteArray_1(names);
                                return new CallSiteArray(CodeTab$_3_run_closure4.class, names);
                            }
                            
                            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                                CallSiteArray $createCallSiteArray;
                                if (CodeTab$_3_run_closure4.$callSiteArray == null || ($createCallSiteArray = CodeTab$_3_run_closure4.$callSiteArray.get()) == null) {
                                    $createCallSiteArray = $createCallSiteArray();
                                    CodeTab$_3_run_closure4.$callSiteArray = new SoftReference($createCallSiteArray);
                                }
                                return $createCallSiteArray.array;
                            }
                        });
                    }
                    $getCallSiteArray[23].call($getCallSiteArray[24].callGroovyObjectGetProperty(this), 0);
                    $getCallSiteArray[25].call(systemOutInterceptor.get());
                    ScriptBytecodeAdapter.setGroovyObjectProperty(false, CodeTab$3.class, this, "running");
                    $getCallSiteArray[26].call($getCallSiteArray[27].callGroovyObjectGetProperty(this), $getCallSiteArray[28].callGetProperty($getCallSiteArray[29].callGroovyObjectGetProperty(this)));
                    $getCallSiteArray[30].call($getCallSiteArray[31].callGetProperty($getCallSiteArray[32].callGroovyObjectGetProperty(this)), true);
                    $getCallSiteArray[33].call($getCallSiteArray[34].callGetProperty($getCallSiteArray[35].callGroovyObjectGetProperty(this)), true);
                    if (BytecodeInterface8.isOrigZ() && !CodeTab$3.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                        if (ScriptBytecodeAdapter.compareNotEqual(lastLine.get(), -1)) {
                            $getCallSiteArray[39].call($getCallSiteArray[40].callGetProperty($getCallSiteArray[41].callGroovyObjectGetProperty(this)), lastLine.get());
                        }
                    }
                    else if (ScriptBytecodeAdapter.compareNotEqual(lastLine.get(), -1)) {
                        $getCallSiteArray[36].call($getCallSiteArray[37].callGetProperty($getCallSiteArray[38].callGroovyObjectGetProperty(this)), lastLine.get());
                    }
                    $getCallSiteArray[42].call($getCallSiteArray[43].callGroovyObjectGetProperty(this), true);
                    $getCallSiteArray[44].call($getCallSiteArray[45].callGroovyObjectGetProperty(this), true);
                }
                finally {
                    $getCallSiteArray[46].call($getCallSiteArray[47].callGroovyObjectGetProperty(this), 0);
                    $getCallSiteArray[48].call(systemOutInterceptor.get());
                    ScriptBytecodeAdapter.setGroovyObjectProperty(false, CodeTab$3.class, this, "running");
                    $getCallSiteArray[49].call($getCallSiteArray[50].callGroovyObjectGetProperty(this), $getCallSiteArray[51].callGetProperty($getCallSiteArray[52].callGroovyObjectGetProperty(this)));
                    $getCallSiteArray[53].call($getCallSiteArray[54].callGetProperty($getCallSiteArray[55].callGroovyObjectGetProperty(this)), true);
                    $getCallSiteArray[56].call($getCallSiteArray[57].callGetProperty($getCallSiteArray[58].callGroovyObjectGetProperty(this)), true);
                    if (BytecodeInterface8.isOrigZ() && !CodeTab$3.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                        if (ScriptBytecodeAdapter.compareNotEqual(lastLine.get(), -1)) {
                            $getCallSiteArray[62].call($getCallSiteArray[63].callGetProperty($getCallSiteArray[64].callGroovyObjectGetProperty(this)), lastLine.get());
                        }
                    }
                    else if (ScriptBytecodeAdapter.compareNotEqual(lastLine.get(), -1)) {
                        $getCallSiteArray[59].call($getCallSiteArray[60].callGetProperty($getCallSiteArray[61].callGroovyObjectGetProperty(this)), lastLine.get());
                    }
                    $getCallSiteArray[65].call($getCallSiteArray[66].callGroovyObjectGetProperty(this), true);
                    $getCallSiteArray[67].call($getCallSiteArray[68].callGroovyObjectGetProperty(this), true);
                }
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != CodeTab$3.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = CodeTab$3.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (CodeTab$3.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                CodeTab$3.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[69];
                $createCallSiteArray_1(names);
                return new CallSiteArray(CodeTab$3.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (CodeTab$3.$callSiteArray == null || ($createCallSiteArray = CodeTab$3.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    CodeTab$3.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        });
        $getCallSiteArray[82].call(this.execThread);
    }
    
    protected /* synthetic */ MetaClass $getStaticMetaClass() {
        if (this.getClass() != CodeTab.class) {
            return ScriptBytecodeAdapter.initMetaClass(this);
        }
        ClassInfo $staticClassInfo = CodeTab.$staticClassInfo;
        if ($staticClassInfo == null) {
            $staticClassInfo = (CodeTab.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
        }
        return $staticClassInfo.getMetaClass();
    }
    
    public static /* synthetic */ void __$swapInit() {
        $getCallSiteArray();
        CodeTab.$callSiteArray = null;
    }
    
    static {
        __$swapInit();
        CodeTab.__timeStamp__239_neverHappen1397742965741 = 0L;
        CodeTab.__timeStamp = 1397742965741L;
    }
    
    public RSyntaxTextArea getTextArea() {
        return this.textArea;
    }
    
    public void setTextArea(final RSyntaxTextArea textArea) {
        this.textArea = textArea;
    }
    
    public JTextArea getOutputText() {
        return this.outputText;
    }
    
    public void setOutputText(final JTextArea outputText) {
        this.outputText = outputText;
    }
    
    public MainWindow getMainWindow() {
        return this.mainWindow;
    }
    
    public void setMainWindow(final MainWindow mainWindow) {
        this.mainWindow = mainWindow;
    }
    
    public Object getCodeTab() {
        return this.codeTab;
    }
    
    public void setCodeTab(final Object codeTab) {
        this.codeTab = codeTab;
    }
    
    public JTextField getDriverName() {
        return this.driverName;
    }
    
    public void setDriverName(final JTextField driverName) {
        this.driverName = driverName;
    }
    
    public JFormattedTextField getTimeoutValue() {
        return this.timeoutValue;
    }
    
    public void setTimeoutValue(final JFormattedTextField timeoutValue) {
        this.timeoutValue = timeoutValue;
    }
    
    public LookingGlass getGlass() {
        return this.glass;
    }
    
    public void setGlass(final LookingGlass glass) {
        this.glass = glass;
    }
    
    public JScrollPane getOutputView() {
        return this.outputView;
    }
    
    public void setOutputView(final JScrollPane outputView) {
        this.outputView = outputView;
    }
    
    public Recorder getRecorder() {
        return this.recorder;
    }
    
    public void setRecorder(final Recorder recorder) {
        this.recorder = recorder;
    }
    
    public boolean getRecording() {
        return this.recording;
    }
    
    public boolean isRecording() {
        return this.recording;
    }
    
    public void setRecording(final boolean recording) {
        this.recording = recording;
    }
    
    public boolean getRunning() {
        return this.running;
    }
    
    public boolean isRunning() {
        return this.running;
    }
    
    public void setRunning(final boolean running) {
        this.running = running;
    }
    
    public ImageIcon getRecordIcon() {
        return this.recordIcon;
    }
    
    public void setRecordIcon(final ImageIcon recordIcon) {
        this.recordIcon = recordIcon;
    }
    
    public ImageIcon getStopIcon() {
        return this.stopIcon;
    }
    
    public void setStopIcon(final ImageIcon stopIcon) {
        this.stopIcon = stopIcon;
    }
    
    public ImageIcon getPlayIcon() {
        return this.playIcon;
    }
    
    public void setPlayIcon(final ImageIcon playIcon) {
        this.playIcon = playIcon;
    }
    
    public JButton getExecuteBtn() {
        return this.executeBtn;
    }
    
    public void setExecuteBtn(final JButton executeBtn) {
        this.executeBtn = executeBtn;
    }
    
    public RTextScrollPane getCodeView() {
        return this.codeView;
    }
    
    public void setCodeView(final RTextScrollPane codeView) {
        this.codeView = codeView;
    }
    
    public Object getExecThread() {
        return this.execThread;
    }
    
    public void setExecThread(final Object execThread) {
        this.execThread = execThread;
    }
    
    public boolean getFirstActionRecorded() {
        return this.firstActionRecorded;
    }
    
    public boolean isFirstActionRecorded() {
        return this.firstActionRecorded;
    }
    
    public void setFirstActionRecorded(final boolean firstActionRecorded) {
        this.firstActionRecorded = firstActionRecorded;
    }
    
    public Object getLastURL() {
        return this.lastURL;
    }
    
    public void setLastURL(final Object lastURL) {
        this.lastURL = lastURL;
    }
    
    public String getSelectedImports() {
        return this.selectedImports;
    }
    
    public void setSelectedImports(final String selectedImports) {
        this.selectedImports = selectedImports;
    }
    
    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
        final String[] names = new String[83];
        $createCallSiteArray_1(names);
        return new CallSiteArray(CodeTab.class, names);
    }
    
    private static /* synthetic */ CallSite[] $getCallSiteArray() {
        CallSiteArray $createCallSiteArray;
        if (CodeTab.$callSiteArray == null || ($createCallSiteArray = CodeTab.$callSiteArray.get()) == null) {
            $createCallSiteArray = $createCallSiteArray();
            CodeTab.$callSiteArray = new SoftReference($createCallSiteArray);
        }
        return $createCallSiteArray.array;
    }
    
    public class recordBtn extends JButton implements ActionListener, GroovyObject
    {
        private static /* synthetic */ ClassInfo $staticClassInfo;
        public static transient /* synthetic */ boolean __$stMC;
        private transient /* synthetic */ MetaClass metaClass;
        private static /* synthetic */ SoftReference $callSiteArray;
        
        public recordBtn(final ImageIcon icon) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            this.metaClass = this.$getStaticMetaClass();
            ScriptBytecodeAdapter.invokeMethodOnSuperN(JButton.class, this, "setIcon", new Object[] { icon });
            $getCallSiteArray[0].callCurrent(this, this);
        }
        
        public void actionPerformed(final ActionEvent e) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[1].callGetProperty($getCallSiteArray[2].callGroovyObjectGetProperty(this)))) {
                ScriptBytecodeAdapter.setProperty(false, null, $getCallSiteArray[3].callGroovyObjectGetProperty(this), "recording");
                $getCallSiteArray[4].call($getCallSiteArray[5].callGetProperty($getCallSiteArray[6].callGroovyObjectGetProperty(this)));
                $getCallSiteArray[7].callCurrent(this, $getCallSiteArray[8].callGetProperty($getCallSiteArray[9].callGroovyObjectGetProperty(this)));
                $getCallSiteArray[10].call($getCallSiteArray[11].callGroovyObjectGetProperty($getCallSiteArray[12].callGroovyObjectGetProperty(this)), true);
                $getCallSiteArray[13].call($getCallSiteArray[14].callGroovyObjectGetProperty($getCallSiteArray[15].callGroovyObjectGetProperty(this)), true);
                return;
            }
            if (BytecodeInterface8.isOrigZ() && !recordBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[20].callGroovyObjectGetProperty(this), null)) {
                    $getCallSiteArray[21].call(JOptionPane.class, $getCallSiteArray[22].callGroovyObjectGetProperty(this), "Start Browser at Inspect tab.", "Error", $getCallSiteArray[23].callGetProperty(JOptionPane.class));
                    return;
                }
            }
            else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[16].callGroovyObjectGetProperty(this), null)) {
                $getCallSiteArray[17].call(JOptionPane.class, $getCallSiteArray[18].callGroovyObjectGetProperty(this), "Start Browser at Inspect tab.", "Error", $getCallSiteArray[19].callGetProperty(JOptionPane.class));
                return;
            }
            if (BytecodeInterface8.isOrigZ() && !recordBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[32].callGetProperty($getCallSiteArray[33].callGetProperty($getCallSiteArray[34].callGetProperty($getCallSiteArray[35].callGetProperty($getCallSiteArray[36].callGroovyObjectGetProperty(this))))), "internet explorer")) {
                    $getCallSiteArray[37].call(JOptionPane.class, $getCallSiteArray[38].callGroovyObjectGetProperty(this), "Recorder does not currently work with IE.", "Error", $getCallSiteArray[39].callGetProperty(JOptionPane.class));
                    return;
                }
            }
            else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[24].callGetProperty($getCallSiteArray[25].callGetProperty($getCallSiteArray[26].callGetProperty($getCallSiteArray[27].callGetProperty($getCallSiteArray[28].callGroovyObjectGetProperty(this))))), "internet explorer")) {
                $getCallSiteArray[29].call(JOptionPane.class, $getCallSiteArray[30].callGroovyObjectGetProperty(this), "Recorder does not currently work with IE.", "Error", $getCallSiteArray[31].callGetProperty(JOptionPane.class));
                return;
            }
            if (BytecodeInterface8.isOrigZ() && !recordBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[45].callGroovyObjectGetProperty($getCallSiteArray[46].callGroovyObjectGetProperty(this)), true)) {
                    $getCallSiteArray[47].call(JOptionPane.class, $getCallSiteArray[48].callGroovyObjectGetProperty(this), "Please stop inspecting elements by clicking on any of them.", "Error", $getCallSiteArray[49].callGetProperty(JOptionPane.class));
                    return;
                }
            }
            else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[40].callGroovyObjectGetProperty($getCallSiteArray[41].callGroovyObjectGetProperty(this)), true)) {
                $getCallSiteArray[42].call(JOptionPane.class, $getCallSiteArray[43].callGroovyObjectGetProperty(this), "Please stop inspecting elements by clicking on any of them.", "Error", $getCallSiteArray[44].callGetProperty(JOptionPane.class));
                return;
            }
            ScriptBytecodeAdapter.setGroovyObjectProperty($getCallSiteArray[50].callGroovyObjectGetProperty($getCallSiteArray[51].callGroovyObjectGetProperty(this)), recordBtn.class, (GroovyObject)$getCallSiteArray[52].callGroovyObjectGetProperty(this), "RecDriver");
            ScriptBytecodeAdapter.setGroovyObjectProperty(true, recordBtn.class, this, "recording");
            $getCallSiteArray[53].call($getCallSiteArray[54].callGroovyObjectGetProperty($getCallSiteArray[55].callGroovyObjectGetProperty(this)), false);
            $getCallSiteArray[56].call($getCallSiteArray[57].callGroovyObjectGetProperty($getCallSiteArray[58].callGroovyObjectGetProperty(this)), false);
            $getCallSiteArray[59].call($getCallSiteArray[60].callConstructor(ObjectLocator.class, this, $getCallSiteArray[61].callGroovyObjectGetProperty(this)));
            $getCallSiteArray[62].callCurrent(this, $getCallSiteArray[63].callGetProperty($getCallSiteArray[64].callGroovyObjectGetProperty(this)));
        }
        
        public void addRecording(final Object recordings) {
            final CallSite[] $getCallSiteArray = $getCallSiteArray();
            if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !recordBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[66].call(recordings), 0)) {
                    ScriptBytecodeAdapter.setGroovyObjectProperty(true, recordBtn.class, this, "firstActionRecorded");
                }
            }
            else if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[65].call(recordings), 0)) {
                ScriptBytecodeAdapter.setGroovyObjectProperty(true, recordBtn.class, this, "firstActionRecorded");
            }
            if (BytecodeInterface8.isOrigZ() && !recordBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (!DefaultTypeTransformation.booleanUnbox($getCallSiteArray[92].callGroovyObjectGetProperty(this)) && ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[93].call($getCallSiteArray[94].callGroovyObjectGetProperty($getCallSiteArray[95].callGroovyObjectGetProperty(this))), null) && DefaultTypeTransformation.booleanUnbox($getCallSiteArray[96].call($getCallSiteArray[97].call($getCallSiteArray[98].callGroovyObjectGetProperty($getCallSiteArray[99].callGroovyObjectGetProperty(this))), "http://")) && (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[100].callGroovyObjectGetProperty(this), null) || ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[101].callGroovyObjectGetProperty(this), $getCallSiteArray[102].call($getCallSiteArray[103].callGroovyObjectGetProperty($getCallSiteArray[104].callGroovyObjectGetProperty(this)))))) {
                    ScriptBytecodeAdapter.setGroovyObjectProperty($getCallSiteArray[105].call($getCallSiteArray[106].callGroovyObjectGetProperty($getCallSiteArray[107].callGroovyObjectGetProperty(this))), recordBtn.class, this, "lastURL");
                    $getCallSiteArray[108].call($getCallSiteArray[109].callGroovyObjectGetProperty(this), $getCallSiteArray[110].call($getCallSiteArray[111].call($getCallSiteArray[112].call($getCallSiteArray[113].callGroovyObjectGetProperty(this)), $getCallSiteArray[114].call($getCallSiteArray[115].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[116].callGroovyObjectGetProperty(this) }, new String[] { ".get(\"", "\");\r\n" })));
                }
            }
            else if (!DefaultTypeTransformation.booleanUnbox($getCallSiteArray[67].callGroovyObjectGetProperty(this)) && ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[68].call($getCallSiteArray[69].callGroovyObjectGetProperty($getCallSiteArray[70].callGroovyObjectGetProperty(this))), null) && DefaultTypeTransformation.booleanUnbox($getCallSiteArray[71].call($getCallSiteArray[72].call($getCallSiteArray[73].callGroovyObjectGetProperty($getCallSiteArray[74].callGroovyObjectGetProperty(this))), "http://")) && (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[75].callGroovyObjectGetProperty(this), null) || ScriptBytecodeAdapter.compareNotEqual($getCallSiteArray[76].callGroovyObjectGetProperty(this), $getCallSiteArray[77].call($getCallSiteArray[78].callGroovyObjectGetProperty($getCallSiteArray[79].callGroovyObjectGetProperty(this)))))) {
                ScriptBytecodeAdapter.setGroovyObjectProperty($getCallSiteArray[80].call($getCallSiteArray[81].callGroovyObjectGetProperty($getCallSiteArray[82].callGroovyObjectGetProperty(this))), recordBtn.class, this, "lastURL");
                $getCallSiteArray[83].call($getCallSiteArray[84].callGroovyObjectGetProperty(this), $getCallSiteArray[85].call($getCallSiteArray[86].call($getCallSiteArray[87].call($getCallSiteArray[88].callGroovyObjectGetProperty(this)), $getCallSiteArray[89].call($getCallSiteArray[90].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[91].callGroovyObjectGetProperty(this) }, new String[] { ".get(\"", "\");\r\n" })));
            }
            final Reference enterResponse = new Reference(null);
            final Reference clickResponse = new Reference(null);
            $getCallSiteArray[117].call(recordings, new GeneratedClosure((Object)this, (Object)this) {
                public static transient /* synthetic */ boolean __$stMC;
                private static /* synthetic */ SoftReference $callSiteArray;
                
                public Object doCall(final Object record) {
                    final CallSite[] $getCallSiteArray = $getCallSiteArray();
                    Object parsedResponse = null;
                    try {
                        parsedResponse = $getCallSiteArray[0].call($getCallSiteArray[1].callConstructor(JsonSlurper.class), record);
                    }
                    catch (Exception ex) {
                        return null;
                    }
                    if (BytecodeInterface8.isOrigZ() && !CodeTab$_recordBtn_addRecording_closure1.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[52].callGetProperty(parsedResponse), "click")) {
                            final Object call = $getCallSiteArray[53].call($getCallSiteArray[54].call($getCallSiteArray[55].callGroovyObjectGetProperty(this)), new GStringImpl(new Object[] { $getCallSiteArray[56].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).click();\r\n" }));
                            clickResponse.set(call);
                            return call;
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[57].callGetProperty(parsedResponse), "sendKeys")) {
                            $getCallSiteArray[58].call($getCallSiteArray[59].callGroovyObjectGetProperty(this), $getCallSiteArray[60].call($getCallSiteArray[61].call($getCallSiteArray[62].call($getCallSiteArray[63].callGroovyObjectGetProperty(this)), $getCallSiteArray[64].call($getCallSiteArray[65].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[66].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).clear();\r\n" })));
                            return $getCallSiteArray[67].call($getCallSiteArray[68].callGroovyObjectGetProperty(this), $getCallSiteArray[69].call($getCallSiteArray[70].call($getCallSiteArray[71].call($getCallSiteArray[72].callGroovyObjectGetProperty(this)), $getCallSiteArray[73].call($getCallSiteArray[74].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[75].callGetProperty(parsedResponse), $getCallSiteArray[76].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).sendKeys(\"", "\");\r\n" })));
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[77].callGetProperty(parsedResponse), "clear")) {
                            return $getCallSiteArray[78].call($getCallSiteArray[79].callGroovyObjectGetProperty(this), $getCallSiteArray[80].call($getCallSiteArray[81].call($getCallSiteArray[82].call($getCallSiteArray[83].callGroovyObjectGetProperty(this)), $getCallSiteArray[84].call($getCallSiteArray[85].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[86].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).clear();\r\n" })));
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[87].callGetProperty(parsedResponse), "select")) {
                            return $getCallSiteArray[88].call($getCallSiteArray[89].callGroovyObjectGetProperty(this), $getCallSiteArray[90].call($getCallSiteArray[91].call($getCallSiteArray[92].callGroovyObjectGetProperty(this)), new GStringImpl(new Object[] { $getCallSiteArray[93].call($getCallSiteArray[94].callGroovyObjectGetProperty(this)), $getCallSiteArray[95].callGetProperty(parsedResponse), $getCallSiteArray[96].callGetProperty(parsedResponse) }, new String[] { "new Select(", ".findElement(By.xpath(\"", "\"))).selectByVisibleText(\"", "\");\r\n" })));
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[97].callGetProperty(parsedResponse), "sendEnter")) {
                            final Object call2 = $getCallSiteArray[98].call($getCallSiteArray[99].call($getCallSiteArray[100].callGroovyObjectGetProperty(this)), new GStringImpl(new Object[] { $getCallSiteArray[101].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).sendKeys(org.openqa.selenium.Keys.ENTER);\r\n" }));
                            enterResponse.set(call2);
                            return call2;
                        }
                        return null;
                    }
                    else {
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[2].callGetProperty(parsedResponse), "click")) {
                            final Object call3 = $getCallSiteArray[3].call($getCallSiteArray[4].call($getCallSiteArray[5].callGroovyObjectGetProperty(this)), new GStringImpl(new Object[] { $getCallSiteArray[6].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).click();\r\n" }));
                            clickResponse.set(call3);
                            return call3;
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[7].callGetProperty(parsedResponse), "sendKeys")) {
                            $getCallSiteArray[8].call($getCallSiteArray[9].callGroovyObjectGetProperty(this), $getCallSiteArray[10].call($getCallSiteArray[11].call($getCallSiteArray[12].call($getCallSiteArray[13].callGroovyObjectGetProperty(this)), $getCallSiteArray[14].call($getCallSiteArray[15].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[16].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).clear();\r\n" })));
                            return $getCallSiteArray[17].call($getCallSiteArray[18].callGroovyObjectGetProperty(this), $getCallSiteArray[19].call($getCallSiteArray[20].call($getCallSiteArray[21].call($getCallSiteArray[22].callGroovyObjectGetProperty(this)), $getCallSiteArray[23].call($getCallSiteArray[24].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[25].callGetProperty(parsedResponse), $getCallSiteArray[26].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).sendKeys(\"", "\");\r\n" })));
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[27].callGetProperty(parsedResponse), "clear")) {
                            return $getCallSiteArray[28].call($getCallSiteArray[29].callGroovyObjectGetProperty(this), $getCallSiteArray[30].call($getCallSiteArray[31].call($getCallSiteArray[32].call($getCallSiteArray[33].callGroovyObjectGetProperty(this)), $getCallSiteArray[34].call($getCallSiteArray[35].callGroovyObjectGetProperty(this))), new GStringImpl(new Object[] { $getCallSiteArray[36].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).clear();\r\n" })));
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[37].callGetProperty(parsedResponse), "select")) {
                            return $getCallSiteArray[38].call($getCallSiteArray[39].callGroovyObjectGetProperty(this), $getCallSiteArray[40].call($getCallSiteArray[41].call($getCallSiteArray[42].callGroovyObjectGetProperty(this)), new GStringImpl(new Object[] { $getCallSiteArray[43].call($getCallSiteArray[44].callGroovyObjectGetProperty(this)), $getCallSiteArray[45].callGetProperty(parsedResponse), $getCallSiteArray[46].callGetProperty(parsedResponse) }, new String[] { "new Select(", ".findElement(By.xpath(\"", "\"))).selectByVisibleText(\"", "\");\r\n" })));
                        }
                        if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[47].callGetProperty(parsedResponse), "sendEnter")) {
                            final Object call4 = $getCallSiteArray[48].call($getCallSiteArray[49].call($getCallSiteArray[50].callGroovyObjectGetProperty(this)), new GStringImpl(new Object[] { $getCallSiteArray[51].callGetProperty(parsedResponse) }, new String[] { ".findElement(By.xpath(\"", "\")).sendKeys(org.openqa.selenium.Keys.ENTER);\r\n" }));
                            enterResponse.set(call4);
                            return call4;
                        }
                        return null;
                    }
                }
                
                public Object getClickResponse() {
                    $getCallSiteArray();
                    return clickResponse.get();
                }
                
                public Object getEnterResponse() {
                    $getCallSiteArray();
                    return enterResponse.get();
                }
                
                public static /* synthetic */ void __$swapInit() {
                    $getCallSiteArray();
                    CodeTab$_recordBtn_addRecording_closure1.$callSiteArray = null;
                }
                
                static {
                    __$swapInit();
                }
                
                private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                    final String[] names = new String[102];
                    $createCallSiteArray_1(names);
                    return new CallSiteArray(CodeTab$_recordBtn_addRecording_closure1.class, names);
                }
                
                private static /* synthetic */ CallSite[] $getCallSiteArray() {
                    CallSiteArray $createCallSiteArray;
                    if (CodeTab$_recordBtn_addRecording_closure1.$callSiteArray == null || ($createCallSiteArray = CodeTab$_recordBtn_addRecording_closure1.$callSiteArray.get()) == null) {
                        $createCallSiteArray = $createCallSiteArray();
                        CodeTab$_recordBtn_addRecording_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                    }
                    return $createCallSiteArray.array;
                }
            });
            if (BytecodeInterface8.isOrigZ() && !recordBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareNotEqual(enterResponse.get(), null)) {
                    $getCallSiteArray[123].call($getCallSiteArray[124].callGroovyObjectGetProperty(this), $getCallSiteArray[125].call($getCallSiteArray[126].call($getCallSiteArray[127].callGroovyObjectGetProperty(this)), enterResponse.get()));
                }
            }
            else if (ScriptBytecodeAdapter.compareNotEqual(enterResponse.get(), null)) {
                $getCallSiteArray[118].call($getCallSiteArray[119].callGroovyObjectGetProperty(this), $getCallSiteArray[120].call($getCallSiteArray[121].call($getCallSiteArray[122].callGroovyObjectGetProperty(this)), enterResponse.get()));
            }
            if (BytecodeInterface8.isOrigZ() && !recordBtn.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareNotEqual(clickResponse.get(), null)) {
                    $getCallSiteArray[133].call($getCallSiteArray[134].callGroovyObjectGetProperty(this), $getCallSiteArray[135].call($getCallSiteArray[136].call($getCallSiteArray[137].callGroovyObjectGetProperty(this)), clickResponse.get()));
                }
            }
            else if (ScriptBytecodeAdapter.compareNotEqual(clickResponse.get(), null)) {
                $getCallSiteArray[128].call($getCallSiteArray[129].callGroovyObjectGetProperty(this), $getCallSiteArray[130].call($getCallSiteArray[131].call($getCallSiteArray[132].callGroovyObjectGetProperty(this)), clickResponse.get()));
            }
        }
        
        protected /* synthetic */ MetaClass $getStaticMetaClass() {
            if (this.getClass() != recordBtn.class) {
                return ScriptBytecodeAdapter.initMetaClass(this);
            }
            ClassInfo $staticClassInfo = recordBtn.$staticClassInfo;
            if ($staticClassInfo == null) {
                $staticClassInfo = (recordBtn.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
            }
            return $staticClassInfo.getMetaClass();
        }
        
        public static /* synthetic */ void __$swapInit() {
            $getCallSiteArray();
            recordBtn.$callSiteArray = null;
        }
        
        static {
            __$swapInit();
        }
        
        private static /* synthetic */ CallSiteArray $createCallSiteArray() {
            final String[] names = new String[138];
            $createCallSiteArray_1(names);
            return new CallSiteArray(recordBtn.class, names);
        }
        
        private static /* synthetic */ CallSite[] $getCallSiteArray() {
            CallSiteArray $createCallSiteArray;
            if (recordBtn.$callSiteArray == null || ($createCallSiteArray = recordBtn.$callSiteArray.get()) == null) {
                $createCallSiteArray = $createCallSiteArray();
                recordBtn.$callSiteArray = new SoftReference($createCallSiteArray);
            }
            return $createCallSiteArray.array;
        }
        
        public class ObjectLocator extends SwingWorker<String, Object> implements GroovyObject
        {
            private CodeTab tab;
            private static /* synthetic */ ClassInfo $staticClassInfo;
            private transient /* synthetic */ MetaClass metaClass;
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public ObjectLocator(final CodeTab tab) {
                $getCallSiteArray();
                this.metaClass = this.$getStaticMetaClass();
                this.tab = (CodeTab)ScriptBytecodeAdapter.castToType(tab, CodeTab.class);
            }
            
            public String doInBackground() {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                final Object returnClosure = new GeneratedClosure(this, this) {
                    private static /* synthetic */ SoftReference $callSiteArray;
                    
                    public Object doCall(final Object recording) {
                        return $getCallSiteArray()[0].callCurrent(this, recording);
                    }
                    
                    public static /* synthetic */ void __$swapInit() {
                        $getCallSiteArray();
                        CodeTab$_ObjectLocator_doInBackground_closure1.$callSiteArray = null;
                    }
                    
                    static {
                        __$swapInit();
                    }
                    
                    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                        final String[] names = { null };
                        $createCallSiteArray_1(names);
                        return new CallSiteArray(CodeTab$_ObjectLocator_doInBackground_closure1.class, names);
                    }
                    
                    private static /* synthetic */ CallSite[] $getCallSiteArray() {
                        CallSiteArray $createCallSiteArray;
                        if (CodeTab$_ObjectLocator_doInBackground_closure1.$callSiteArray == null || ($createCallSiteArray = CodeTab$_ObjectLocator_doInBackground_closure1.$callSiteArray.get()) == null) {
                            $createCallSiteArray = $createCallSiteArray();
                            CodeTab$_ObjectLocator_doInBackground_closure1.$callSiteArray = new SoftReference($createCallSiteArray);
                        }
                        return $createCallSiteArray.array;
                    }
                };
                while (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[0].callGetProperty(this.tab))) {
                    $getCallSiteArray[1].call($getCallSiteArray[2].callGetProperty(this.tab), returnClosure);
                }
                return "";
            }
            
            @Override
            protected void process(final List<Object> chunks) {
                final CallSite[] $getCallSiteArray = $getCallSiteArray();
                Object record = null;
                final Iterator iterator = (Iterator)ScriptBytecodeAdapter.castToType($getCallSiteArray[3].call(chunks), Iterator.class);
                while (iterator.hasNext()) {
                    record = iterator.next();
                    if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[4].callGetProperty(this.tab), false)) {
                        return;
                    }
                    $getCallSiteArray[5].callCurrent(this, record);
                }
            }
            
            protected /* synthetic */ MetaClass $getStaticMetaClass() {
                if (this.getClass() != ObjectLocator.class) {
                    return ScriptBytecodeAdapter.initMetaClass(this);
                }
                ClassInfo $staticClassInfo = ObjectLocator.$staticClassInfo;
                if ($staticClassInfo == null) {
                    $staticClassInfo = (ObjectLocator.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
                }
                return $staticClassInfo.getMetaClass();
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                ObjectLocator.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                final String[] names = new String[6];
                $createCallSiteArray_1(names);
                return new CallSiteArray(ObjectLocator.class, names);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (ObjectLocator.$callSiteArray == null || ($createCallSiteArray = ObjectLocator.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    ObjectLocator.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        }
    }
}
