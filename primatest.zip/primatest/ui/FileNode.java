// 
// Decompiled by Procyon v0.5.36
// 

package com.primatest.ui;

import org.codehaus.groovy.runtime.callsite.CallSiteArray;
import java.util.Enumeration;
import javax.swing.tree.TreeNode;
import org.codehaus.groovy.runtime.GStringImpl;
import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
import org.codehaus.groovy.runtime.BytecodeInterface8;
import org.codehaus.groovy.runtime.callsite.CallSite;
import java.util.Collections;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import javax.swing.tree.MutableTreeNode;
import java.io.File;
import java.lang.ref.SoftReference;
import groovy.lang.MetaClass;
import org.codehaus.groovy.reflection.ClassInfo;
import groovy.lang.GroovyObject;
import javax.swing.tree.DefaultMutableTreeNode;

public class FileNode extends DefaultMutableTreeNode implements Comparable, GroovyObject
{
    private Object file;
    private static /* synthetic */ ClassInfo $staticClassInfo;
    public static transient /* synthetic */ boolean __$stMC;
    private transient /* synthetic */ MetaClass metaClass;
    public static /* synthetic */ long __timeStamp;
    public static /* synthetic */ long __timeStamp__239_neverHappen1397742965716;
    private static /* synthetic */ SoftReference $callSiteArray;
    
    public FileNode(final File file) {
        super($getCallSiteArray()[0].callGetProperty(file));
        this.metaClass = this.$getStaticMetaClass();
        this.file = file;
    }
    
    @Override
    public void insert(final MutableTreeNode newChild, final int childIndex) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        ScriptBytecodeAdapter.invokeMethodOnSuperN(DefaultMutableTreeNode.class, this, "insert", new Object[] { newChild, childIndex });
        $getCallSiteArray[1].call(Collections.class, $getCallSiteArray[2].callGroovyObjectGetProperty(this));
    }
    
    public int compareTo(final Object o) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        if (BytecodeInterface8.isOrigZ() && !FileNode.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[10].call(this.file)) && !DefaultTypeTransformation.booleanUnbox($getCallSiteArray[11].call($getCallSiteArray[12].callGetProperty(o)))) {
                final String compStr = (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[13].call("!", $getCallSiteArray[14].callGetProperty(this.file)), String.class);
                return DefaultTypeTransformation.intUnbox($getCallSiteArray[15].call(compStr, $getCallSiteArray[16].call(o)));
            }
        }
        else if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[3].call(this.file)) && !DefaultTypeTransformation.booleanUnbox($getCallSiteArray[4].call($getCallSiteArray[5].callGetProperty(o)))) {
            final String compStr2 = (String)ScriptBytecodeAdapter.castToType($getCallSiteArray[6].call("!", $getCallSiteArray[7].callGetProperty(this.file)), String.class);
            return DefaultTypeTransformation.intUnbox($getCallSiteArray[8].call(compStr2, $getCallSiteArray[9].call(o)));
        }
        return DefaultTypeTransformation.intUnbox($getCallSiteArray[17].call($getCallSiteArray[18].callCurrent(this), $getCallSiteArray[19].call(o)));
    }
    
    protected /* synthetic */ MetaClass $getStaticMetaClass() {
        if (this.getClass() != FileNode.class) {
            return ScriptBytecodeAdapter.initMetaClass(this);
        }
        ClassInfo $staticClassInfo = FileNode.$staticClassInfo;
        if ($staticClassInfo == null) {
            $staticClassInfo = (FileNode.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
        }
        return $staticClassInfo.getMetaClass();
    }
    
    public static /* synthetic */ void __$swapInit() {
        $getCallSiteArray();
        FileNode.$callSiteArray = null;
    }
    
    static {
        __$swapInit();
        FileNode.__timeStamp__239_neverHappen1397742965716 = 0L;
        FileNode.__timeStamp = 1397742965716L;
    }
    
    public Object getFile() {
        return this.file;
    }
    
    public void setFile(final Object file) {
        this.file = file;
    }
    
    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
        final String[] names = new String[20];
        $createCallSiteArray_1(names);
        return new CallSiteArray(FileNode.class, names);
    }
    
    private static /* synthetic */ CallSite[] $getCallSiteArray() {
        CallSiteArray $createCallSiteArray;
        if (FileNode.$callSiteArray == null || ($createCallSiteArray = FileNode.$callSiteArray.get()) == null) {
            $createCallSiteArray = $createCallSiteArray();
            FileNode.$callSiteArray = new SoftReference($createCallSiteArray);
        }
        return $createCallSiteArray.array;
    }
}
