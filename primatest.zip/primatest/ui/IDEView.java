// 
// Decompiled by Procyon v0.5.36
// 

package com.primatest.ui;

import org.codehaus.groovy.runtime.callsite.CallSiteArray;
import java.awt.MenuComponent;
import javax.accessibility.AccessibleContext;
import java.awt.image.VolatileImage;
import java.awt.ImageCapabilities;
import java.awt.event.InputMethodEvent;
import javax.swing.plaf.ComponentUI;
import java.awt.AWTKeyStroke;
import javax.swing.JRootPane;
import java.awt.FontMetrics;
import java.awt.BufferCapabilities;
import java.awt.image.ImageObserver;
import java.awt.im.InputContext;
import java.awt.event.KeyListener;
import java.awt.event.HierarchyEvent;
import javax.swing.ComponentInputMap;
import java.awt.event.ActionListener;
import java.awt.image.ImageProducer;
import java.awt.event.FocusEvent;
import java.io.PrintStream;
import java.awt.im.InputMethodRequests;
import javax.swing.TransferHandler;
import javax.swing.JToolTip;
import javax.swing.InputMap;
import java.io.PrintWriter;
import java.awt.Insets;
import javax.swing.event.AncestorListener;
import javax.swing.ActionMap;
import javax.swing.JPopupMenu;
import java.awt.image.BufferStrategy;
import java.awt.event.InputMethodListener;
import java.awt.Font;
import java.awt.PopupMenu;
import javax.swing.KeyStroke;
import java.awt.event.HierarchyBoundsListener;
import java.awt.Color;
import java.awt.FocusTraversalPolicy;
import java.awt.PointerInfo;
import java.awt.event.KeyEvent;
import javax.swing.InputVerifier;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.AWTEvent;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.ColorModel;
import javax.swing.border.Border;
import java.awt.event.ContainerListener;
import java.awt.event.ContainerEvent;
import javax.accessibility.AccessibleStateSet;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseEvent;
import javax.swing.plaf.PanelUI;
import java.util.Locale;
import java.beans.PropertyChangeListener;
import sun.java2d.pipe.Region;
import java.awt.Window;
import java.awt.peer.ComponentPeer;
import java.awt.Image;
import java.awt.Event;
import java.awt.dnd.DropTarget;
import java.awt.LayoutManager;
import java.util.Set;
import java.awt.Toolkit;
import java.awt.Rectangle;
import java.awt.GraphicsConfiguration;
import java.awt.Cursor;
import javax.accessibility.Accessible;
import java.awt.Component;
import java.awt.Point;
import java.security.AccessControlContext;
import java.awt.Graphics;
import java.awt.event.FocusListener;
import java.beans.VetoableChangeListener;
import java.awt.event.MouseWheelListener;
import java.awt.Dimension;
import java.awt.ComponentOrientation;
import java.awt.event.HierarchyListener;
import java.awt.Container;
import org.codehaus.groovy.runtime.GStringImpl;
import org.fife.ui.rtextarea.RTextScrollPane;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import java.io.File;
import org.codehaus.groovy.runtime.callsite.CallSite;
import javax.swing.JSplitPane;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import com.jidesoft.swing.JideTabbedPane;
import net.miginfocom.swing.MigLayout;
import java.lang.ref.SoftReference;
import groovy.lang.MetaClass;
import org.codehaus.groovy.reflection.ClassInfo;
import javax.swing.JTabbedPane;
import groovy.lang.GroovyObject;
import javax.swing.JPanel;

public class IDEView extends JPanel implements GroovyObject
{
    private Object fileView;
    private JTabbedPane tabbedPane;
    private static /* synthetic */ ClassInfo $staticClassInfo;
    private transient /* synthetic */ MetaClass metaClass;
    public static /* synthetic */ long __timeStamp;
    public static /* synthetic */ long __timeStamp__239_neverHappen1397671187733;
    private static /* synthetic */ SoftReference $callSiteArray;
    
    public IDEView() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        this.metaClass = this.$getStaticMetaClass();
        $getCallSiteArray[0].callCurrent(this, $getCallSiteArray[1].callConstructor(MigLayout.class));
        this.tabbedPane = (JTabbedPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[2].callConstructor(JideTabbedPane.class), JTabbedPane.class);
        $getCallSiteArray[3].call(this.tabbedPane, false);
        $getCallSiteArray[4].call(this.tabbedPane, true);
        this.fileView = $getCallSiteArray[5].callConstructor(FileExplorer.class, "Dima", "c:\\SeleniumRecorder", this);
        final JSplitPane splitPane = (JSplitPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[6].callConstructor(JSplitPane.class, $getCallSiteArray[7].callGetProperty(JSplitPane.class), this.fileView, this.tabbedPane), JSplitPane.class);
        $getCallSiteArray[8].call(splitPane, true);
        $getCallSiteArray[9].call(splitPane, 250);
        $getCallSiteArray[10].callCurrent(this, splitPane, "push, grow,height 200:3000:");
    }
    
    public Object openGroovyFile(final File file) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        return $getCallSiteArray[11].callCurrent(this, file, $getCallSiteArray[12].callGetProperty(SyntaxConstants.class));
    }
    
    public Object openJavaFile(final File file) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        return $getCallSiteArray[13].callCurrent(this, file, $getCallSiteArray[14].callGetProperty(SyntaxConstants.class));
    }
    
    public Object openXMLFile(final File file) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        return $getCallSiteArray[15].callCurrent(this, file, $getCallSiteArray[16].callGetProperty(SyntaxConstants.class));
    }
    
    public Object openTextFile(final File file) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        return $getCallSiteArray[17].callCurrent(this, file, $getCallSiteArray[18].callGetProperty(SyntaxConstants.class));
    }
    
    public Object openFile(final File file, final Object type) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        final RSyntaxTextArea textArea = (RSyntaxTextArea)ScriptBytecodeAdapter.castToType($getCallSiteArray[19].callConstructor(RSyntaxTextArea.class, 10, 275), RSyntaxTextArea.class);
        $getCallSiteArray[20].call(textArea, type);
        $getCallSiteArray[21].call(textArea, true);
        $getCallSiteArray[22].call(textArea, true);
        final RTextScrollPane sp = (RTextScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[23].callConstructor(RTextScrollPane.class, textArea), RTextScrollPane.class);
        $getCallSiteArray[24].call(sp, true);
        final RTextScrollPane codeView = (RTextScrollPane)ScriptBytecodeAdapter.castToType($getCallSiteArray[25].callConstructor(RTextScrollPane.class, textArea), RTextScrollPane.class);
        $getCallSiteArray[26].call(textArea, $getCallSiteArray[27].callGetProperty(file));
        $getCallSiteArray[28].call(textArea, 0);
        $getCallSiteArray[29].call(this.tabbedPane, $getCallSiteArray[30].callGetProperty(file), codeView);
        return $getCallSiteArray[31].call(this.tabbedPane, codeView);
    }
    
    protected /* synthetic */ MetaClass $getStaticMetaClass() {
        if (this.getClass() != IDEView.class) {
            return ScriptBytecodeAdapter.initMetaClass(this);
        }
        ClassInfo $staticClassInfo = IDEView.$staticClassInfo;
        if ($staticClassInfo == null) {
            $staticClassInfo = (IDEView.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
        }
        return $staticClassInfo.getMetaClass();
    }
    
    public static /* synthetic */ void __$swapInit() {
        $getCallSiteArray();
        IDEView.$callSiteArray = null;
    }
    
    static {
        __$swapInit();
        IDEView.__timeStamp__239_neverHappen1397671187733 = 0L;
        IDEView.__timeStamp = 1397671187733L;
    }
    
    public Object getFileView() {
        return this.fileView;
    }
    
    public void setFileView(final Object fileView) {
        this.fileView = fileView;
    }
    
    public JTabbedPane getTabbedPane() {
        return this.tabbedPane;
    }
    
    public void setTabbedPane(final JTabbedPane tabbedPane) {
        this.tabbedPane = tabbedPane;
    }
    
    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
        final String[] names = new String[32];
        $createCallSiteArray_1(names);
        return new CallSiteArray(IDEView.class, names);
    }
    
    private static /* synthetic */ CallSite[] $getCallSiteArray() {
        CallSiteArray $createCallSiteArray;
        if (IDEView.$callSiteArray == null || ($createCallSiteArray = IDEView.$callSiteArray.get()) == null) {
            $createCallSiteArray = $createCallSiteArray();
            IDEView.$callSiteArray = new SoftReference($createCallSiteArray);
        }
        return $createCallSiteArray.array;
    }
}
