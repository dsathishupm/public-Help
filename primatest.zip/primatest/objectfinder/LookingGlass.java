// 
// Decompiled by Procyon v0.5.36
// 

package com.primatest.objectfinder;

import org.codehaus.groovy.runtime.callsite.CallSiteArray;
import org.codehaus.groovy.runtime.GStringImpl;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService$Builder;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.chrome.ChromeDriverService$Builder;
import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
import java.io.File;
import groovy.json.JsonSlurper;
import org.codehaus.groovy.runtime.callsite.CallSite;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.By;
import org.codehaus.groovy.runtime.BytecodeInterface8;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import java.util.concurrent.TimeUnit;
import java.lang.ref.SoftReference;
import groovy.lang.MetaClass;
import org.codehaus.groovy.reflection.ClassInfo;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import groovy.lang.GroovyObject;

public class LookingGlass implements Runnable, GroovyObject
{
    private Object exceptionClosure;
    private WebDriver RecDriver;
    private JavascriptExecutor js;
    private String BrowserType;
    private static Object getRawHtmlScript;
    private static Object initScript;
    private Object getObjectIDScript;
    private Object getObjectXpathScript;
    private Object highLightObjectScript;
    private Object recordObjectScript;
    private Object stopRecordingScript;
    private static Object isFocusedScript;
    private Object collectScript;
    private Object isPageRdyScript;
    private Object browserRdyClosure;
    private static /* synthetic */ ClassInfo $staticClassInfo;
    public static transient /* synthetic */ boolean __$stMC;
    private transient /* synthetic */ MetaClass metaClass;
    public static /* synthetic */ long __timeStamp;
    public static /* synthetic */ long __timeStamp__239_neverHappen1397537943935;
    private static /* synthetic */ SoftReference $callSiteArray;
    
    public LookingGlass(final Object browserRdy, final Object exception) {
        $getCallSiteArray();
        this.getObjectIDScript = "\n    var callback = arguments[arguments.length - 1];\n    callback(document.lookingGlassGenerateID(arguments[0]));\n";
        this.getObjectXpathScript = "\n    var callback = arguments[arguments.length - 1];\n    callback(document.lookingGlassGetXpath(arguments[0]));\n";
        this.highLightObjectScript = "\nvar stopHighLight = function(){\n    document.lookingGlassLastElem.style.outline = document.lookingGlassLastElemColor;\n    document.lookingGlassLastElem.style.backgroundColor = document.lookingGlassLastElemHighlight;\n}\nif(document.lookingGlassLastElem){\n    stopHighLight();\n}\ndocument.lookingGlassLastElem = arguments[0]\ndocument.lookingGlassLastElemColor = arguments[0].style.outline\ndocument.lookingGlassLastElemHighlight = arguments[0].style.backgroundColor\nsetTimeout(function(){stopHighLight()}, 8000);\narguments[0].style.outline=\"thin solid green\";\narguments[0].style.backgroundColor= \"#FDFF47\";\narguments[1](document.lookingGlassGetXpath(arguments[0]));\n";
        this.recordObjectScript = "\ndocument.body.style.cursor = \"pointer\";\ndocument.lookingGlassRecording = null;\ndocument.addEventListener('click', document.lookingGlassPreventClick,false);\ndocument.addEventListener('mousedown', document.lookingGlassPreventClick,false);\ndocument.addEventListener('mouseup', document.lookingGlassPreventClick,false);\ndocument.addEventListener('submit', document.lookingGlassPreventClick,false);\ndocument.addEventListener('mouseover', document.lookingGlassMouseOver, false);\n//window.onclick =\n";
        this.stopRecordingScript = "\n//document.body.style.cursor = document.lookingGlassLastCursor\nif(document.lookingGlassLastElem){\n    document.lookingGlassLastElem.style.outline = document.lookingGlassLastElemColor\n    document.lookingGlassLastElem.style.backgroundColor = document.lookingGlassLastElemHighlight\n}\ndocument.removeEventListener('click', document.lookingGlassPreventClick,false);\ndocument.removeEventListener('mousedown', document.lookingGlassPreventClick,false);\ndocument.removeEventListener('mouseup', document.lookingGlassPreventClick,false);\ndocument.removeEventListener('submit', document.lookingGlassPreventClick,false);\ndocument.removeEventListener('mouseover', document.lookingGlassMouseOver, false);\ndelete document.lookingGlassGetXpath\n";
        this.collectScript = "\n   var callback = arguments[arguments.length - 1];;\n   //if there is no document.lookingGlassMouseOver function that means we can't really do anything\n   if(!document.lookingGlassMouseOver){\n        callback('{error:\"init not run\"}');\n        return;\n   }\n   var waitForActions = function(){\n       if(document.lookingGlassRecording){\n        callback(document.lookingGlassGenerateID(document.lookingGlassRecording));\n        //callback(document.lookingGlassRecording);\n        document.lookingGlassRecording = null;\n       }\n       else{\n           if(document.lookingGlassRecordingStop == true){\n             callback(\"END OF RECORDING\")\n             document.lookingGlassRecording = null;\n             document.lookingGlassRecordingStop = false;\n           }\n           else{\n            setTimeout(waitForActions, 50);\n           }\n       }\n   }\n   waitForActions();\n";
        this.isPageRdyScript = "\nif(document.lookingGlassMouseOver){\n    arguments[0](\"true\");\n}\nelse{\n    arguments[0](\"false\");\n}\n";
        this.metaClass = this.$getStaticMetaClass();
        this.browserRdyClosure = browserRdy;
        this.exceptionClosure = exception;
    }
    
    public void stopRecording() {
        $getCallSiteArray()[0].call(this.js, this.stopRecordingScript);
    }
    
    public Object performElementAction(final String id, final Object reloadHTML, final String idType, final String actionType, final Object exceptionClosure) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        $getCallSiteArray[1].call($getCallSiteArray[2].call($getCallSiteArray[3].call(this.RecDriver)), 1, $getCallSiteArray[4].callGetProperty(TimeUnit.class));
        Object elements = null;
        final Object response = ScriptBytecodeAdapter.createMap(new Object[0]);
        try {
            if (BytecodeInterface8.isOrigZ() && !LookingGlass.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareEqual(idType, "XPath")) {
                    elements = $getCallSiteArray[21].call(this.RecDriver, $getCallSiteArray[22].call(By.class, id));
                }
                else if (ScriptBytecodeAdapter.compareEqual(idType, "ID")) {
                    elements = $getCallSiteArray[23].call(this.RecDriver, $getCallSiteArray[24].call(By.class, id));
                }
                else if (ScriptBytecodeAdapter.compareEqual(idType, "Name")) {
                    elements = $getCallSiteArray[25].call(this.RecDriver, $getCallSiteArray[26].call(By.class, id));
                }
                else if (ScriptBytecodeAdapter.compareEqual(idType, "CSS Selector")) {
                    elements = $getCallSiteArray[27].call(this.RecDriver, $getCallSiteArray[28].call(By.class, id));
                }
                else if (ScriptBytecodeAdapter.compareEqual(idType, "Class Name")) {
                    elements = $getCallSiteArray[29].call(this.RecDriver, $getCallSiteArray[30].call(By.class, id));
                }
                else if (ScriptBytecodeAdapter.compareEqual(idType, "Tag Name")) {
                    elements = $getCallSiteArray[31].call(this.RecDriver, $getCallSiteArray[32].call(By.class, id));
                }
                else if (ScriptBytecodeAdapter.compareEqual(idType, "Link Text")) {
                    elements = $getCallSiteArray[33].call(this.RecDriver, $getCallSiteArray[34].call(By.class, id));
                }
                else if (ScriptBytecodeAdapter.compareEqual(idType, "Partial Link Text")) {
                    elements = $getCallSiteArray[35].call(this.RecDriver, $getCallSiteArray[36].call(By.class, id));
                }
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "XPath")) {
                elements = $getCallSiteArray[5].call(this.RecDriver, $getCallSiteArray[6].call(By.class, id));
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "ID")) {
                elements = $getCallSiteArray[7].call(this.RecDriver, $getCallSiteArray[8].call(By.class, id));
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "Name")) {
                elements = $getCallSiteArray[9].call(this.RecDriver, $getCallSiteArray[10].call(By.class, id));
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "CSS Selector")) {
                elements = $getCallSiteArray[11].call(this.RecDriver, $getCallSiteArray[12].call(By.class, id));
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "Class Name")) {
                elements = $getCallSiteArray[13].call(this.RecDriver, $getCallSiteArray[14].call(By.class, id));
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "Tag Name")) {
                elements = $getCallSiteArray[15].call(this.RecDriver, $getCallSiteArray[16].call(By.class, id));
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "Link Text")) {
                elements = $getCallSiteArray[17].call(this.RecDriver, $getCallSiteArray[18].call(By.class, id));
            }
            else if (ScriptBytecodeAdapter.compareEqual(idType, "Partial Link Text")) {
                elements = $getCallSiteArray[19].call(this.RecDriver, $getCallSiteArray[20].call(By.class, id));
            }
        }
        catch (InvalidSelectorException ex4) {
            ScriptBytecodeAdapter.setProperty("<font color=red>Invalid locator.</font>", null, response, "text");
            return response;
        }
        catch (NoSuchWindowException ex) {
            $getCallSiteArray[37].call(exceptionClosure, ex);
            return null;
        }
        catch (WebDriverException ex5) {
            ScriptBytecodeAdapter.setProperty("<font color=red>Invalid locator.</font>", null, response, "text");
            return response;
        }
        if (BytecodeInterface8.isOrigZ() && !LookingGlass.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[41].call(this.js, this.isPageRdyScript), "false")) {
                $getCallSiteArray[42].call(this.js, LookingGlass.initScript);
                $getCallSiteArray[43].call(reloadHTML);
            }
        }
        else if (ScriptBytecodeAdapter.compareEqual($getCallSiteArray[38].call(this.js, this.isPageRdyScript), "false")) {
            $getCallSiteArray[39].call(this.js, LookingGlass.initScript);
            $getCallSiteArray[40].call(reloadHTML);
        }
        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !LookingGlass.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[57].call(elements), 0)) {
                try {
                    if (ScriptBytecodeAdapter.compareEqual(actionType, "highlight")) {
                        ScriptBytecodeAdapter.setProperty($getCallSiteArray[58].call(this.js, this.highLightObjectScript, $getCallSiteArray[59].call(elements, 0)), null, response, "xpath");
                    }
                    else if (ScriptBytecodeAdapter.compareEqual(actionType, "click")) {
                        ScriptBytecodeAdapter.setProperty($getCallSiteArray[60].call(this.js, this.getObjectXpathScript, $getCallSiteArray[61].call(elements, 0)), null, response, "xpath");
                        $getCallSiteArray[62].call($getCallSiteArray[63].call(elements, 0));
                    }
                    else if (ScriptBytecodeAdapter.compareEqual(actionType, "type")) {
                        ScriptBytecodeAdapter.setProperty($getCallSiteArray[64].call(this.js, this.getObjectXpathScript, $getCallSiteArray[65].call(elements, 0)), null, response, "xpath");
                        $getCallSiteArray[66].call($getCallSiteArray[67].call(elements, 0), "test text");
                    }
                }
                catch (Exception ex2) {
                    $getCallSiteArray[68].call(exceptionClosure, ex2);
                    return null;
                }
                if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[69].call(elements), 1)) {
                    ScriptBytecodeAdapter.setProperty("<font color=green>More then one element found, working with first one.</font>", null, response, "text");
                }
                else {
                    ScriptBytecodeAdapter.setProperty("<font color=green>Found One Element.</font>", null, response, "text");
                }
            }
            else {
                ScriptBytecodeAdapter.setProperty("<font color=red>No elements found.</font>", null, response, "text");
            }
        }
        else if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[44].call(elements), 0)) {
            try {
                if (ScriptBytecodeAdapter.compareEqual(actionType, "highlight")) {
                    ScriptBytecodeAdapter.setProperty($getCallSiteArray[45].call(this.js, this.highLightObjectScript, $getCallSiteArray[46].call(elements, 0)), null, response, "xpath");
                }
                else if (ScriptBytecodeAdapter.compareEqual(actionType, "click")) {
                    ScriptBytecodeAdapter.setProperty($getCallSiteArray[47].call(this.js, this.getObjectXpathScript, $getCallSiteArray[48].call(elements, 0)), null, response, "xpath");
                    $getCallSiteArray[49].call($getCallSiteArray[50].call(elements, 0));
                }
                else if (ScriptBytecodeAdapter.compareEqual(actionType, "type")) {
                    ScriptBytecodeAdapter.setProperty($getCallSiteArray[51].call(this.js, this.getObjectXpathScript, $getCallSiteArray[52].call(elements, 0)), null, response, "xpath");
                    $getCallSiteArray[53].call($getCallSiteArray[54].call(elements, 0), "test text");
                }
            }
            catch (Exception ex3) {
                $getCallSiteArray[55].call(exceptionClosure, ex3);
                return null;
            }
            if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[56].call(elements), 1)) {
                ScriptBytecodeAdapter.setProperty("<font color=green>More then one element found, working with first one.</font>", null, response, "text");
            }
            else {
                ScriptBytecodeAdapter.setProperty("<font color=green>Found One Element.</font>", null, response, "text");
            }
        }
        else {
            ScriptBytecodeAdapter.setProperty("<font color=red>No elements found.</font>", null, response, "text");
        }
        return response;
    }
    
    public Object getElementID(final Object xpath) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        $getCallSiteArray[70].callCurrent(this, 200);
        final Object elements = $getCallSiteArray[71].call(this.RecDriver, $getCallSiteArray[72].call(By.class, xpath));
        if (BytecodeInterface8.isOrigInt() && BytecodeInterface8.isOrigZ() && !LookingGlass.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
            if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[79].call(elements), 0)) {
                $getCallSiteArray[80].call(this.js, LookingGlass.initScript);
                Object response = $getCallSiteArray[81].call(this.js, this.getObjectIDScript, $getCallSiteArray[82].call(elements, 0));
                response = $getCallSiteArray[83].call($getCallSiteArray[84].callConstructor(JsonSlurper.class), response);
                return response;
            }
            return ScriptBytecodeAdapter.createMap(new Object[0]);
        }
        else {
            if (ScriptBytecodeAdapter.compareGreaterThan($getCallSiteArray[73].call(elements), 0)) {
                $getCallSiteArray[74].call(this.js, LookingGlass.initScript);
                Object response2 = $getCallSiteArray[75].call(this.js, this.getObjectIDScript, $getCallSiteArray[76].call(elements, 0));
                response2 = $getCallSiteArray[77].call($getCallSiteArray[78].callConstructor(JsonSlurper.class), response2);
                return response2;
            }
            return ScriptBytecodeAdapter.createMap(new Object[0]);
        }
    }
    
    public String getHTML(final Object exceptionClosure) {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        String s = null;
        try {
            $getCallSiteArray[85].call(this.RecDriver, $getCallSiteArray[86].call(By.class, "//*[1]"));
            final Object html = $getCallSiteArray[87].call(this.js, LookingGlass.getRawHtmlScript);
            s = (String)ScriptBytecodeAdapter.castToType(html, String.class);
            try {
                return s;
            }
            catch (Exception ex) {
                $getCallSiteArray[88].call(exceptionClosure, ex);
                return "";
            }
        }
        catch (Exception ex2) {}
        try {
            return s;
        }
        finally {}
        return null;
    }
    
    public Object FindObject(final Object reloadHTML) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: new             Lgroovy/lang/Reference;
        //     4: dup_x1         
        //     5: swap           
        //     6: invokespecial   groovy/lang/Reference.<init>:(Ljava/lang/Object;)V
        //     9: astore_2        /* reloadHTML */
        //    10: invokestatic    com/primatest/objectfinder/LookingGlass.$getCallSiteArray:()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
        //    13: astore_3       
        //    14: new             Lcom/primatest/objectfinder/LookingGlass$_FindObject_closure1;
        //    17: dup            
        //    18: aload_0         /* this */
        //    19: aload_0         /* this */
        //    20: aload_2         /* reloadHTML */
        //    21: invokespecial   com/primatest/objectfinder/LookingGlass$_FindObject_closure1.<init>:(Ljava/lang/Object;Ljava/lang/Object;Lgroovy/lang/Reference;)V
        //    24: astore          recording
        //    26: aload           recording
        //    28: pop            
        //    29: aload_3        
        //    30: ldc_w           89
        //    33: aaload         
        //    34: aload           recording
        //    36: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;)Ljava/lang/Object;
        //    41: astore          recordingResult
        //    43: aload           recordingResult
        //    45: pop            
        //    46: aload           recordingResult
        //    48: astore          6
        //    50: nop            
        //    51: nop            
        //    52: aload           6
        //    54: areturn        
        //    55: goto            512
        //    58: astore          ex
        //    60: invokestatic    org/codehaus/groovy/runtime/BytecodeInterface8.isOrigZ:()Z
        //    63: ifeq            81
        //    66: getstatic       com/primatest/objectfinder/LookingGlass.__$stMC:Z
        //    69: ifne            81
        //    72: invokestatic    org/codehaus/groovy/runtime/BytecodeInterface8.disabledStandardMetaClass:()Z
        //    75: ifne            81
        //    78: goto            296
        //    81: aload_3        
        //    82: ldc_w           90
        //    85: aaload         
        //    86: aload_3        
        //    87: ldc_w           91
        //    90: aaload         
        //    91: aload           ex
        //    93: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //    98: ldc_w           "unload"
        //   101: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   106: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   109: ifne            143
        //   112: aload_3        
        //   113: ldc_w           92
        //   116: aaload         
        //   117: aload_3        
        //   118: ldc_w           93
        //   121: aaload         
        //   122: aload           ex
        //   124: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   129: ldc_w           "reload"
        //   132: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   137: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   140: ifeq            147
        //   143: iconst_1       
        //   144: goto            148
        //   147: iconst_0       
        //   148: ifeq            263
        //   151: aload_3        
        //   152: ldc_w           94
        //   155: aaload         
        //   156: aload_0         /* this */
        //   157: getfield        com/primatest/objectfinder/LookingGlass.RecDriver:Lorg/openqa/selenium/WebDriver;
        //   160: aload_3        
        //   161: ldc_w           95
        //   164: aaload         
        //   165: ldc             Lorg/openqa/selenium/By;.class
        //   167: ldc_w           "//*[1]"
        //   170: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   175: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   180: pop            
        //   181: aload_3        
        //   182: ldc_w           96
        //   185: aaload         
        //   186: aload_0         /* this */
        //   187: ldc_w           "reloading"
        //   190: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   195: pop            
        //   196: aload_3        
        //   197: ldc_w           97
        //   200: aaload         
        //   201: aload_2         /* reloadHTML */
        //   202: invokevirtual   groovy/lang/Reference.get:()Ljava/lang/Object;
        //   205: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;)Ljava/lang/Object;
        //   210: pop            
        //   211: aload_3        
        //   212: ldc_w           98
        //   215: aaload         
        //   216: aload_0         /* this */
        //   217: ldc_w           "reloading2"
        //   220: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   225: pop            
        //   226: aload_3        
        //   227: ldc_w           99
        //   230: aaload         
        //   231: aload_0         /* this */
        //   232: ldc_w           "unloaded"
        //   235: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   240: pop            
        //   241: aload_3        
        //   242: ldc_w           100
        //   245: aaload         
        //   246: aload           recording
        //   248: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;)Ljava/lang/Object;
        //   253: astore          8
        //   255: nop            
        //   256: nop            
        //   257: aload           8
        //   259: areturn        
        //   260: goto            293
        //   263: aload_3        
        //   264: ldc_w           101
        //   267: aaload         
        //   268: aload_0         /* this */
        //   269: aload_3        
        //   270: ldc_w           102
        //   273: aaload         
        //   274: aload           ex
        //   276: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   281: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   286: astore          9
        //   288: nop            
        //   289: nop            
        //   290: aload           9
        //   292: areturn        
        //   293: goto            508
        //   296: aload_3        
        //   297: ldc_w           103
        //   300: aaload         
        //   301: aload_3        
        //   302: ldc_w           104
        //   305: aaload         
        //   306: aload           ex
        //   308: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   313: ldc_w           "unload"
        //   316: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   321: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   324: ifne            358
        //   327: aload_3        
        //   328: ldc_w           105
        //   331: aaload         
        //   332: aload_3        
        //   333: ldc_w           106
        //   336: aaload         
        //   337: aload           ex
        //   339: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   344: ldc_w           "reload"
        //   347: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   352: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   355: ifeq            362
        //   358: iconst_1       
        //   359: goto            363
        //   362: iconst_0       
        //   363: ifeq            478
        //   366: aload_3        
        //   367: ldc_w           107
        //   370: aaload         
        //   371: aload_0         /* this */
        //   372: getfield        com/primatest/objectfinder/LookingGlass.RecDriver:Lorg/openqa/selenium/WebDriver;
        //   375: aload_3        
        //   376: ldc_w           108
        //   379: aaload         
        //   380: ldc             Lorg/openqa/selenium/By;.class
        //   382: ldc_w           "//*[1]"
        //   385: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   390: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   395: pop            
        //   396: aload_3        
        //   397: ldc_w           109
        //   400: aaload         
        //   401: aload_0         /* this */
        //   402: ldc_w           "reloading"
        //   405: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   410: pop            
        //   411: aload_3        
        //   412: ldc_w           110
        //   415: aaload         
        //   416: aload_2         /* reloadHTML */
        //   417: invokevirtual   groovy/lang/Reference.get:()Ljava/lang/Object;
        //   420: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;)Ljava/lang/Object;
        //   425: pop            
        //   426: aload_3        
        //   427: ldc_w           111
        //   430: aaload         
        //   431: aload_0         /* this */
        //   432: ldc_w           "reloading2"
        //   435: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   440: pop            
        //   441: aload_3        
        //   442: ldc_w           112
        //   445: aaload         
        //   446: aload_0         /* this */
        //   447: ldc_w           "unloaded"
        //   450: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   455: pop            
        //   456: aload_3        
        //   457: ldc_w           113
        //   460: aaload         
        //   461: aload           recording
        //   463: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;)Ljava/lang/Object;
        //   468: astore          10
        //   470: nop            
        //   471: nop            
        //   472: aload           10
        //   474: areturn        
        //   475: goto            508
        //   478: aload_3        
        //   479: ldc_w           114
        //   482: aaload         
        //   483: aload_0         /* this */
        //   484: aload_3        
        //   485: ldc_w           115
        //   488: aaload         
        //   489: aload           ex
        //   491: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   496: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   501: astore          11
        //   503: nop            
        //   504: nop            
        //   505: aload           11
        //   507: areturn        
        //   508: nop            
        //   509: goto            512
        //   512: nop            
        //   513: goto            521
        //   516: astore          12
        //   518: aload           12
        //   520: athrow         
        //   521: aconst_null    
        //   522: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  29     51     58     508    Ljava/lang/Exception;
        //  52     58     58     508    Ljava/lang/Exception;
        //  29     51     516    521    Any
        //  52     58     516    521    Any
        //  58     256    516    521    Any
        //  257    289    516    521    Any
        //  290    471    516    521    Any
        //  472    504    516    521    Any
        //  505    509    516    521    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0081:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void run() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        try {
            Object libDir = "";
            if (DefaultTypeTransformation.booleanUnbox($getCallSiteArray[116].call($getCallSiteArray[117].callConstructor(File.class, "lib/chromedriver.exe")))) {
                libDir = $getCallSiteArray[118].call($getCallSiteArray[119].callGetProperty($getCallSiteArray[120].callConstructor(File.class, "lib")), "/");
            }
            if (BytecodeInterface8.isOrigZ() && !LookingGlass.__$stMC && !BytecodeInterface8.disabledStandardMetaClass()) {
                if (ScriptBytecodeAdapter.compareEqual(this.BrowserType, "Chrome")) {
                    Object service = null;
                    if (ScriptBytecodeAdapter.compareGreaterThanEqual($getCallSiteArray[163].call($getCallSiteArray[164].call($getCallSiteArray[165].call(System.class, "os.name")), "mac"), 0)) {
                        service = $getCallSiteArray[166].call($getCallSiteArray[167].call($getCallSiteArray[168].call($getCallSiteArray[169].callConstructor(ChromeDriverService$Builder.class), 9515), $getCallSiteArray[170].callConstructor(File.class, $getCallSiteArray[171].call(libDir, "chromedriver"))));
                    }
                    else if (ScriptBytecodeAdapter.compareGreaterThanEqual($getCallSiteArray[172].call($getCallSiteArray[173].call($getCallSiteArray[174].call(System.class, "os.name")), "linux"), 0)) {
                        service = $getCallSiteArray[175].call($getCallSiteArray[176].call($getCallSiteArray[177].call($getCallSiteArray[178].callConstructor(ChromeDriverService$Builder.class), 9515), $getCallSiteArray[179].callConstructor(File.class, $getCallSiteArray[180].call(libDir, "chromedriver_linux"))));
                    }
                    else {
                        service = $getCallSiteArray[181].call($getCallSiteArray[182].call($getCallSiteArray[183].call($getCallSiteArray[184].callConstructor(ChromeDriverService$Builder.class), 9515), $getCallSiteArray[185].callConstructor(File.class, $getCallSiteArray[186].call(libDir, "chromedriver.exe"))));
                    }
                    $getCallSiteArray[187].call(service);
                    this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[188].callConstructor(RemoteWebDriver.class, $getCallSiteArray[189].call(service), $getCallSiteArray[190].call(DesiredCapabilities.class)), WebDriver.class);
                }
                else if (ScriptBytecodeAdapter.compareEqual(this.BrowserType, "Firefox")) {
                    this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[191].callConstructor(FirefoxDriver.class), WebDriver.class);
                }
                else if (ScriptBytecodeAdapter.compareEqual(this.BrowserType, "Safari")) {
                    this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[192].callConstructor(SafariDriver.class), WebDriver.class);
                }
                else {
                    final Object serviceIE = $getCallSiteArray[193].call($getCallSiteArray[194].call($getCallSiteArray[195].call($getCallSiteArray[196].callConstructor(InternetExplorerDriverService$Builder.class), 9517), $getCallSiteArray[197].callConstructor(File.class, "lib/IEDriverServer.exe")));
                    $getCallSiteArray[198].call(serviceIE);
                    final DesiredCapabilities d = (DesiredCapabilities)ScriptBytecodeAdapter.castToType($getCallSiteArray[199].call(DesiredCapabilities.class), DesiredCapabilities.class);
                    $getCallSiteArray[200].call(d, "nativeEvents", false);
                    $getCallSiteArray[201].call(d, $getCallSiteArray[202].callGetProperty(InternetExplorerDriver.class), true);
                    this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[203].callConstructor(RemoteWebDriver.class, $getCallSiteArray[204].call(serviceIE), d), WebDriver.class);
                }
            }
            else if (ScriptBytecodeAdapter.compareEqual(this.BrowserType, "Chrome")) {
                Object service2 = null;
                if (ScriptBytecodeAdapter.compareGreaterThanEqual($getCallSiteArray[121].call($getCallSiteArray[122].call($getCallSiteArray[123].call(System.class, "os.name")), "mac"), 0)) {
                    service2 = $getCallSiteArray[124].call($getCallSiteArray[125].call($getCallSiteArray[126].call($getCallSiteArray[127].callConstructor(ChromeDriverService$Builder.class), 9515), $getCallSiteArray[128].callConstructor(File.class, $getCallSiteArray[129].call(libDir, "chromedriver"))));
                }
                else if (ScriptBytecodeAdapter.compareGreaterThanEqual($getCallSiteArray[130].call($getCallSiteArray[131].call($getCallSiteArray[132].call(System.class, "os.name")), "linux"), 0)) {
                    service2 = $getCallSiteArray[133].call($getCallSiteArray[134].call($getCallSiteArray[135].call($getCallSiteArray[136].callConstructor(ChromeDriverService$Builder.class), 9515), $getCallSiteArray[137].callConstructor(File.class, $getCallSiteArray[138].call(libDir, "chromedriver_linux"))));
                }
                else {
                    service2 = $getCallSiteArray[139].call($getCallSiteArray[140].call($getCallSiteArray[141].call($getCallSiteArray[142].callConstructor(ChromeDriverService$Builder.class), 9515), $getCallSiteArray[143].callConstructor(File.class, $getCallSiteArray[144].call(libDir, "chromedriver.exe"))));
                }
                $getCallSiteArray[145].call(service2);
                this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[146].callConstructor(RemoteWebDriver.class, $getCallSiteArray[147].call(service2), $getCallSiteArray[148].call(DesiredCapabilities.class)), WebDriver.class);
            }
            else if (ScriptBytecodeAdapter.compareEqual(this.BrowserType, "Firefox")) {
                this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[149].callConstructor(FirefoxDriver.class), WebDriver.class);
            }
            else if (ScriptBytecodeAdapter.compareEqual(this.BrowserType, "Safari")) {
                this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[150].callConstructor(SafariDriver.class), WebDriver.class);
            }
            else {
                final Object serviceIE2 = $getCallSiteArray[151].call($getCallSiteArray[152].call($getCallSiteArray[153].call($getCallSiteArray[154].callConstructor(InternetExplorerDriverService$Builder.class), 9517), $getCallSiteArray[155].callConstructor(File.class, "lib/IEDriverServer.exe")));
                $getCallSiteArray[156].call(serviceIE2);
                final DesiredCapabilities d2 = (DesiredCapabilities)ScriptBytecodeAdapter.castToType($getCallSiteArray[157].call(DesiredCapabilities.class), DesiredCapabilities.class);
                $getCallSiteArray[158].call(d2, "nativeEvents", false);
                $getCallSiteArray[159].call(d2, $getCallSiteArray[160].callGetProperty(InternetExplorerDriver.class), true);
                this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType($getCallSiteArray[161].callConstructor(RemoteWebDriver.class, $getCallSiteArray[162].call(serviceIE2), d2), WebDriver.class);
            }
            $getCallSiteArray[205].call($getCallSiteArray[206].call($getCallSiteArray[207].call(this.RecDriver)), 999999, $getCallSiteArray[208].callGetProperty(TimeUnit.class));
            $getCallSiteArray[209].call($getCallSiteArray[210].call($getCallSiteArray[211].call(this.RecDriver)), 10, $getCallSiteArray[212].callGetProperty(TimeUnit.class));
            this.js = (JavascriptExecutor)ScriptBytecodeAdapter.castToType(this.RecDriver, JavascriptExecutor.class);
            ScriptBytecodeAdapter.invokeClosure(this.browserRdyClosure, new Object[0]);
        }
        catch (Exception ex) {
            ScriptBytecodeAdapter.invokeClosure(this.exceptionClosure, new Object[] { ex });
        }
    }
    
    protected /* synthetic */ MetaClass $getStaticMetaClass() {
        if (this.getClass() != LookingGlass.class) {
            return ScriptBytecodeAdapter.initMetaClass(this);
        }
        ClassInfo $staticClassInfo = LookingGlass.$staticClassInfo;
        if ($staticClassInfo == null) {
            $staticClassInfo = (LookingGlass.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
        }
        return $staticClassInfo.getMetaClass();
    }
    
    public static /* synthetic */ void __$swapInit() {
        $getCallSiteArray();
        LookingGlass.$callSiteArray = null;
    }
    
    static {
        __$swapInit();
        LookingGlass.__timeStamp__239_neverHappen1397537943935 = 0L;
        LookingGlass.__timeStamp = 1397537943935L;
        LookingGlass.isFocusedScript = "\nvar callback = arguments[arguments.length - 1];\ncallback(document.activeElement);\n";
        LookingGlass.initScript = "\ndocument.lookingGlassRecordingStop = false;\n//if already run just return\nif(document.lookingGlassGetXpath) return;\n\ndocument.lookingGlassGetCSSSelector = function(element){\n    if(!element) return \"\";\n    if (element.id!=='')\n        return \"#\"+element.id;\n    if (element===document.body)\n        return \"\";\n        //return element.tagName;\n\n    var ix= 0;\n    var siblings = element.parentNode.childNodes;\n    var classes = [];\n    var classesToWrite = [];\n\n    if(element.className){\n        classes = element.className.trim().split(\" \");\n        classesToWrite.push(classes[0]);\n    }\n\n    for (var i= 0; i<siblings.length; i++) {\n        var sibling = siblings[i];\n        if(classes.length > 0){\n            if(sibling.className){\n               var siblingClasses = sibling.className.trim().split(\" \");\n               for (var classCount= 0; classCount<classes.length; classCount++) {\n                    if(classes[classCount] === siblingClasses[classCount] && sibling.tagName === element.tagName){\n                        if(classCount+1 > classesToWrite.length){\n                            classesToWrite.push(classes[classCount]);\n                        }\n                    }\n                    else{\n                        break;\n                    }\n               }\n            }\n        }\n        else if (sibling===element){\n            return document.lookingGlassGetCSSSelector(element.parentNode)+' > '+element.tagName+':nth-child('+(ix+1)+')';\n        }\n        if (sibling.nodeType===1 && sibling.tagName===element.tagName)\n            ix++;\n    }\n    if(classes.length > 0){\n\n    }\n    if((classes.length > 0) && (classesToWrite.length <= classes.length)){\n        var classString = \"\";\n\n        for(var i=0;i<classesToWrite.length;i++){\n            classString = classString + \".\" + classesToWrite[i];\n        }\n        return document.lookingGlassGetCSSSelector(element.parentNode)+' > '+element.tagName+classString;\n    }\n    else{\n        return document.lookingGlassGetCSSSelector(element.parentNode)+' > '+element.tagName+':nth-child('+(ix)+')';\n    }\n}\n\ndocument.lookingGlassGetLinkText = function(element){\n    if(element.tagName == \"A\"){\n        return element.textContent;\n    }\n    else{\n        return \"\";\n    }\n}\n\ndocument.lookingGlassGetLinkText = function(element){\n    if(element.tagName == \"A\"){\n        return element.textContent;\n    }\n    else{\n        return \"\";\n    }\n}\n\ndocument.lookingGlassGenerateID = function(element){\n    //return '{\"xpath\":\"+document.lookingGlassGetXpath(element)+\",css:\"+document.lookingGlassGetCSSSelector(element)+\",id:\"+element.id+\",name:\"+element.getAttribute(\"name\")+\",className:\"+element.getAttribute(\"class\")+\",tagName:\"+element.tagName+\",linkText:\"+document.lookingGlassGetLinkText(element)+\"}';\n    var jsonParser\n    if(Object.toJSON){\n        jsonParser = Object.toJSON;\n    }\n    else{\n        jsonParser = JSON.stringify;\n    }\n    return jsonParser({xpath:document.lookingGlassGetXpath(element),css:document.lookingGlassGetCSSSelector(element),id:element.id,name:element.getAttribute(\"name\"),className:element.getAttribute(\"class\"),tagName:element.tagName,linkText:document.lookingGlassGetLinkText(element)});\n}\ndocument.lookingGlassGetXpath = function (element) {\n    if(!element) return \"\";\n    //if(element.tagName == \"A\"){\n    //    return \"//a[text()='\"+element.textContent+\"']\";\n    //}\n    if (element.id!=='')\n        return \"//*[@id='\"+element.id+\"']\";\n    if (element===document.body)\n        return \"/HTML/BODY\";\n        //return element.tagName;\n\n    var ix= 0;\n    var siblings= element.parentNode.childNodes;\n    for (var i= 0; i<siblings.length; i++) {\n        var sibling= siblings[i];\n        if (sibling===element)\n            return document.lookingGlassGetXpath(element.parentNode)+'/'+element.tagName+'['+(ix+1)+']';\n        if (sibling.nodeType===1 && sibling.tagName===element.tagName)\n            ix++;\n    }\n}\n\ndocument.lookingGlassMouseOver = function(e){\n\n    if(e.target == document.documentElement) return\n    document.lookingGlassRecording =  e.target;\n    e.target.lookingGlassOn = true;\n    e.target.addEventListener('click', document.lookingGlassPreventClick,false);\n    e.target.addEventListener('mousedown', document.lookingGlassPreventClick,false);\n    e.target.addEventListener('mouseup', document.lookingGlassPreventClick,false);\n    e.target.addEventListener('submit', document.lookingGlassPreventClick,false);\n    document.lookingGlassLastElem = e.target;\n    document.lookingGlassLastElemColor = e.target.style.outline;\n    document.lookingGlassLastElemHighlight = e.target.style.backgroundColor;\n    e.target.style.outline = \"medium solid green\";\n    e.target.style.backgroundColor = \"#FDFF47\";\n    var verifyAgain = function(){\n        if (e.target.lookingGlassOn === true){\n            document.lookingGlassRecording =  e.target;\n        }\n    }\n    setTimeout(verifyAgain,100);\n    setTimeout(verifyAgain,400);\n    setTimeout(verifyAgain,800);\n    //document.lookingGlassRecording =  document.lookingGlassGenerateID(e.target);\n};\n\ndocument.onmouseout = function(ev){\n    if(document.lookingGlassLastElem){\n        ev.target.lookingGlassOn = false;\n        ev.target.style.outline = document.lookingGlassLastElemColor;\n        ev.target.style.backgroundColor = document.lookingGlassLastElemHighlight;\n    }\n    ev.target.removeEventListener('click', document.lookingGlassPreventClick,false);\n    ev.target.removeEventListener('mousedown', document.lookingGlassPreventClick,false);\n    ev.target.removeEventListener('mouseup', document.lookingGlassPreventClick,false);\n    ev.target.removeEventListener('submit', document.lookingGlassPreventClick,false);\n};\n\ndocument.lookingGlassLastCursor = document.body.style.cursor;\n\ndocument.lookingGlassPreventClick = function(e){\n    //document.lookingGlassRecording =  e.target;\n    document.lookingGlassRecordingStop = true;\n    document.removeEventListener('mouseover', document.lookingGlassMouseOver);\n    document.removeEventListener('click', document.lookingGlassPreventClick,false);\n    document.removeEventListener('mousedown', document.lookingGlassPreventClick,false);\n    document.removeEventListener('mouseup', document.lookingGlassPreventClick,false);\n    document.removeEventListener('submit', document.lookingGlassPreventClick,false);\n\n    e.target.removeEventListener('mouseover', document.lookingGlassMouseOver);\n    e.target.style.outline = document.lookingGlassLastElemColor;\n    e.target.style.backgroundColor = document.lookingGlassLastElemHighlight;\n    document.body.style.cursor =  document.lookingGlassLastCursor;\n    if(e.stopPropagation) e.stopPropagation();\n    if(e.preventDefault) e.preventDefault();\n    if(e.stopImmediatePropagation) e.stopImmediatePropagation();\n    return false;\n};\n\n";
        LookingGlass.getRawHtmlScript = "\n    var callback = arguments[arguments.length - 1];\n    callback(document.documentElement.innerHTML);\n";
    }
    
    public Object getExceptionClosure() {
        return this.exceptionClosure;
    }
    
    public void setExceptionClosure(final Object exceptionClosure) {
        this.exceptionClosure = exceptionClosure;
    }
    
    public WebDriver getRecDriver() {
        return this.RecDriver;
    }
    
    public void setRecDriver(final WebDriver recDriver) {
        this.RecDriver = recDriver;
    }
    
    public JavascriptExecutor getJs() {
        return this.js;
    }
    
    public void setJs(final JavascriptExecutor js) {
        this.js = js;
    }
    
    public String getBrowserType() {
        return this.BrowserType;
    }
    
    public void setBrowserType(final String browserType) {
        this.BrowserType = browserType;
    }
    
    public static Object getGetRawHtmlScript() {
        return LookingGlass.getRawHtmlScript;
    }
    
    public static void setGetRawHtmlScript(final Object getRawHtmlScript) {
        LookingGlass.getRawHtmlScript = getRawHtmlScript;
    }
    
    public static Object getInitScript() {
        return LookingGlass.initScript;
    }
    
    public static void setInitScript(final Object initScript) {
        LookingGlass.initScript = initScript;
    }
    
    public Object getGetObjectIDScript() {
        return this.getObjectIDScript;
    }
    
    public void setGetObjectIDScript(final Object getObjectIDScript) {
        this.getObjectIDScript = getObjectIDScript;
    }
    
    public Object getGetObjectXpathScript() {
        return this.getObjectXpathScript;
    }
    
    public void setGetObjectXpathScript(final Object getObjectXpathScript) {
        this.getObjectXpathScript = getObjectXpathScript;
    }
    
    public Object getHighLightObjectScript() {
        return this.highLightObjectScript;
    }
    
    public void setHighLightObjectScript(final Object highLightObjectScript) {
        this.highLightObjectScript = highLightObjectScript;
    }
    
    public Object getRecordObjectScript() {
        return this.recordObjectScript;
    }
    
    public void setRecordObjectScript(final Object recordObjectScript) {
        this.recordObjectScript = recordObjectScript;
    }
    
    public Object getStopRecordingScript() {
        return this.stopRecordingScript;
    }
    
    public void setStopRecordingScript(final Object stopRecordingScript) {
        this.stopRecordingScript = stopRecordingScript;
    }
    
    public static Object getIsFocusedScript() {
        return LookingGlass.isFocusedScript;
    }
    
    public static void setIsFocusedScript(final Object isFocusedScript) {
        LookingGlass.isFocusedScript = isFocusedScript;
    }
    
    public Object getCollectScript() {
        return this.collectScript;
    }
    
    public void setCollectScript(final Object collectScript) {
        this.collectScript = collectScript;
    }
    
    public Object getIsPageRdyScript() {
        return this.isPageRdyScript;
    }
    
    public void setIsPageRdyScript(final Object isPageRdyScript) {
        this.isPageRdyScript = isPageRdyScript;
    }
    
    public Object getBrowserRdyClosure() {
        return this.browserRdyClosure;
    }
    
    public void setBrowserRdyClosure(final Object browserRdyClosure) {
        this.browserRdyClosure = browserRdyClosure;
    }
    
    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
        final String[] names = new String[213];
        $createCallSiteArray_1(names);
        return new CallSiteArray(LookingGlass.class, names);
    }
    
    private static /* synthetic */ CallSite[] $getCallSiteArray() {
        CallSiteArray $createCallSiteArray;
        if (LookingGlass.$callSiteArray == null || ($createCallSiteArray = LookingGlass.$callSiteArray.get()) == null) {
            $createCallSiteArray = $createCallSiteArray();
            LookingGlass.$callSiteArray = new SoftReference($createCallSiteArray);
        }
        return $createCallSiteArray.array;
    }
}
