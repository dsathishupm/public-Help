// 
// Decompiled by Procyon v0.5.36
// 

package com.primatest.recorder;

import org.codehaus.groovy.runtime.GStringImpl;
import org.codehaus.groovy.runtime.callsite.CallSite;
import org.codehaus.groovy.runtime.callsite.CallSiteArray;
import groovy.lang.Closure;
import org.codehaus.groovy.runtime.GeneratedClosure;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import java.lang.ref.SoftReference;
import groovy.lang.MetaClass;
import org.codehaus.groovy.reflection.ClassInfo;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import groovy.lang.GroovyObject;

public class Recorder implements GroovyObject
{
    private WebDriver RecDriver;
    private static Object initScript;
    private static Object collectScript;
    private Object stopScript;
    private Object returnClosure;
    private Object stopRecording;
    private JavascriptExecutor js;
    private static /* synthetic */ ClassInfo $staticClassInfo;
    private transient /* synthetic */ MetaClass metaClass;
    public static /* synthetic */ long __timeStamp;
    public static /* synthetic */ long __timeStamp__239_neverHappen1397536916932;
    private static /* synthetic */ SoftReference $callSiteArray;
    
    public Recorder() {
        $getCallSiteArray();
        this.RecDriver = (WebDriver)ScriptBytecodeAdapter.castToType(null, WebDriver.class);
        this.stopScript = "\nif (document.removeEventListener) {\n    document.removeEventListener('mousedown', document.lookingGlassRecordMouseUp);\n    document.removeEventListener('change', document.lookingGlassRecordChange);\n    document.removeEventListener('keydown', document.lookingGlassRecordKeyDown);\n}\nelse if(document.detachEvent){\n    document.detachEvent('onmousedown', document.lookingGlassRecordMouseUp);\n    document.detachEvent('onchange', document.lookingGlassRecordChange);\n    document.detachEvent('onkeydown', document.lookingGlassRecordKeyDown);\n}\ndelete document.redwoodRecording;\ndocument.lookingGlassLastCallback([]);\n";
        this.returnClosure = new _closure1(this);
        this.stopRecording = false;
        this.js = (JavascriptExecutor)ScriptBytecodeAdapter.castToType(null, JavascriptExecutor.class);
        this.metaClass = this.$getStaticMetaClass();
    }
    
    public Object stop() {
        final CallSite[] $getCallSiteArray = $getCallSiteArray();
        this.returnClosure = new GeneratedClosure(this, this) {
            private static /* synthetic */ SoftReference $callSiteArray;
            
            public Object doCall(final Object it) {
                $getCallSiteArray();
                return null;
            }
            
            public Object doCall() {
                $getCallSiteArray();
                return this.doCall(null);
            }
            
            public static /* synthetic */ void __$swapInit() {
                $getCallSiteArray();
                Recorder$_stop_closure2.$callSiteArray = null;
            }
            
            static {
                __$swapInit();
            }
            
            private static /* synthetic */ CallSiteArray $createCallSiteArray() {
                return new CallSiteArray(Recorder$_stop_closure2.class, new String[0]);
            }
            
            private static /* synthetic */ CallSite[] $getCallSiteArray() {
                CallSiteArray $createCallSiteArray;
                if (Recorder$_stop_closure2.$callSiteArray == null || ($createCallSiteArray = Recorder$_stop_closure2.$callSiteArray.get()) == null) {
                    $createCallSiteArray = $createCallSiteArray();
                    Recorder$_stop_closure2.$callSiteArray = new SoftReference($createCallSiteArray);
                }
                return $createCallSiteArray.array;
            }
        };
        this.stopRecording = true;
        Object call = null;
        try {
            call = $getCallSiteArray[0].call(this.js, this.stopScript);
            try {
                return call;
            }
            catch (Exception ex) {
                return $getCallSiteArray[1].callCurrent(this, $getCallSiteArray[2].callGetProperty(ex));
            }
        }
        catch (Exception ex2) {}
        try {
            return call;
        }
        finally {}
        return null;
    }
    
    public Object record(final Object returnClosure) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1         /* returnClosure */
        //     5: astore_3       
        //     6: aload_3        
        //     7: aload_0         /* this */
        //     8: swap           
        //     9: putfield        com/primatest/recorder/Recorder.returnClosure:Ljava/lang/Object;
        //    12: aload_3        
        //    13: pop            
        //    14: invokestatic    org/codehaus/groovy/runtime/BytecodeInterface8.isOrigZ:()Z
        //    17: ifeq            35
        //    20: getstatic       com/primatest/recorder/Recorder.__$stMC:Z
        //    23: ifne            35
        //    26: invokestatic    org/codehaus/groovy/runtime/BytecodeInterface8.disabledStandardMetaClass:()Z
        //    29: ifne            35
        //    32: goto            52
        //    35: aload_0         /* this */
        //    36: getfield        com/primatest/recorder/Recorder.RecDriver:Lorg/openqa/selenium/WebDriver;
        //    39: aconst_null    
        //    40: invokestatic    org/codehaus/groovy/runtime/ScriptBytecodeAdapter.compareEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //    43: ifeq            49
        //    46: ldc             ""
        //    48: areturn        
        //    49: goto            66
        //    52: aload_0         /* this */
        //    53: getfield        com/primatest/recorder/Recorder.RecDriver:Lorg/openqa/selenium/WebDriver;
        //    56: aconst_null    
        //    57: invokestatic    org/codehaus/groovy/runtime/ScriptBytecodeAdapter.compareEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //    60: ifeq            66
        //    63: ldc             ""
        //    65: areturn        
        //    66: aload_0         /* this */
        //    67: getfield        com/primatest/recorder/Recorder.RecDriver:Lorg/openqa/selenium/WebDriver;
        //    70: ldc             Lorg/openqa/selenium/JavascriptExecutor;.class
        //    72: invokestatic    org/codehaus/groovy/runtime/ScriptBytecodeAdapter.castToType:(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
        //    75: checkcast       Lorg/openqa/selenium/JavascriptExecutor;
        //    78: astore          4
        //    80: aload           4
        //    82: aload_0         /* this */
        //    83: swap           
        //    84: putfield        com/primatest/recorder/Recorder.js:Lorg/openqa/selenium/JavascriptExecutor;
        //    87: aload           4
        //    89: pop            
        //    90: aload_2        
        //    91: ldc             3
        //    93: aaload         
        //    94: aload_0         /* this */
        //    95: getfield        com/primatest/recorder/Recorder.js:Lorg/openqa/selenium/JavascriptExecutor;
        //    98: getstatic       com/primatest/recorder/Recorder.initScript:Ljava/lang/Object;
        //   101: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   106: pop            
        //   107: iconst_0       
        //   108: anewarray       Ljava/lang/Object;
        //   111: invokestatic    org/codehaus/groovy/runtime/ScriptBytecodeAdapter.createList:([Ljava/lang/Object;)Ljava/util/List;
        //   114: astore          recording
        //   116: aload           recording
        //   118: pop            
        //   119: aload_2        
        //   120: ldc             4
        //   122: aaload         
        //   123: aload_0         /* this */
        //   124: getfield        com/primatest/recorder/Recorder.js:Lorg/openqa/selenium/JavascriptExecutor;
        //   127: getstatic       com/primatest/recorder/Recorder.collectScript:Ljava/lang/Object;
        //   130: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   135: astore          data
        //   137: aload           data
        //   139: pop            
        //   140: aload_2        
        //   141: ldc             5
        //   143: aaload         
        //   144: aload_1         /* returnClosure */
        //   145: aload           data
        //   147: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   152: pop            
        //   153: ldc             ""
        //   155: astore          7
        //   157: nop            
        //   158: nop            
        //   159: aload           7
        //   161: areturn        
        //   162: goto            600
        //   165: astore          ex
        //   167: invokestatic    org/codehaus/groovy/runtime/BytecodeInterface8.isOrigZ:()Z
        //   170: ifeq            188
        //   173: getstatic       com/primatest/recorder/Recorder.__$stMC:Z
        //   176: ifne            188
        //   179: invokestatic    org/codehaus/groovy/runtime/BytecodeInterface8.disabledStandardMetaClass:()Z
        //   182: ifne            188
        //   185: goto            389
        //   188: aload_2        
        //   189: ldc             6
        //   191: aaload         
        //   192: aload_2        
        //   193: ldc             7
        //   195: aaload         
        //   196: aload           ex
        //   198: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   203: ldc             "unload"
        //   205: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   210: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   213: ifne            244
        //   216: aload_2        
        //   217: ldc             8
        //   219: aaload         
        //   220: aload_2        
        //   221: ldc             9
        //   223: aaload         
        //   224: aload           ex
        //   226: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   231: ldc             "reload"
        //   233: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   238: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   241: ifeq            248
        //   244: iconst_1       
        //   245: goto            249
        //   248: iconst_0       
        //   249: ifeq            255
        //   252: goto            386
        //   255: aload_2        
        //   256: ldc             10
        //   258: aaload         
        //   259: aload_0         /* this */
        //   260: aload_2        
        //   261: ldc             11
        //   263: aaload         
        //   264: ldc             "ERROR:"
        //   266: aload_2        
        //   267: ldc             12
        //   269: aaload         
        //   270: aload           ex
        //   272: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   277: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   282: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   287: pop            
        //   288: aload_2        
        //   289: ldc             13
        //   291: aaload         
        //   292: aload           recording
        //   294: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;)Ljava/lang/Object;
        //   299: iconst_0       
        //   300: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   303: invokestatic    org/codehaus/groovy/runtime/ScriptBytecodeAdapter.compareEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //   306: ifeq            349
        //   309: aload_2        
        //   310: ldc             14
        //   312: aaload         
        //   313: aload_2        
        //   314: ldc             15
        //   316: aaload         
        //   317: aload           ex
        //   319: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   324: ldc             "disconnected"
        //   326: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   331: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   334: ifne            341
        //   337: iconst_1       
        //   338: goto            342
        //   341: iconst_0       
        //   342: ifeq            349
        //   345: iconst_1       
        //   346: goto            350
        //   349: iconst_0       
        //   350: ifeq            386
        //   353: aload_2        
        //   354: ldc             16
        //   356: aaload         
        //   357: aload_0         /* this */
        //   358: aload_2        
        //   359: ldc             17
        //   361: aaload         
        //   362: ldc             "ERROR:"
        //   364: aload_2        
        //   365: ldc             18
        //   367: aaload         
        //   368: aload           ex
        //   370: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   375: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   380: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   385: pop            
        //   386: goto            587
        //   389: aload_2        
        //   390: ldc             19
        //   392: aaload         
        //   393: aload_2        
        //   394: ldc             20
        //   396: aaload         
        //   397: aload           ex
        //   399: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   404: ldc             "unload"
        //   406: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   411: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   414: ifne            445
        //   417: aload_2        
        //   418: ldc             21
        //   420: aaload         
        //   421: aload_2        
        //   422: ldc             22
        //   424: aaload         
        //   425: aload           ex
        //   427: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   432: ldc             "reload"
        //   434: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   439: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   442: ifeq            449
        //   445: iconst_1       
        //   446: goto            450
        //   449: iconst_0       
        //   450: ifeq            456
        //   453: goto            587
        //   456: aload_2        
        //   457: ldc             23
        //   459: aaload         
        //   460: aload_0         /* this */
        //   461: aload_2        
        //   462: ldc             24
        //   464: aaload         
        //   465: ldc             "ERROR:"
        //   467: aload_2        
        //   468: ldc             25
        //   470: aaload         
        //   471: aload           ex
        //   473: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   478: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   483: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   488: pop            
        //   489: aload_2        
        //   490: ldc             26
        //   492: aaload         
        //   493: aload           recording
        //   495: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;)Ljava/lang/Object;
        //   500: iconst_0       
        //   501: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   504: invokestatic    org/codehaus/groovy/runtime/ScriptBytecodeAdapter.compareEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //   507: ifeq            550
        //   510: aload_2        
        //   511: ldc             27
        //   513: aaload         
        //   514: aload_2        
        //   515: ldc             28
        //   517: aaload         
        //   518: aload           ex
        //   520: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   525: ldc             "disconnected"
        //   527: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   532: invokestatic    org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation.booleanUnbox:(Ljava/lang/Object;)Z
        //   535: ifne            542
        //   538: iconst_1       
        //   539: goto            543
        //   542: iconst_0       
        //   543: ifeq            550
        //   546: iconst_1       
        //   547: goto            551
        //   550: iconst_0       
        //   551: ifeq            587
        //   554: aload_2        
        //   555: ldc             29
        //   557: aaload         
        //   558: aload_0         /* this */
        //   559: aload_2        
        //   560: ldc             30
        //   562: aaload         
        //   563: ldc             "ERROR:"
        //   565: aload_2        
        //   566: ldc             31
        //   568: aaload         
        //   569: aload           ex
        //   571: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callGetProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   576: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.call:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   581: invokeinterface org/codehaus/groovy/runtime/callsite/CallSite.callCurrent:(Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
        //   586: pop            
        //   587: ldc             ""
        //   589: astore          9
        //   591: nop            
        //   592: nop            
        //   593: aload           9
        //   595: areturn        
        //   596: nop            
        //   597: goto            600
        //   600: nop            
        //   601: goto            609
        //   604: astore          10
        //   606: aload           10
        //   608: athrow         
        //   609: aconst_null    
        //   610: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  119    158    165    596    Ljava/lang/Exception;
        //  159    165    165    596    Ljava/lang/Exception;
        //  119    158    604    609    Any
        //  159    165    604    609    Any
        //  165    592    604    609    Any
        //  593    597    604    609    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0188:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected /* synthetic */ MetaClass $getStaticMetaClass() {
        if (this.getClass() != Recorder.class) {
            return ScriptBytecodeAdapter.initMetaClass(this);
        }
        ClassInfo $staticClassInfo = Recorder.$staticClassInfo;
        if ($staticClassInfo == null) {
            $staticClassInfo = (Recorder.$staticClassInfo = ClassInfo.getClassInfo(this.getClass()));
        }
        return $staticClassInfo.getMetaClass();
    }
    
    public static /* synthetic */ void __$swapInit() {
        $getCallSiteArray();
        Recorder.$callSiteArray = null;
    }
    
    static {
        __$swapInit();
        Recorder.__timeStamp__239_neverHappen1397536916932 = 0L;
        Recorder.__timeStamp = 1397536916932L;
        Recorder.collectScript = "\n   var callback = arguments[arguments.length - 1];\n   document.lookingGlassLastCallback = callback;\n\n   var count = 0;\n   var waitForActions = function(){\n       if((document.redwoodRecording) && (document.redwoodRecording.length > 0)){\n        callback(document.redwoodRecording);\n        document.redwoodRecording = [];\n       }\n       else if(count == 10){\n        callback([]);\n       }\n       else{\n        setTimeout(waitForActions, 100);\n       }\n       count++\n   }\n   waitForActions();\n   //setTimeout(waitForActions, 100);\n   //callback(document.redwoodRecording);\n   //document.redwoodRecording = [];\n";
        Recorder.initScript = "\n\nif(document.redwoodRecording) return;\nfunction getPathTo(element) {\n    //if(element.tagName == \"A\"){\n    //    return \"//a[text()='\"+element.textContent+\"']\";\n    //}\n    if (element.id!=='')\n        return \"//*[@id='\"+element.id+\"']\";\n    if (element===document.body)\n        return element.tagName;\n\n    var ix= 0;\n    var siblings= element.parentNode.childNodes;\n    for (var i= 0; i<siblings.length; i++) {\n        var sibling= siblings[i];\n        if (sibling===element)\n            return getPathTo(element.parentNode)+'/'+element.tagName+'['+(ix+1)+']';\n        if (sibling.nodeType===1 && sibling.tagName===element.tagName)\n            ix++;\n    }\n}\n\ndocument.redwoodRecording = [];\n\n//document.lookingGlassXhr = new XMLHttpRequest();\n//document.lookingGlassXhr.open('POST', 'http://localhost:9933', true);\n//document.lookingGlassXhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');\n//document.lookingGlassXhr.send(\"BLANK\");\n\ndocument.lookingGlassSendRecording = function(data){\n    document.lookingGlassXhr.open('POST', 'http://localhost:9933', true);\n    document.lookingGlassXhr.send(data);\n}\n\ndocument.lookingGlassRecordKeyDown = function(ev){\n    var jsonParser\n    if(Object.toJSON){\n        jsonParser = Object.toJSON;\n    }\n    else{\n        jsonParser = JSON.stringify;\n    }\n    if(ev.keyCode == 13){\n        var path = getPathTo(ev.target);\n        document.redwoodRecording.push(jsonParser({operation:\"sendEnter\",idType:\"xpath\",id:getPathTo(ev.target)}));\n        //document.lookingGlassSendRecording(jsonParser({operation:\"sendEnter\",idType:\"xpath\",id:getPathTo(ev.target)}));\n    }\n}\n\ndocument.lookingGlassRecordChange = function(ev){\n    var jsonParser\n    if(Object.toJSON){\n        jsonParser = Object.toJSON;\n    }\n    else{\n        jsonParser = JSON.stringify;\n    }\n    if(ev.target.tagName === \"INPUT\"){\n        if((ev.target.type === \"checkbox\") ||(ev.target.type === \"radio\")){\n            //document.lookingGlassSendRecording(jsonParser({operation:\"click\",idType:\"xpath\",id:getPathTo(ev.target)}));\n            document.redwoodRecording.push(jsonParser({operation:\"click\",idType:\"xpath\",id:getPathTo(ev.target)}));\n        }\n        else if(ev.target.value === \"\"){\n            //document.lookingGlassSendRecording(jsonParser({operation:\"clear\",idType:\"xpath\",id:getPathTo(ev.target)}));\n            document.redwoodRecording.push(jsonParser({operation:\"clear\",idType:\"xpath\",id:getPathTo(ev.target)}));\n        }\n        else{\n            //document.lookingGlassSendRecording(jsonParser({operation:\"sendKeys\",idType:\"xpath\",id:getPathTo(ev.target),data:ev.target.value}));\n            document.redwoodRecording.push(jsonParser({operation:\"sendKeys\",idType:\"xpath\",id:getPathTo(ev.target),data:ev.target.value}));\n        }\n    }\n    else if(ev.target.tagName == \"SELECT\"){\n        var selectedText = ev.target.options[ev.target.selectedIndex].text;\n        //document.lookingGlassSendRecording(jsonParser({operation:\"select\",idType:\"xpath\",id:getPathTo(ev.target),data:selectedText}));\n        document.redwoodRecording.push(jsonParser({operation:\"select\",idType:\"xpath\",id:getPathTo(ev.target),data:selectedText}));\n    }\n};\n\ndocument.lookingGlassRecordMouseUp = function(ev){\n    var jsonParser\n    if(Object.toJSON){\n        jsonParser = Object.toJSON;\n    }\n    else{\n        jsonParser = JSON.stringify;\n    }\n    console.log(ev.target.tagName);\n    console.log(ev.target.type);\n    //var xhr = new XMLHttpRequest();\n\n\n    if(ev.target.tagName === \"SELECT\"){\n        return;\n    }\n    else if(ev.target.tagName === \"INPUT\"){\n        if(ev.target.type === \"submit\"){\n            //document.lookingGlassSendRecording(jsonParser({operation:\"click\",idType:\"xpath\",id:getPathTo(ev.target)}));\n            document.redwoodRecording.push(jsonParser({operation:\"click\",idType:\"xpath\",id:getPathTo(ev.target)}));\n        }\n        return;\n    }\n    else if((ev.target.tagName != \"INPUT\") && (ev.target.tagName != \"SELECT\")){\n        var path = getPathTo(ev.target);\n        //document.lookingGlassSendRecording(jsonParser({operation:\"click\",idType:\"xpath\",id:getPathTo(ev.target)}));\n        document.redwoodRecording.push(jsonParser({operation:\"click\",idType:\"xpath\",id:getPathTo(ev.target)}));\n    }\n};\n\n   window.onbeforeunload  = function(){\n        var delay = function (ms) {\n            var start = +new Date;\n            var array = document.redwoodRecording;\n            while ((+new Date - start) < 500);\n            document.lookingGlassLastCallback(document.redwoodRecording);\n            while ((+new Date - start) < 500);\n            document.lookingGlassLastCallback(document.redwoodRecording);\n            while ((+new Date - start) < 500);\n            //while ((+new Date - start) < ms);\n        }\n        delay(500);\n    }\n\nif(!document.lookingGlassLoaded){\n   if (document.addEventListener){  // W3C DOM\n    document.addEventListener('mousedown', document.lookingGlassRecordMouseUp);\n    document.addEventListener('change', document.lookingGlassRecordChange);\n    document.addEventListener('keydown', document.lookingGlassRecordKeyDown);\n   }\n   else if (document.attachEvent) { // IE DOM\n    document.attachEvent('onmousedown', document.lookingGlassRecordMouseUp);\n    document.attachEvent('onchange', document.lookingGlassRecordChange);\n    document.attachEvent('onkeydown', document.lookingGlassRecordKeyDown);\n   }\n}\n";
    }
    
    public WebDriver getRecDriver() {
        return this.RecDriver;
    }
    
    public void setRecDriver(final WebDriver recDriver) {
        this.RecDriver = recDriver;
    }
    
    public static Object getInitScript() {
        return Recorder.initScript;
    }
    
    public static void setInitScript(final Object initScript) {
        Recorder.initScript = initScript;
    }
    
    public static Object getCollectScript() {
        return Recorder.collectScript;
    }
    
    public static void setCollectScript(final Object collectScript) {
        Recorder.collectScript = collectScript;
    }
    
    public Object getStopScript() {
        return this.stopScript;
    }
    
    public void setStopScript(final Object stopScript) {
        this.stopScript = stopScript;
    }
    
    public Object getReturnClosure() {
        return this.returnClosure;
    }
    
    public void setReturnClosure(final Object returnClosure) {
        this.returnClosure = returnClosure;
    }
    
    public Object getStopRecording() {
        return this.stopRecording;
    }
    
    public void setStopRecording(final Object stopRecording) {
        this.stopRecording = stopRecording;
    }
    
    public JavascriptExecutor getJs() {
        return this.js;
    }
    
    public void setJs(final JavascriptExecutor js) {
        this.js = js;
    }
    
    private static /* synthetic */ CallSiteArray $createCallSiteArray() {
        final String[] names = new String[32];
        $createCallSiteArray_1(names);
        return new CallSiteArray(Recorder.class, names);
    }
    
    private static /* synthetic */ CallSite[] $getCallSiteArray() {
        CallSiteArray $createCallSiteArray;
        if (Recorder.$callSiteArray == null || ($createCallSiteArray = Recorder.$callSiteArray.get()) == null) {
            $createCallSiteArray = $createCallSiteArray();
            Recorder.$callSiteArray = new SoftReference($createCallSiteArray);
        }
        return $createCallSiteArray.array;
    }
    
    class _closure1 extends Closure implements GeneratedClosure
    {
        private static /* synthetic */ SoftReference $callSiteArray;
        
        public _closure1(final Object _outerInstance, final Object _thisObject) {
            $getCallSiteArray();
            super(_outerInstance, _thisObject);
        }
        
        public Object doCall(final Object it) {
            $getCallSiteArray();
            return null;
        }
        
        public Object doCall() {
            $getCallSiteArray();
            return this.doCall(null);
        }
        
        public static /* synthetic */ void __$swapInit() {
            $getCallSiteArray();
            _closure1.$callSiteArray = null;
        }
        
        static {
            __$swapInit();
        }
        
        private static /* synthetic */ CallSiteArray $createCallSiteArray() {
            return new CallSiteArray(_closure1.class, new String[0]);
        }
        
        private static /* synthetic */ CallSite[] $getCallSiteArray() {
            CallSiteArray $createCallSiteArray;
            if (_closure1.$callSiteArray == null || ($createCallSiteArray = _closure1.$callSiteArray.get()) == null) {
                $createCallSiteArray = $createCallSiteArray();
                _closure1.$callSiteArray = new SoftReference($createCallSiteArray);
            }
            return $createCallSiteArray.array;
        }
    }
}
