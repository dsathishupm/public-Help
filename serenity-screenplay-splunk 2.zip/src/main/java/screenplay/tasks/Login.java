package screenplay.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.*;
import net.thucydides.core.annotations.Step;
import screenplay.ui.LoginPage;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class Login implements Task {

    private final String user;
    private final String password;

    public Login(String user, String password) {
        this.user = user;
        this.password = password;
    }

    public static Login withCredentials(String user, String password) {
        return instrumented(Login.class, user, password);
    }

    @Step("{0} logs in with username #user")
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
            Enter.theValue(user).into(LoginPage.USERNAME),
            Enter.theValue(password).into(LoginPage.PASSWORD),
            Click.on(LoginPage.LOGIN_BUTTON)
        );
    }
}