package screenplay;

import net.serenitybdd.junit5.SerenityTest;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import screenplay.tasks.Login;

import static net.serenitybdd.screenplay.GivenWhenThen.*;

@SerenityTest
public class LoginTest {

    @BeforeEach
    void set_the_stage() {
        OnStage.setTheStage(new OnlineCast());
    }

    @Test
    void user_can_login_successfully() {
        OnStage.theActorCalled("Alice").attemptsTo(
            Login.withCredentials("testuser", "testpass")
        );
    }
}